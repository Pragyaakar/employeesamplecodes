/***********************************************************************
*
* The following javascript code is created by FMT Consultants LLC,
* a NetSuite Partner. It is a SuiteFlex component containing custom code
* intended for NetSuite (www.netsuite.com) and use the SuiteScript API.
* The code is provided "as is": FMT Consultants LLC shall not be liable
* for any damages arising out the intended use or if the code is modified
* after delivery.
*
* Company:     FMT Consultants LLC, www.fmtconsultants.com
* Author:      apoblete@fmtconsultants.com
* File:        AM_CUE_CheckPurchaseOrders.js
* Date:        3/10/2019
*
***********************************************************************/
/**
* Trigger function that warns the user if the current purchase order number
* already exists for the selected customer.
* @author  apoblete@fmtconsultants.com
* @param   null
* @returns{boolean}
*/
function saveRecord_checkPurchaseOrders() {
  try {
    //Constants
    var customerId = nlapiGetFieldValue('entity');
    var poNumber = nlapiGetFieldValue('otherrefnum');
    var consumer_order_number = nlapiGetFieldValue('custbody_consumer_order_number');
    var internalid = nlapiGetRecordId();
    //nlapiLogExecution('debug', 'nlobjContext', nlapiGetContext( ).getExecutionContext ( ));

    if (customerId && (poNumber || consumer_order_number)) {
      if (duplicatePurchaseOrders(customerId, poNumber, consumer_order_number, internalid)) {
        alert("This PO number or Consumer Order Number you have entered has already been used and cannot be used again. You will need to use a new PO number or Consumer Order Number in order to save your order.");
        return false;
      }
    }
    return true;

  } catch (err) {
    nlapiLogExecution('error', 'The script encountered an error', err.toString());
  }
}
function saveRecord_checkPurchaseOrders_UE() {

  if(nlapiGetContext( ).getExecutionContext ( )!="userinterface")
  {
    var customerId = nlapiGetFieldValue('entity');
    var poNumber = nlapiGetFieldValue('otherrefnum');
    var consumer_order_number = nlapiGetFieldValue('custbody_consumer_order_number');
    var internalid = nlapiGetRecordId();
    if (customerId && (poNumber || consumer_order_number)) {
      if (duplicatePurchaseOrders(customerId, poNumber, consumer_order_number, internalid)) {
        if(internalid)
        {
          nlapiLogExecution('debug', 'details','Order :'+internalid +" , ExecutionContext :"+ nlapiGetContext( ).getExecutionContext ( ) +" , PoNumber : "+poNumber +" , CONSUMER ORDER NUMBER : "+consumer_order_number); 
        }
        else
        {
          nlapiLogExecution('debug', 'ExecutionContext', nlapiGetContext( ).getExecutionContext ( ));
        }
        throw "This PO number or Consumer Order Number you have entered has already been used and cannot be used again. You will need to use a new PO number or new Consumer Order Number in order to save your order.";
      }
    }
  }
}

/**
* Function that checks if a purchase order number already exists for a given customer.
* @param{string} customerId
* @param{integer} poNumber
* @returns{boolean} salesOrderFound
*/
function duplicatePurchaseOrders(customerId, poNumber,consumer_order_number, internalid) {
  var filter = [];
  if(internalid)
  {
    filter.push(["internalid","noneof",internalid]);
    filter.push("AND");
  }	
  filter.push(["mainline","is","T"]);
  filter.push("AND");
  filter.push(["entity","anyof",customerId]);
  filter.push("AND");
  if(poNumber && consumer_order_number)
  {
    filter.push([["otherrefnum","equalto",poNumber],"OR",["custbody_consumer_order_number","is",consumer_order_number]]);
  }
  else if(poNumber)
  {
    filter.push(["otherrefnum","equalto",poNumber]);
  }
  else if(consumer_order_number)
  {
    filter.push(["custbody_consumer_order_number","is",consumer_order_number]);
  }
  var searchResults = nlapiSearchRecord('transaction', null, filter);
  if (searchResults) {
    return true;
  }
  return false;
}
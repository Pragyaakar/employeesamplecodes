/***********************************************************************
 *
 * The following javascript code is created by FMT Consultants LLC,
 * a NetSuite Partner. It is a SuiteFlex component containing custom code
 * intended for NetSuite (www.netsuite.com) and use the SuiteScript API.
 * The code is provided "as is": FMT Consultants LLC shall not be liable
 * for any damages arising out the intended use or if the code is modified
 * after delivery.
 *
 * Company:     FMT Consultants LLC, www.fmtconsultants.com
 * Author:      apoblete@fmtconsultants.com
 * File:        AM_CUE_CheckPurchaseOrders.js
 * Date:        2/11/2016
 *
 ***********************************************************************/
/**
 * Trigger function that warns the user if the current purchase order number
 * already exists for the selected customer.
 * @author  apoblete@fmtconsultants.com
 * @param   null
 * @returns{boolean}
 */
function saveRecord_checkPurchaseOrders() {
    try {
        //Constants
        var customerId = nlapiGetFieldValue('entity');
        var poNumber = nlapiGetFieldValue('otherrefnum');
        var internalid = nlapiGetRecordId();
        nlapiLogExecution('debug', 'internalid', internalid);

        if ((customerId != null && customerId != '') && (poNumber != null && poNumber != '')) {
            if (duplicatePurchaseOrders(customerId, poNumber, internalid)) {
                nlapiLogExecution('debug', 'duplicatePO', duplicatePurchaseOrders(customerId, poNumber));
                alert("This PO number you have entered has already been used and cannot be used again. You will need to use a new PO number in order to save your order.");
                return false;
            }
        }
        return true;

    } catch(err) {
        nlapiLogExecution('error', 'The script encountered an error', err.toString());
    }
}

/**
 * Function that checks if a purchase order number already exists for a given customer.
 * @param{string} customerId
 * @param{integer} poNumber
 * @returns{boolean} salesOrderFound
 */
function duplicatePurchaseOrders(customerId, poNumber, internalid) {
    var salesOrderFound = false;

    var filter = new Array();
    filter[0] = new nlobjSearchFilter('entity', null, 'anyof', customerId);
    filter[1] = new nlobjSearchFilter('otherrefnum', null, 'equalto', poNumber);
    filter[2] = new nlobjSearchFilter('mainline', null, 'is', 'T');

    var column = new Array();
    column[0] = new nlobjSearchColumn('entity');
    column[1] = new nlobjSearchColumn('otherrefnum');
    column[2] = new nlobjSearchColumn('internalid');

    var searchResults = nlapiSearchRecord('transaction', null, filter, column);
    if (searchResults != null && searchResults.length > 0) {
        var id = searchResults[0].getValue('internalid');
        nlapiLogExecution('debug', 'id', id);
        if (id != internalid) {
            salesOrderFound = true;
        }

    }
    nlapiLogExecution('debug', 'salesorderFound', salesOrderFound);

    return salesOrderFound;
}
/***********************************************************************
 *
 * The following javascript code is created by FMT Consultants LLC,
 * a NetSuite Partner. It is a SuiteFlex component containing custom code
 * intended for NetSuite (www.netsuite.com) and use the SuiteScript API.
 * The code is provided "as is": FMT Consultants LLC shall not be liable
 * for any damages arising out the intended use or if the code is modified
 * after delivery.
 *
 * Company:		FMT Consultants LLC, www.fmtconsultants.com
 * Author:		apoblete@fmtconsultants.com
 * File:        AM_CUE_Dropship.js
 * Date:        2/29/2016
 *
 ***********************************************************************/
//Constants
var TAX_STRING = null;
var TAX_ID = null;
var DROPSHIP = null;
var NOT_TAXABLE = -8;

/**
 * Function that modifys selected tax item based on the status of the drop ship checkbox
 * already exists for the selected customer.
 * @author  apoblete@fmtconsultants.com
 * @param{string} type
 * @param{string} name
 * @returns null
 */
function postSourcing_Dropship(type, name) {
    var context = nlapiGetContext();
    var roleCenter = context.getRoleCenter();
    if (roleCenter != 'CUSTOMER' && roleCenter != 'SALESCENTER') {
        if (name == 'taxitem' || name == 'custbody_dropship') {
            TAX_STRING = nlapiGetFieldText('taxitem');
            TAX_ID = nlapiGetFieldValue('taxitem');
            DROPSHIP = nlapiGetFieldValue('custbody_dropship');

            nlapiLogExecution('debug', 'taxString', TAX_STRING);
            nlapiLogExecution('debug', 'taxID', TAX_ID);
            nlapiLogExecution('debug', 'drop', DROPSHIP);

            if (TAX_ID != null && TAX_ID != '' && TAX_ID != NOT_TAXABLE) {
                if (DROPSHIP == 'T' && TAX_STRING.indexOf('taxable') == -1 && TAX_STRING.indexOf('Drop') == -1) {
                    var newTax = nlapiSetFieldText('taxitem', TAX_STRING.concat('-DropShip'));
                    nlapiLogExecution('debug', 'newTaxChecked', newTax);
                }
                if (DROPSHIP != 'T') {
                    if (TAX_STRING.indexOf('Drop') != -1) {
                        var newTax = nlapiSetFieldText('taxitem', TAX_STRING.replace('-DropShip', ''));
                    }
                    var newTax = nlapiSetFieldText('taxitem', TAX_STRING);
                    nlapiLogExecution('debug', 'newTaxUnchecked', newTax);
                }
            }
        }
    }
}


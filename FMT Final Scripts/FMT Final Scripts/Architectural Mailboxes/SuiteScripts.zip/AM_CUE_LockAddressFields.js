/***********************************************************************
 *
 * The following javascript code is created by FMT Consultants LLC,
 * a NetSuite Partner. It is a SuiteFlex component containing custom code
 * intended for NetSuite (www.netsuite.com) and use the SuiteScript API.
 * The code is provided "as is": FMT Consultants LLC shall not be liable
 * for any damages arising out the intended use or if the code is modified
 * after delivery.
 *
 * Company:		FMT Consultants LLC, www.fmtconsultants.com
 * Author:		apoblete@fmtconsultants.com
 * File:        AM_CUE_LockAddressFields.js
 * Date:        5/3/2016
 *
 ***********************************************************************/

//Constants
var AM_SALES_MANAGER = 'customrole1011';
var AM_CER = 'customrole1005';
var AM_CER_CUSTOMER_ENTRY_ACCESS = 'customrole1021';
/**
 * These functions prevents the user from editing the address on the customer record based on their role.
 * @param{sublist} type
 * @param{name} field
 * @returns null
 */

function cust_PageInit_LockLines(type) {
	if (type == 'edit') {
		var context = nlapiGetContext();
		var roleId = context.getRoleId();

		var recordID = nlapiGetRecordId();
		var recordType = nlapiGetRecordType();
		var record = nlapiLoadRecord(recordType, recordID);
		var totalLines = record.getLineItemCount('addressbook');

		if (roleId != 'administrator' && roleId != 'sales_manager' && roleId != AM_CER && roleId != AM_CER_CUSTOMER_ENTRY_ACCESS && roleId != AM_SALES_MANAGER) {
			for (var i = 1; i <= totalLines; i++) {
				nlapiDisableLineItemField('addressbook', 'defaultshipping', i);
				nlapiDisableLineItemField('addressbook', 'defaultbilling', i);
				nlapiDisableLineItemField('addressbook', 'isresidential', i);
				nlapiDisableLineItemField('addressbook', 'label', i);
			}
		}
	}

}

function cust_LineInit_LockAddressFields(type) {

	if (type == 'addressbook') {
		var context = nlapiGetContext();
		var roleId = context.getRoleId();

		if (roleId != 'administrator' && roleId != 'sales_manager' && roleId != AM_CER && roleId != AM_CER_CUSTOMER_ENTRY_ACCESS && roleId != AM_SALES_MANAGER) {
			nlapiDisableLineItemField('addressbook', 'addressbookaddress', true);
		}
	}

}

function cust_ValidateLine_LockAddressFields(type) {
	if (type == 'addressbook') {
		var context = nlapiGetContext();
		var roleId = context.getRoleId();

		if (roleId != 'administrator' && roleId != 'sales_manager' && roleId != AM_CER && roleId != AM_CER_CUSTOMER_ENTRY_ACCESS && roleId != AM_SALES_MANAGER) {
			alert('You are unable to edit the address fields.');
			return false;
		} else {
			return true;
		}
	} else if (type != 'addressbook') {
		return true;
	}

}

function cust_ValidateInsert_LockAddressFields(type) {

	if (type == 'addressbook') {
		var context = nlapiGetContext();
		var roleId = context.getRoleId();

		if (roleId != 'administrator' && roleId != 'sales_manager' && roleId != AM_CER && roleId != AM_CER_CUSTOMER_ENTRY_ACCESS && roleId != AM_SALES_MANAGER) {
			alert('You are unable to add a new address.');
			return false;
		} else {
			return true;
		}
	} else if (type != 'addressbook') {
		return true;
	}

}

function cust_ValidateDelete_LockAddressFields(type) {

	if (type == 'addressbook') {
		var context = nlapiGetContext();
		var roleId = context.getRoleId();

		if (roleId != 'administrator' && roleId != 'sales_manager' && roleId != AM_CER && roleId != AM_CER_CUSTOMER_ENTRY_ACCESS && roleId != AM_SALES_MANAGER) {
			alert('You are unable to remove this address.');
			return false;
		} else {
			return true;
		}
	} else if (type != 'addressbook') {
		return true;
	}

}

function addrssForm_PageInit_LockAddressFields(type) {
	var context = nlapiGetContext();
	var roleId = context.getRoleId();
	var defaultShipping = nlapiGetFieldValue('defaultshipping');
	var defaultBilling = nlapiGetFieldValue('defaultbilling');

	if (defaultShipping == 'T' || defaultBilling == 'T') {//Address Form on Transactions
		nlapiDisableField('country', true);
		nlapiDisableField('attention', true);
		nlapiDisableField('addressee', true);
		nlapiDisableField('addrphone', true);
		nlapiDisableField('addr1', true);
		nlapiDisableField('addr2', true);
		nlapiDisableField('city', true);
		nlapiDisableField('state', true);
		nlapiDisableField('zip', true);
		nlapiDisableField('defaultshipping', true);
		nlapiDisableField('defaultbilling', true);
		nlapiDisableField('isresidential', true);
		nlapiDisableField('label', true);
		nlapiDisableField('override', true);
		nlapiDisableField('custrecord_save_address', true);

	} else if ((defaultShipping == null && defaultBilling == null) && (roleId != 'administrator' && roleId != 'sales_manager' && roleId != AM_CER && roleId != AM_CER_CUSTOMER_ENTRY_ACCESS && roleId != AM_SALES_MANAGER)) {
		//Address Form on Customer Record
		nlapiDisableField('country', true);
		nlapiDisableField('attention', true);
		nlapiDisableField('addressee', true);
		nlapiDisableField('addrphone', true);
		nlapiDisableField('addr1', true);
		nlapiDisableField('addr2', true);
		nlapiDisableField('city', true);
		nlapiDisableField('state', true);
		nlapiDisableField('zip', true);
		nlapiDisableField('defaultshipping', true);
		nlapiDisableField('defaultbilling', true);
		nlapiDisableField('isresidential', true);
		nlapiDisableField('label', true);
		nlapiDisableField('override', true);
		nlapiDisableField('custrecord_save_address', true);
	}

}

function addrssForm__SaveRecord_LockAddressFields() {
	var context = nlapiGetContext();
	var roleId = context.getRoleId();
	var defaultShipping = nlapiGetFieldValue('defaultshipping');
	var defaultBilling = nlapiGetFieldValue('defaultbilling');

	if (defaultShipping == 'T' || defaultBilling == 'T') {//Address Form on Transactions
		alert('You are unable to edit this address.');
		window.close();
		return false;
	} else if ((defaultShipping == null && defaultBilling == null) && (roleId != 'administrator' && roleId != 'sales_manager' && roleId != AM_CER && roleId != AM_CER_CUSTOMER_ENTRY_ACCESS && roleId != AM_SALES_MANAGER)) {
		//Address Form on Customer Record
		alert('You are unable to edit this address.');
		window.close();
		return false;
	} else {
		return true;
	}

}


/***********************************************************************
 *
 * The following javascript code is created by FMT Consultants LLC,
 * a NetSuite Partner. It is a SuiteFlex component containing custom code
 * intended for NetSuite (www.netsuite.com) and use the SuiteScript API.
 * The code is provided "as is": FMT Consultants LLC shall not be liable
 * for any damages arising out the intended use or if the code is modified
 * after delivery.
 *
 * Company:		FMT Consultants LLC, www.fmtconsultants.com
 * Author:		apoblete@fmtconsultants.com
 * File:        AM_CUE_LockAddressFields.js
 * Date:        5/3/2016
 *
 ***********************************************************************/

//Constants
var AM_SALES_MANAGER = 'customrole1011';
var AM_CER = 'customrole1005';
var AM_CER_CUSTOMER_ENTRY_ACCESS = 'customrole1021';
var ADMINISTRATOR = 'administrator';
var SALES_MANAGER = 'sales_manager';
var CUSTOMER = 'CUSTOMER';
var SALESCENTER = 'SALESCENTER';

var custCenterRoles = ['customrole14', 'customrole1030', 'customrole1029', 'customrole1027', 'customrole1025', 'customrole1028', 'customrole1026', 'customrole1013', 'customrole1004'];

/**
 * This function prevents the user from editing a line if their roles doesn't have permission to do so.
 * @param{string} type
 * @returns null
 */
function cust_PageInit_LockLines(type) {
    if (type == 'edit') {
        var context = nlapiGetContext();
        var roleId = context.getRoleId();
        var roleCenter = context.getRoleCenter();
        var recordID = nlapiGetRecordId();
        var recordType = nlapiGetRecordType();
        var record = nlapiLoadRecord(recordType, recordID);
        var totalLines = record.getLineItemCount('addressbook');

        if (roleId != ADMINISTRATOR && roleId != SALES_MANAGER && roleId != AM_CER && roleId != AM_CER_CUSTOMER_ENTRY_ACCESS && roleId != AM_SALES_MANAGER && custCenterRoles.indexOf(roleId) == -1 && roleCenter != CUSTOMER && roleCenter != SALESCENTER) {
            for (var i = 1; i <= totalLines; i++) {
                nlapiDisableLineItemField('addressbook', 'defaultshipping', i);
                nlapiDisableLineItemField('addressbook', 'defaultbilling', i);
                nlapiDisableLineItemField('addressbook', 'isresidential', i);
                nlapiDisableLineItemField('addressbook', 'label', i);
            }
        }
    }

}

/**
 * This function prevents the user from adding a line if their roles doesn't have permission to do so.
 * @param{string} type
 * @returns {boolean}
 */
function cust_ValidateLine_LockAddressFields(type) {
    if (type == 'addressbook') {
        var context = nlapiGetContext();
        var roleId = context.getRoleId();
        var roleCenter = context.getRoleCenter();

        if (roleId != ADMINISTRATOR && roleId != SALES_MANAGER && roleId != AM_CER && roleId != AM_CER_CUSTOMER_ENTRY_ACCESS && roleId != AM_SALES_MANAGER && custCenterRoles.indexOf(roleId) == -1 && roleCenter != CUSTOMER && roleCenter != SALESCENTER) {
            alert('You are unable to edit the address fields.');
            return false;
        } else {
            return true;
        }
    } else if (type != 'addressbook') {
        return true;
    }

}

/**
 * This function prevents the user from inserting a line if their roles doesn't have permission to do so.
 * @param{string} type
 * @returns {boolean}
 */
function cust_ValidateInsert_LockAddressFields(type) {

    if (type == 'addressbook') {
        var context = nlapiGetContext();
        var roleId = context.getRoleId();
        var roleCenter = context.getRoleCenter();

        if (roleId != ADMINISTRATOR && roleId != SALES_MANAGER && roleId != AM_CER && roleId != AM_CER_CUSTOMER_ENTRY_ACCESS && roleId != AM_SALES_MANAGER && custCenterRoles.indexOf(roleId) == -1 && roleCenter != CUSTOMER && roleCenter != SALESCENTER) {
            alert('You are unable to add a new address.');
            return false;
        } else {
            return true;
        }
    } else if (type != 'addressbook') {
        return true;
    }

}

/**
 * This function prevents the user from deleting a line if their roles doesn't have permission to do so.
 * @param{string} type
 * @returns {boolean}
 */
function cust_ValidateDelete_LockAddressFields(type) {

    if (type == 'addressbook') {
        var context = nlapiGetContext();
        var roleId = context.getRoleId();
        var roleCenter = context.getRoleCenter();

        if (roleId != ADMINISTRATOR && roleId != SALES_MANAGER && roleId != AM_CER && roleId != AM_CER_CUSTOMER_ENTRY_ACCESS && roleId != AM_SALES_MANAGER && custCenterRoles.indexOf(roleId) == -1 && roleCenter != CUSTOMER && roleCenter != SALESCENTER) {
            alert('You are unable to remove this address.');
            return false;
        } else {
            return true;
        }
    } else if (type != 'addressbook') {
        return true;
    }

}

/**
 * This function prevents the user from editing a default address on a transacation. It also prevents certain roles to edit addresses on the customer record.
 * @param null
 * @returns null
 */
function addrssForm_PageInit_LockAddressFields(type) {
    var context = nlapiGetContext();
    var roleId = context.getRoleId();
    var roleCenter = context.getRoleCenter();
    var defaultShipping = nlapiGetFieldValue('defaultshipping');
    var defaultBilling = nlapiGetFieldValue('defaultbilling');

    if (roleId != ADMINISTRATOR && roleId != SALES_MANAGER && roleId != AM_CER && roleId != AM_CER_CUSTOMER_ENTRY_ACCESS && roleId != AM_SALES_MANAGER && custCenterRoles.indexOf(roleId) == -1 && roleCenter != CUSTOMER && roleCenter != SALESCENTER) {
        //Address Form on Customer Record
        nlapiDisableField('country', true);
        nlapiDisableField('attention', true);
        nlapiDisableField('addressee', true);
        nlapiDisableField('addrphone', true);
        nlapiDisableField('addr1', true);
        nlapiDisableField('addr2', true);
        nlapiDisableField('city', true);
        nlapiDisableField('state', true);
        nlapiDisableField('zip', true);
        nlapiDisableField('defaultshipping', true);
        nlapiDisableField('defaultbilling', true);
        nlapiDisableField('isresidential', true);
        nlapiDisableField('label', true);
        nlapiDisableField('override', true);
        nlapiDisableField('custrecord_save_address', true);
    }

}

/**
 * This function prevents the user from saving a default address on a transaction. It also prevents certain roles from saving changes to an address.
 * @param null
 * @returns{boolean}
 */
function addrssForm__SaveRecord_LockAddressFields() {
    var context = nlapiGetContext();
    var roleId = context.getRoleId();
    var roleCenter = context.getRoleCenter();
    var defaultShipping = nlapiGetFieldValue('defaultshipping');
    var defaultBilling = nlapiGetFieldValue('defaultbilling');
    if (roleId != ADMINISTRATOR && roleId != SALES_MANAGER && roleId != AM_CER && roleId != AM_CER_CUSTOMER_ENTRY_ACCESS && roleId != AM_SALES_MANAGER && custCenterRoles.indexOf(roleId) == -1 && roleCenter != CUSTOMER && roleCenter != SALESCENTER) {
        //Address Form on Customer Record
        alert('You are unable to edit this address.');
        window.close();
        return false;
    } else {
        return true;
    }

}


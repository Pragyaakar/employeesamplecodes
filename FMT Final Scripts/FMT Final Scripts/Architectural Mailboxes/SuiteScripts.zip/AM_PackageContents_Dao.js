/***********************************************************************
 *
 * The following javascript code is created by FMT Consultants LLC,
 * a NetSuite Partner. It is a SuiteFlex component containing custom code
 * intended for NetSuite (www.netsuite.com) and use the SuiteScript API.
 * The code is provided "as is": FMT Consultants LLC shall not be liable
 * for any damages arising out the intended use or if the code is modified
 * after delivery.
 *
 * Company:     FMT Consultants LLC, www.fmtconsultants.com
 * Author:      smehmood@fmtconsultants.com
 * File:        AM_PackageContents_Dao.js
 * Date:        11/11/2017
 *
 ***********************************************************************/

var AMPackageContentsDao = (function () {
    return {
        Internalid: 'customrecordhj_tc_package_contents',
        Fields: {
            Pallet: {id: 'custrecordhj_pkg_pallet', source: 'custrecordhj_pkg_pallet'},
            Box: {id: 'custrecordhj_pkgbox', source: 'custrecordhj_pkgbox'},
            Lbs: {id: 'custrecordhj_tc_packagecontentslbs', source: 'custrecordhj_tc_packagecontentslbs'},
            UCC128: {id: 'custrecordhj_ucc', source: 'custrecordhj_ucc'},
            TrackingNumber: {id: 'custrecordhj_pkg_trackingnumber', source: 'custrecordhj_pkg_trackingnumber'},
            PackageContents: {id: 'custrecordhj_pkg_desc', source: 'custrecordhj_pkg_desc'},
            TransactionParentRef: {id: 'custrecord_hj_packagecontents_sublist', source: 'fulfillmentid'},
        },
        Sublist_Item: {
            id: 'recmachcustrecordhj_tc_pkgcont_lineitemparent',
            fields: {
                ItemInternalID: {
                    id: 'custrecordhj_tc_pkgcontents_lineitemiid',
                    source: 'custrecordhj_tc_pkgcontents_lineitemiid'
                },
                Item: {
                    id: 'custrecordhj_tc_pkgcontents_lineitemitem',
                    source: 'custrecordhj_tc_pkgcontents_lineitemitem'
                },
                ItemDescription: {id: 'custrecordhj_tc_pkgcontentslineitemdesc'},
                ItemName: {
                    id: 'custpagehj_tc_pkgcontentslineitemnumber',
                    source: 'custpagehj_tc_pkgcontentslineitemnumber'
                }, //Special Field Added by UE Script
                Quantity: {
                    id: 'custrecordhj_tc_pkgcontents_lineitemqty',
                    source: 'custrecordhj_tc_pkgcontents_lineitemqty'
                },
                ItemWeight: {id: 'custrecordhj_tc_pkgcontents_lineitemwt'},
                LotSerial: {id: 'custrecordhj_tc_pkgcontents_lineitemlot'},
                Parent: {id: 'custrecordhj_tc_pkgcont_lineitemparent'},
                ItemShipment: {id: 'custrecordhj_tc_pkgcont_grandparent'},
                QuantityRemaining: {id: 'custrecordhj_tc_pkgcontents_qtyremaining'},
                LotExpiration: {id: 'custrecordhj_tc_pkgcont_lineitm_exp_date'},
                LineNumber: {id: 'custrecordhj_tc_pkgcontents_linenumber'}
            }
        },
        //Get list of Package Contents  for a ItemFulfillment
        getList: function (itemFulfillment) {
            var recs = null;
            var filters = [];
            var cols = [];
            var result = [];
            if (!!itemFulfillment) {
                filters.push(new nlobjSearchFilter(this.Fields.TransactionParentRef.id, null, 'is', itemFulfillment));

                cols.push(new nlobjSearchColumn(this.Fields.Pallet.id));
                cols.push(new nlobjSearchColumn(this.Fields.Box.id));
                cols.push(new nlobjSearchColumn(this.Fields.Lbs.id));
                cols.push(new nlobjSearchColumn(this.Fields.UCC128.id));
                cols.push(new nlobjSearchColumn(this.Fields.TrackingNumber.id));
                cols.push(new nlobjSearchColumn(this.Fields.PackageContents.id));
                cols.push(new nlobjSearchColumn(this.Fields.TransactionParentRef.id));

                recs = nlapiSearchRecord(this.Internalid, null, filters, cols);

                if (!!recs && recs.length > 0) {
                    for (var i = 0; i < recs.length; i++) {
                        result.push({
                            id: recs[i].getId(),
                            pallet: recs[i].getValue(this.Fields.Pallet.id),
                            box: recs[i].getValue(this.Fields.Box.id),
                            lbs: recs[i].getValue(this.Fields.Lbs.id),
                            ucc128: recs[i].getValue(this.Fields.UCC128.id),
                            trackingNumber: recs[i].getValue(this.Fields.TrackingNumber.id),
                            packageContents: recs[i].getValue(this.Fields.PackageContents.id),
                            transactionParentRef: recs[i].getValue(this.Fields.TransactionParentRef.id)
                        });
                    }
                }
            }
            return result;
        },

        //Upsert function to create/update records
        upsert: function (dataObject) {
            var nsObject, existingLinesCount, id;

            if (!!dataObject) {
                if (!!dataObject.id) {
                    nsObject = nlapiLoadRecord(this.Internalid, dataObject.id);
                    existingLinesCount = nsObject.getLineItemCount(this.Sublist_Item.id);

                    for (var l = existingLinesCount; l > 0; l--) {
                        nsObject.removeLineItem(this.Sublist_Item.id, l);
                    }

                } else {
                    nsObject = nlapiCreateRecord(this.Internalid);
                }

                for (var f in this.Fields) {
                    if (!!this.Fields[f].source) {

                        nlapiLogExecution('debug', this.Fields[f].id + '  ' + this.Fields[f].source, dataObject[this.Fields[f].source]);

                        nsObject.setFieldValue(
                            this.Fields[f].id,
                            dataObject[this.Fields[f].source]
                        );
                    }
                }

                for (var s = 0; s < dataObject['lines'].length; s++) {
                    nsObject.selectNewLineItem(this.Sublist_Item.id);
                    for (var f in this.Sublist_Item.fields) {
                        if (!!this.Sublist_Item.fields[f].source) {
                            nlapiLogExecution('debug', this.Sublist_Item.fields[f].id + '  ' +
                                this.Sublist_Item.fields[f].source, dataObject['lines'][s][this.Sublist_Item.fields[f].source]);


                            nsObject.setCurrentLineItemValue(
                                this.Sublist_Item.id,
                                this.Sublist_Item.fields[f].id,
                                dataObject['lines'][s][this.Sublist_Item.fields[f].source]
                            );
                        }
                    }
                    nsObject.setCurrentLineItemValue(
                        this.Sublist_Item.id,
                        this.Sublist_Item.fields.LineNumber.id,
                        (s + 1)
                    );
                    nsObject.commitLineItem(this.Sublist_Item.id);
                }
                id = nlapiSubmitRecord(nsObject);
            } else {
                throw new nlapiCreateError('INVALID_DATA', 'Invalid Data Object to Create/Update record ' + this.Internalid);
            }
            return id;
        }
    };
})();
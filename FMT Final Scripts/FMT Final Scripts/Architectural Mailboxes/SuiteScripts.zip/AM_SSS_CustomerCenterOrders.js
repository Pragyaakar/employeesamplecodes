/***********************************************************************
 *
 * The following javascript code is created by FMT Consultants LLC,
 * a NetSuite Partner. It is a SuiteFlex component containing custom code
 * intended for NetSuite (www.netsuite.com) and use the SuiteScript API.
 * The code is provided "as is": FMT Consultants LLC shall not be liable
 * for any damages arising out the intended use or if the code is modified
 * after delivery.
 *
 * Company:		FMT Consultants LLC, www.fmtconsultants.com
 * Author:		apoblete@fmtconsultants.com
 * File:        AM_SSS_CustomerCenterOrders.js
 * Date:        10/13/2017
 *
 ***********************************************************************/
var IN_STOCK = true;
var NS_MAX_SEARCH_RESULT = 1000;
var SET_RECOVERY_POINT_METERING = 200;
/**
 * Trigger function which creates an item fulfillment if the all the items on the sales order are in in stock and the address is completed
 * @author apoblete@fmtconsultants.com
 * @param{string} type
 * @returns null
 */
function customerCenterOrders() {
    var approvedSalesOrders = getApprovedOrders();
    nlapiLogExecution('debug', 'approvedSalesOrders: ', approvedSalesOrders);

    if (approvedSalesOrders != null) {

        for (var i = 0; i < approvedSalesOrders.length; i++) {
            nlapiLogExecution('debug', 'i: ', i);
            var shidpAddr = approvedSalesOrders[i].getValue('shipaddress');
            nlapiLogExecution('debug', 'shidpAddr: ', shidpAddr);
            var billAddr = approvedSalesOrders[i].getValue('billaddress');
            nlapiLogExecution('debug', 'billAddr: ', billAddr);
            var id = approvedSalesOrders[i].getValue('internalid');
            nlapiLogExecution('debug', 'id: ', id);
            var so = nlapiLoadRecord('salesorder', id);
            nlapiLogExecution('debug', 'so: ', so);

            if (shidpAddr != null && shidpAddr != '' && billAddr != null && billAddr != '') {
                var totalLines = so.getLineItemCount('item');
                nlapiLogExecution('debug', 'totalLines: ', totalLines);
                for (var i = 1; i <= totalLines; i++) {
                    var backOrdered = so.getLineItemValue('item', 'quantitybackordered', i);
                    nlapiLogExecution('debug', 'backOrdered: ', backOrdered);
                    if (backOrdered > 0) {
                        IN_STOCK = false;
                        break;
                    }

                }

                if (IN_STOCK) {
                    var fulfillment = nlapiTransformRecord('salesorder', id, 'itemfulfillment', null);
                    nlapiSubmitRecord(fulfillment);
                }
            }

            // If we dont have enough usage to process one more record we yield
            //the script to continue in a new execution where we left off
            // if (nlapiGetContext().getRemainingUsage() < 75 + SET_RECOVERY_POINT_METERING) {
            //   setRecoveryPoint();
            //   yieldScript();
            //}
        }
    }

}

function getApprovedOrders() {

    var approvedSalesOrders = nlapiSearchRecord("salesorder", null, [["type", "anyof", "SalesOrd"], "AND", ["status", "anyof", "SalesOrd:B"], "AND", ["mainline", "is", "T"], "AND", ["source", "anyof", "webServices"]], [new nlobjSearchColumn("mainline", null, null), new nlobjSearchColumn("internalid", null, null), new nlobjSearchColumn("shipaddress", null, null), new nlobjSearchColumn("billaddress", null, null)]);
    if (approvedSalesOrders != null && approvedSalesOrders.length > 0) {
        return approvedSalesOrders;
    } else {
        return null;
    }
}

/**
 * yieldScript : Calls the API to yield the current script (equivalent to reschedule basically).
 * Logs information depending on returned state.
 *
 * @author frederic.jannelle@erpguru.com
 */
function yieldScript() {
    var state = nlapiYieldScript();
    if (state.status == 'FAILURE') {
        nlapiLogExecution("ERROR", "Failed to yield script, exiting: Reason = " + state.reason + " / Size = " + state.size);
        throw "Failed to yield script";
    } else if (state.status == 'RESUME') {
        nlapiLogExecution("AUDIT", "Resuming script because of " + state.reason + ".  Size = " + state.size);
    }
    // state.status will never be SUCCESS because a success would imply a yield has occurred.  The equivalent response would be yield
}

/**
 * setRecoveryPoint : Calls the API to resume the execution of the scheduled script execution
 * exactly where it left off before the interruption.
 *
 * @author ibudimir@fmtconsultants.com
 */

function setRecoveryPoint() {
    var state = nlapiSetRecoveryPoint();
    //100 point governance
    if (state.status == 'SUCCESS') {
        return;
    }//we successfully create a new recovery point
    if (state.status == 'RESUME') {//a recovery point was previously set, we are resuming due to some unforeseen error
        nlapiLogExecution("ERROR", "Resuming script because of " + state.reason + ".  Size = " + state.size);
    } else if (state.status == 'FAILURE') {//we failed to create a new recovery point
        nlapiLogExecution("ERROR", "Failed to create recovery point. Reason = " + state.reason + " / Size = " + state.size);
    }
}


function renderInlinePDF(request, response) {

    var itmfulID = request.getParameter('itmfulID');
    var itemFulfillment = nlapiLoadRecord('itemfulfillment', itmfulID);
    var createdFrom = itemFulfillment.getFieldText('createdfrom');
    var template = '462';
    //default template
    nlapiLogExecution('error', 'string', createdFrom);
    nlapiLogExecution('error', 'templatebeforeloop', template);
    if (createdFrom.indexOf('Sales') != -1) {
        var customerId = itemFulfillment.getFieldValue('entity');
        var customer = nlapiLoadRecord('customer', customerId);

        if (customer.getFieldValue('custentity_custom_packing_slip_template') != null) {
            template = customer.getFieldValue('custentity_custom_packing_slip_template');
        }
        itemFulfillment.setFieldValue('custbody_custom_packing_slip_template', template);

        nlapiLogExecution('error', 'customerid', customerId);
        nlapiLogExecution('error', 'customer', customer);
        nlapiLogExecution('error', 'template', template);

    }

    nlapiLogExecution('error', 'templateafterloop', template);

    var file = nlapiLoadFile(template);
    //load HTML file
    var contents = file.getValue();
    //get the contents

    var renderer = nlapiCreateTemplateRenderer();
    renderer.setTemplate(contents);
    renderer.addRecord('record', itemFulfillment);
    var xml = renderer.renderToString();
    var file = nlapiXMLToPDF(xml);
    response.setContentType('PDF', itemFulfillment.getFieldValue('tranid') + '.pdf', 'inline');
    response.write(file.getValue());
}
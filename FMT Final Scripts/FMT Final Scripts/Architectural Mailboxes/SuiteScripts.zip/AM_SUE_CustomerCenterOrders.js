/***********************************************************************
 *
 * The following javascript code is created by FMT Consultants LLC,
 * a NetSuite Partner. It is a SuiteFlex component containing custom code
 * intended for NetSuite (www.netsuite.com) and use the SuiteScript API.
 * The code is provided "as is": FMT Consultants LLC shall not be liable
 * for any damages arising out the intended use or if the code is modified
 * after delivery.
 *
 * Company:		FMT Consultants LLC, www.fmtconsultants.com
 * Author:		apoblete@fmtconsultants.com
 * File:        AM_SUE_CustomerCenterOrders.js
 * Date:        10/13/2017
 *
 ***********************************************************************/
var APPROVED_PENDING_FULFILLMENT = 'B';
var IN_STOCK = true;
/**
 * Trigger function which creates an item fulfillment if the all the items on the sales order are in in stock and the address is completed
 * @author apoblete@fmtconsultants.com
 * @param{string} type
 * @returns null
 */
function afterSubmit_CustomerCenterOrders(type) {
    var id = nlapiGetRecordId();
    var so = nlapiLoadRecord('salesorder', id);
    var status = so.getFieldValue('orderstatus');
    var source = so.getFieldValue('source');
    if (status == APPROVED_PENDING_FULFILLMENT && source == 'Web Services') {
        var shidpAddr = so.getFieldValue('shipaddress');
        var billAddr = so.getFieldValue('billaddress');

        if (shidpAddr != null && shidpAddr != '' && billAddr != null && billAddr != '') {
            var totalLines = so.getLineItemCount('item');
            for (var i = 1; i <= totalLines; i++) {
                var backOrdered = so.getLineItemValue('item', 'quantitybackordered', i);
                if (backOrdered > 0) {
                    IN_STOCK = false;
                    break;
                }

            }
            
            if (IN_STOCK){
                var fulfillment = nlapiTransformRecord('salesorder', id, 'itemfulfillment', null);
                nlapiSubmitRecord(fulfillment);
            }           
        }

    }

}


/***********************************************************************
 *
 * The following javascript code is created by FMT Consultants LLC,
 * a NetSuite Partner. It is a SuiteFlex component containing custom code
 * intended for NetSuite (www.netsuite.com) and use the SuiteScript API.
 * The code is provided "as is": FMT Consultants LLC shall not be liable
 * for any damages arising out the intended use or if the code is modified
 * after delivery.
 *
 * Company:     FMT Consultants LLC, www.fmtconsultants.com
 * Author:      apoblete@fmtconsultants.com
 * File:        AM_SUE_CustomerCenterRoles.js
 * Date:        2/18/2016
 * Updated:		7/8/2016 - updated logic to only fire the after submit
 *						script based on RoleCenter type instead of 
 *						specific roleid. MAJ
 *
 ***********************************************************************/

/**
 * Trigger function that iterates through each line and grabs the item ID to pass
 * to searchItemRecord()
 * @author apoblete@fmtconsultants.com
 * @param{string} type
 * @returns null
 */
function afterSubmit_popClassLocation(type) {
    var context = nlapiGetContext();
    var roleCenter = context.getRoleCenter();

	if (roleCenter == 'CUSTOMER') { // check if order was submitted from customer center

		try {
			//Constants
			var recordID = nlapiGetRecordId();
			var recordType = nlapiGetRecordType();
			var record = nlapiLoadRecord(recordType, recordID);
			var totalLines = record.getLineItemCount('item');
			var item;
			nlapiLogExecution('debug', 'lines', totalLines);
			for (var i = 1; i <= totalLines; i++) {
				item = record.getLineItemValue('item', 'item', i);
				nlapiLogExecution('debug', 'item', item);
				searchItemRecord(record, item, i);
			}

			var id = nlapiSubmitRecord(record);

		} catch(err) {
			nlapiLogExecution('error', 'The script encountered an error', err.toString());
		}
	}
}

/**
 * Function that searches the item record for items that the customer ordered and
 * populates the class and location column for those items
 * @param{object} record
 * @param{integer} item
 * @param{integer} lineNum
 * @returns null
 */
function searchItemRecord(record, item, lineNum) {

    var filter = new Array();
    filter[0] = new nlobjSearchFilter('internalidnumber', null, 'equalto', item);

    var column = new Array();
    column[0] = new nlobjSearchColumn('class');
    column[1] = new nlobjSearchColumn('preferredlocation');
	column[2] = new nlobjSearchColumn('location');
	column[3] = new nlobjSearchColumn('type');
	
    var searchResults = nlapiSearchRecord('item', null, filter, column);
    var itemClass = searchResults[0].getValue('class');
    
	if (searchResults[0].getValue('type') == 'InvtPart'){
		var itemLocation = searchResults[0].getValue('preferredlocation');
	} else {
		var itemLocation = searchResults[0].getValue('location');	
	}

    if (searchResults != null && searchResults.length > 0) {
        nlapiLogExecution('debug', 'class', itemClass);
        nlapiLogExecution('debug', 'location', itemLocation);
        record.setLineItemValue('item', 'class', lineNum, itemClass);
        record.setLineItemValue('item', 'location', lineNum, itemLocation);
    }
}


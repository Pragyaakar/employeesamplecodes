/***********************************************************************
 *
 * The following javascript code is created by FMT Consultants LLC,
 * a NetSuite Partner. It is a SuiteFlex component containing custom code
 * intended for NetSuite (www.netsuite.com) and use the SuiteScript API.
 * The code is provided "as is": FMT Consultants LLC shall not be liable
 * for any damages arising out the intended use or if the code is modified
 * after delivery.
 *
 * Company:     FMT Consultants LLC, www.fmtconsultants.com
 * Author:      apoblete@fmtconsultants.com
 * File:        AM_SUE_CustomerSKU.js
 * Date:        2/15/2016
 *
 ***********************************************************************/

/**
 * Trigger function that stores each item in an array and calls searchCustomRecord
 * @author apoblete@fmtconsultants.com
 * @param{string} type
 * @returns null
 */
function afterSubmit_popCustomerSKU(type) {
    try {
        var recordID = nlapiGetRecordId();
        var recordType = nlapiGetRecordType();
        var record = nlapiLoadRecord(recordType, recordID);
        var customerId = record.getFieldValue('entity');
        var totalLines = record.getLineItemCount('item');
        var soItems = new Array();

        for (var i = 1; i <= totalLines; i++) {
            record.setLineItemValue('item', 'custcol_customeritem_sku', i, null);
            soItems[i] = record.getLineItemValue('item', 'item', i);
        }

        searchCustomRecord(record, customerId, soItems);
        var id = nlapiSubmitRecord(record);

    } catch(err) {
        nlapiLogExecution('error', 'The script encountered an error', err.toString());
    }

}

/**
 * Function that iterates through each line and populates the Customer SKU column
 * if one exists for that item.
 * @param{object} record
 * @param{integer} customerId
 * @param{array} items
 * @returns null
 */
function searchCustomRecord(record, customerId, items) {
    var filter = new Array();
    filter[0] = new nlobjSearchFilter('custrecord_customeritem_customer', null, 'anyof', customerId);
    filter[1] = new nlobjSearchFilter('custrecord_customeritem_item', null, 'anyof', items);

    var column = new Array();
    column[0] = new nlobjSearchColumn('custrecord_customeritem_item');
    column[1] = new nlobjSearchColumn('custrecord_customeritem_sku');

    var searchResults = nlapiSearchRecord('customrecord_customeritem', null, filter, column);

    if (searchResults != null && searchResults.length > 0) {
        for (var i = 1; i <= items.length; i++) {
            var customRecItem = record.getLineItemValue('item', 'item', i);
            for (var j = 0; j < searchResults.length; j++) {
                var customerSku = searchResults[j].getValue('custrecord_customeritem_sku');
                if (searchResults[j].getValue('custrecord_customeritem_item') == customRecItem) {
                    nlapiLogExecution('debug', 'itemsku', customerSku);
                    var custSkuColumn = record.getLineItemValue('item', 'custcol_customeritem_sku', i);
                    if (custSkuColumn == '' || custSkuColumn == null) {
                        record.setLineItemValue('item', 'custcol_customeritem_sku', i, customerSku);
                        break;
                    }
                }
            }
        }
    }
}
/*
 ***********************************************************************
 *
 * The following javascript code is created by FMT Consultants LLC,
 * a NetSuite Partner. It is a SuiteFlex component containing custom code
 * intended for NetSuite (www.netsuite.com) and use the SuiteScript API.
 * The code is provided "as is": FMT Consultants LLC shall not be liable
 * for any damages arising out the intended use or if the code is modified
 * after delivery.
 *
 * Company:		FMT Consultants LLC, www.fmtconsultants.com
 * Author:		ibudimir@fmtconsultants.com
 * File:		AM_SUE_GetUdf.js
 * Date:        01/25/2018
 *
 * NetSuite Script to populate same field from Item Fulfillment to Invoice
 *
 * This script was created because the client needed values that are entered
 * onto the item fulfillment field to be on the invoice as well. In this case
 * the field {custbodyhj_tc_udf5} is a custom field on the sales order, item fulfillment, and invoice.
 *
 * When users ship the order, they enter a value in this field on the item fulfillment. Once the sales order is invoiced,
 * this value will carry over to the invoice in the same field.
 * This script is triggered when a new invoice is created from a sales order and when an existing invoice is edited and saved.
 *
 * USER EVENT script triggered on Before Submit
 *
 * Revisions:
 * 01/25/2018 | Rewrote function found in SuiteAnswers
 *
 ***********************************************************************/

var SCRIPT_ID = 'AM_SUE_GetUdf.js';

/**
 * This function transfers the value in {custbodyhj_tc_udf5} field from Item Fulfillment to
 * Invoice / Cash Sale.
 *
 * @author ibudimir@fmtconsultants.com
 * @param {string} type
 * @return null
 */
function getUdf(type) {
    if (type != 'create' && type != 'edit') {
        return;
    }
    try {
        var salesOrder = nlapiGetFieldValue('createdfrom');
        if (!isEmpty(salesOrder)) {
            //find item fulfillment
            var filters = [];
            filters.push(new nlobjSearchFilter('type', null, 'anyof', 'ItemShip'));
            filters.push(new nlobjSearchFilter("createdfrom", null, "anyof", salesOrder));
            filters.push(new nlobjSearchFilter("mainline", null, "is", "T"));

            var itemfulfillmentSearch = nlapiSearchRecord("transaction", null, filters, null);
            if (!isEmpty(itemfulfillmentSearch)) {
                var itemfulfillmentId = itemfulfillmentSearch[0].getId();

                if (!isEmpty(itemfulfillmentId)) {
                    var vals = nlapiLookupField('itemfulfillment', itemfulfillmentId,
                        ['custbodyhj_tc_udf5', 'custbodyhj_tc_udf3', 'custbodyhj_tc_udf4', 'custbody_release_number']);

                    nlapiSetFieldValue('custbodyhj_tc_udf5', vals.custbodyhj_tc_udf5);
                    nlapiSetFieldValue('custbodyhj_tc_udf3', vals.custbodyhj_tc_udf3);
                    nlapiSetFieldValue('custbodyhj_tc_udf4', vals.custbodyhj_tc_udf4);
                    nlapiSetFieldValue('custbody_release_number', vals.custbody_release_number);
                    
                    nlapiLogExecution('debug', 'UDF fields setting field set.');
                }
            }
        }
    } catch (err) {
        nlapiLogExecution('error', 'Script ' + SCRIPT_ID + ' failed. Reason: ' + err.toString());
    }
}

/**
 * Return True/False if a value is empty
 *
 * @param : {String} val
 * @return : {Boolean} True/False
 * @author : elean.olguin@gmail.com
 */
function isEmpty(val) {
    return (val == null || val == '') ? true : false;
}

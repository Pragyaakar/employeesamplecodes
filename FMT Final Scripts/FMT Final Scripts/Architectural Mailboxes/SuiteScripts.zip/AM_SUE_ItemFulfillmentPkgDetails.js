/***********************************************************************
 *
 * The following javascript code is created by FMT Consultants LLC,
 * a NetSuite Partner. It is a SuiteFlex component containing custom code
 * intended for NetSuite (www.netsuite.com) and use the SuiteScript API.
 * The code is provided "as is": FMT Consultants LLC shall not be liable
 * for any damages arising out the intended use or if the code is modified
 * after delivery.
 *
 * Company:     FMT Consultants LLC, www.fmtconsultants.com
 * Author:      smehmood@fmtconsultants.com
 * File:        AM_SUE_ItemFulfillmentPkgDetails.js
 * Date:        2/28/2017
 * Change : Changes done in November 2019, Deployed to Production on December 10 2019 , Added code to generate package details
 *
 ***********************************************************************/
var AMSUEItemFulfillmentPkgDetails = (function () {
    return {
        ERROR_MESSAGES: {},
        PACKAGE_DETAILS_SUBLIST: {
            id: 'recmachcustrecord_hj_packagecontents_sublist',
            fields: {
                Pallet: 'custrecordhj_pkg_pallet', Box: 'custrecordhj_pkgbox',
                Lbs: 'custrecordhj_tc_packagecontentslbs', Ucc128: 'custrecordhj_ucc',
                PackageContents: 'custrecordhj_pkg_desc', TrackingNumber: 'custrecordhj_pkg_trackingnumber'
            }

        },
        allowedLocations: ['7'], // CWH
        afterSubmit: function (type) {
            try {
                nlapiLogExecution('debug', 'type', type);

                if ((type == 'create' || type == 'edit' || type == 'pack')) {
                    var fulfillmentId = nlapiGetRecordId();
                    var fRec = nlapiLoadRecord(nlapiGetRecordType(), nlapiGetRecordId());
                    var location = fRec.getLineItemValue('item', 'location', 1);
                    var shipStatus = fRec.getFieldValue('shipstatus');
                    nlapiLogExecution('debug', 'type', type);
                    nlapiLogExecution('debug', 'shipStatus', shipStatus);

                    if (this.allowedLocations.indexOf(location) === -1) {
                        nlapiLogExecution('debug', 'Invalid Location');
                        return;
                    }

                    if (shipStatus != "B") {
                        nlapiLogExecution('debug', 'Script stopped due to ship status other than Packed');
                        return;
                    }
                    //Prepare Values
                    var pallet = '';
                    var box = 1;
                    //var lbs = fRec.getFieldValue('shipmentweightups');
                    var lbs;
                    var ucc128 = '';
                    var packageContents = '';
                    var packageDescription;
                    var packageShortDescription;
                    var packageVeryShortDescription;
                    var trackingNumber;
                    var packageContRecs;

                    var stdPkgInfo = this.getStandardPackageInfo(fRec);
                    var packageContentsCollection = this.getPackageContents(stdPkgInfo, fRec);
                    packageContRecs = AMPackageContentsDao.getList(fulfillmentId);
                    nlapiLogExecution('debug', 'packageContentsCollection', JSON.stringify(packageContentsCollection));
                    //=========================Populate Package Details Start===============================
                    if (!!stdPkgInfo && !!packageContentsCollection && packageContentsCollection.length > 0) {
                        for (var p = 1; p <= stdPkgInfo.count; p++) {
                            var trackingNumber = fRec.getLineItemValue(stdPkgInfo.listName, 'packagetrackingnumber' + stdPkgInfo.fieldSuffix, p);
                            var packageDataObject = {}, pcDetailObj = {};
                            nlapiLogExecution('debug', 'trackingNumber', trackingNumber);
                            var existingPkgId = this.getExistingPackageByTrackingNumber(packageContRecs, trackingNumber);
                            nlapiLogExecution('debug', 'existingPkgId', existingPkgId);
                            lbs = fRec.getLineItemValue(stdPkgInfo.listName, 'packageweight' + stdPkgInfo.fieldSuffix, p);

                            if (!!packageContentsCollection[p - 1]) {
                                if (packageContentsCollection[p - 1].packageDescription.length <= 300)
                                    packageContents = packageContentsCollection[p - 1].packageDescription;
                                else if (packageContentsCollection[p - 1].packageShortDescription.length <= 300)
                                    packageContents = packageContentsCollection[p - 1].packageShortDescription;
                                else {
                                    if (packageContentsCollection[p - 1].packageVeryShortDescription.length <= 300)
                                        packageContents = packageContentsCollection[p - 1].packageVeryShortDescription;
                                    else
                                        packageContents = packageContentsCollection[p - 1].packageVeryShortDescription.substring(0, 299);
                                }
                            }

                            nlapiLogExecution('debug', 'packageContents', packageContents);

                            packageDataObject['id'] = existingPkgId;
                            packageDataObject['fulfillmentid'] = fulfillmentId;

                            packageDataObject[AMPackageContentsDao.Fields.UCC128.id] = ucc128;
                            packageDataObject[AMPackageContentsDao.Fields.Pallet.id] = '';

                            packageDataObject[AMPackageContentsDao.Fields.Box.id] = p;
                            if (!!lbs)
                                packageDataObject[AMPackageContentsDao.Fields.Lbs.id] = lbs;
                            if (packageContents)
                                packageDataObject[AMPackageContentsDao.Fields.PackageContents.id] = packageContents;
                            if (!!trackingNumber)
                                packageDataObject[AMPackageContentsDao.Fields.TrackingNumber.id] = trackingNumber;

                            packageDataObject['lines'] = [];
                            for (var l = 0; l < packageContentsCollection[p - 1].lines.length; l++) {
                                pcDetailObj = {};
                                pcDetailObj[AMPackageContentsDao.Sublist_Item.fields.ItemInternalID.id] = packageContentsCollection[p - 1].lines[l]
                                    [AMPackageContentsDao.Sublist_Item.fields.ItemInternalID.id];
                                pcDetailObj[AMPackageContentsDao.Sublist_Item.fields.Item.id] = packageContentsCollection[p - 1].lines[l]
                                    [AMPackageContentsDao.Sublist_Item.fields.Item.id];
                                pcDetailObj[AMPackageContentsDao.Sublist_Item.fields.Quantity.id] = packageContentsCollection[p - 1].lines[l]
                                    [AMPackageContentsDao.Sublist_Item.fields.Quantity.id];
                                packageDataObject['lines'].push(pcDetailObj);
                            }

                            AMPackageContentsDao.upsert(packageDataObject);

                        }
                        //=========================Populate Package Details End===============================

                        nlapiSubmitRecord(fRec);
                    } else {
                        nlapiLogExecution('debug', 'Invalid Location');
                    }
                }
            } catch (ex) {
                nlapiLogExecution('error', 'error in aftersubmit (AM_SUE_ItemFulfillmentPkgDetails.js)', ex.toString());
            }
        },
        getExistingPackageByTrackingNumber: function (packageArray, trackingNumber) {
            var pkgId = null;
            if (!!packageArray && !!trackingNumber) {
                for (var p = 0; p < packageArray.length; p++) {
                    if (packageArray[p].trackingNumber == trackingNumber) {
                        pkgId = packageArray[p].id;
                        break;
                    }
                }
            }
            return pkgId;
        },
        getStandardPackageInfo: function (fRec) {
            var infoObject = {};
            if (fRec.getLineItemCount('package') > 0) {
                infoObject.listName = 'package';
                infoObject.fieldSuffix = '';
                infoObject.count = fRec.getLineItemCount('package');
            } else if (fRec.getLineItemCount('packageups') > 0) {
                infoObject.listName = 'packageups';
                infoObject.fieldSuffix = 'ups';
                infoObject.count = fRec.getLineItemCount('packageups');
            }
            else if (fRec.getLineItemCount('packagefedex') > 0) {
                infoObject.listName = 'packagefedex';
                infoObject.fieldSuffix = 'fedex';
                infoObject.count = fRec.getLineItemCount('packagefedex');
            }
            else if (fRec.getLineItemCount('packageusps') > 0) {
                infoObject.listName = 'packageusps';
                infoObject.fieldSuffix = 'usps';
                infoObject.count = fRec.getLineItemCount('packageusps');
            }
            return infoObject;
        },
        getPackageContents: function (stdPkgInfo, fRec) {
            var pkgDetailCollection = [];
            if (!!stdPkgInfo) {

                var itemCount = fRec.getLineItemCount('item');
                var pkDetailMaxLength = Math.ceil(itemCount / stdPkgInfo.count);
                var pkDetailCounter = 0;
                var packageDescription = '';
                var packageShortDescription = '';
                var packageVeryShortDescription = '';
                var dataToSave = true
                var pkgLineObject = {};
                var pkgLines = [];
                var item, itemShortName, itemName, itemQty;


                for (var i = 1; i <= itemCount; i++) {
                    item = fRec.getLineItemValue('item', 'item', i);
                    itemShortName = fRec.getLineItemText('item', 'item', i);
                    itemName = itemShortName + " / " + fRec.getLineItemValue('item', 'description', i);
                    itemQty = fRec.getLineItemValue('item', 'quantity', i);

                    pkDetailCounter++;

                    packageDescription += (packageDescription.length > 0 ? ", " : "") + itemName + "(" + itemQty + ")";
                    packageShortDescription += (packageShortDescription.length > 0 ? ", " : "") + itemShortName + "(" + itemQty + ")";
                    packageVeryShortDescription += (packageVeryShortDescription.length > 0 ? ", " : "") + itemShortName;
                    dataToSave = true;

                    pkgLineObject = {};
                    pkgLineObject[AMPackageContentsDao.Sublist_Item.fields.ItemInternalID.id] = item;
                    pkgLineObject[AMPackageContentsDao.Sublist_Item.fields.Item.id] = item;
                    pkgLineObject[AMPackageContentsDao.Sublist_Item.fields.Quantity.id] = itemQty;
                    pkgLines.push(pkgLineObject);

                    if (pkDetailCounter === pkDetailMaxLength) {
                        pkgDetailCollection.push({
                                packageDescription: packageDescription,
                                packageShortDescription: packageShortDescription,
                                packageVeryShortDescription: packageVeryShortDescription,
                                lines: pkgLines
                            }
                        );
                        packageDescription = '';
                        packageShortDescription = '';
                        packageVeryShortDescription = '';
                        dataToSave = false;
                    }
                }

                nlapiLogExecution('debug', 'pkgLines', JSON.stringify(pkgLines));

                if (dataToSave) {
                    pkgDetailCollection.push({
                            packageDescription: packageDescription,
                            packageShortDescription: packageShortDescription,
                            packageVeryShortDescription: packageVeryShortDescription,
                            lines: pkgLines
                        }
                    );
                }
            }
            return pkgDetailCollection;
        }
    };
})();
function afterSubmit(type) {
    return AMSUEItemFulfillmentPkgDetails.afterSubmit(type);
}
/***********************************************************************
 *
 * The following javascript code is created by FMT Consultants LLC,
 * a NetSuite Partner. It is a SuiteFlex component containing custom code
 * intended for NetSuite (www.netsuite.com) and use the SuiteScript API.
 * The code is provided "as is": FMT Consultants LLC shall not be liable
 * for any damages arising out the intended use or if the code is modified
 * after delivery.
 *
 * Company:     FMT Consultants LLC, www.fmtconsultants.com
 * Author:      smehmood@fmtconsultants.com
 * File:        AM_SUE_ItemFulfillmentPkgDetails.js
 * Date:        2/28/2017
 *
 ***********************************************************************/
var AMSUEItemFulfillmentPkgDetails = (function () {
    return {
        ERROR_MESSAGES: {},
        PACKAGE_DETAILS_SUBLIST: {
            id: 'recmachcustrecord_hj_packagecontents_sublist',
            fields: {
                Pallet: 'custrecordhj_pkg_pallet', Box: 'custrecordhj_pkgbox',
                Lbs: 'custrecordhj_tc_packagecontentslbs', Ucc128: 'custrecordhj_ucc',
                PackageContents: 'custrecordhj_pkg_desc', TrackingNumber: 'custrecordhj_pkg_trackingnumber'
            }

        },
        allowedLocations: ['7'], // CWH
        afterSubmit: function (type) {
            nlapiLogExecution('debug', 'type', type);

            if ((type == 'create' || type == 'edit')) {
                var fRec = nlapiLoadRecord(nlapiGetRecordType(), nlapiGetRecordId());
                var location = fRec.getLineItemValue('item', 'location', 1);
                if (this.allowedLocations.indexOf(location) === -1) {
                    nlapiLogExecution('debug', 'Invalid Location');
                    return;
                }
                //Prepare Values
                var pallet = '';
                var box = 1;
                //var lbs = fRec.getFieldValue('shipmentweightups');
                var lbs;
                var ucc128 = '';
                var packageContents = '';
                var packageDescription;
                var packageShortDescription;
                var packageVeryShortDescription;
                var trackingNumber;

                var stdPkgInfo = this.getStandardPackageInfo(fRec);
                var packageContentsCollection = this.getPackageContents(stdPkgInfo, fRec);

                //=========================Populate Package Details Start===============================
                if (!!stdPkgInfo && !!packageContentsCollection && packageContentsCollection.length > 0) {
                    for (var p = 1; p <= stdPkgInfo.count; p++) {
                        var trackingNumber = fRec.getLineItemValue(stdPkgInfo.listName, 'packagetrackingnumber' + stdPkgInfo.fieldSuffix, p);
                        //Add /Edit Lines
                        var existingIndex = fRec.findLineItemValue(this.PACKAGE_DETAILS_SUBLIST.id, this.PACKAGE_DETAILS_SUBLIST.fields.TrackingNumber, trackingNumber);
                        lbs = fRec.getLineItemValue(stdPkgInfo.listName, 'packageweight' + stdPkgInfo.fieldSuffix, p);

                        if (existingIndex === -1) {
                            fRec.selectNewLineItem(this.PACKAGE_DETAILS_SUBLIST.id);
                        } else {
                            fRec.selectLineItem(this.PACKAGE_DETAILS_SUBLIST.id, existingIndex);
                        }

                        if (!!packageContentsCollection[p - 1]) {
                            if (packageContentsCollection[p - 1].packageDescription.length <= 300)
                                packageContents = packageContentsCollection[p - 1].packageDescription;
                            else if (packageContentsCollection[p - 1].packageShortDescription.length <= 300)
                                packageContents = packageContentsCollection[p - 1].packageShortDescription;
                            else {
                                if (packageContentsCollection[p - 1].packageVeryShortDescription.length <= 300)
                                    packageContents = packageContentsCollection[p - 1].packageVeryShortDescription;
                                else
                                    packageContents = packageContentsCollection[p - 1].packageVeryShortDescription.substring(0, 299);
                            }
                        }

                        fRec.setCurrentLineItemValue(this.PACKAGE_DETAILS_SUBLIST.id, this.PACKAGE_DETAILS_SUBLIST.fields.Box, p);

                        if (!!lbs)
                            fRec.setCurrentLineItemValue(this.PACKAGE_DETAILS_SUBLIST.id, this.PACKAGE_DETAILS_SUBLIST.fields.Lbs, lbs);
                        if (!!ucc128)
                            fRec.setCurrentLineItemValue(this.PACKAGE_DETAILS_SUBLIST.id, this.PACKAGE_DETAILS_SUBLIST.fields.Ucc128, ucc128);
                        if (packageContents)
                            fRec.setCurrentLineItemValue(this.PACKAGE_DETAILS_SUBLIST.id, this.PACKAGE_DETAILS_SUBLIST.fields.PackageContents, packageContents);
                        if (!!trackingNumber)
                            fRec.setCurrentLineItemValue(this.PACKAGE_DETAILS_SUBLIST.id, this.PACKAGE_DETAILS_SUBLIST.fields.TrackingNumber, trackingNumber);

                        fRec.commitLineItem(this.PACKAGE_DETAILS_SUBLIST.id);
                    }
                    //=========================Populate Package Details End===============================

                    nlapiSubmitRecord(fRec);
                } else {
                    nlapiLogExecution('debug', 'Invalid Location');
                }
            }
        },
        getStandardPackageInfo: function (fRec) {
            var infoObject = {};
            if (fRec.getLineItemCount('package') > 0) {
                infoObject.listName = 'package';
                infoObject.fieldSuffix = '';
                infoObject.count = fRec.getLineItemCount('package');
            } else if (fRec.getLineItemCount('packageups') > 0) {
                infoObject.listName = 'packageups';
                infoObject.fieldSuffix = 'ups';
                infoObject.count = fRec.getLineItemCount('packageups');
            }
            else if (fRec.getLineItemCount('packagefedex') > 0) {
                infoObject.listName = 'packagefedex';
                infoObject.fieldSuffix = 'fedex';
                infoObject.count = fRec.getLineItemCount('packagefedex');
            }
            else if (fRec.getLineItemCount('packageusps') > 0) {
                infoObject.listName = 'packageusps';
                infoObject.fieldSuffix = 'usps';
                infoObject.count = fRec.getLineItemCount('packageusps');
            }
            return infoObject;
        },
        getPackageContents: function (stdPkgInfo, fRec) {
            var pkgDetailCollection = [];
            if (!!stdPkgInfo) {

                var itemCount = fRec.getLineItemCount('item');
                var pkDetailMaxLength = Math.ceil(itemCount / stdPkgInfo.count);
                var pkDetailCounter = 0;
                var packageDescription = '';
                var packageShortDescription = '';
                var packageVeryShortDescription = '';
                var dataToSave = true;


                for (var i = 1; i <= itemCount; i++) {
                    var itemShortName = fRec.getLineItemText('item', 'item', i);
                    var itemName = itemShortName + " / " + fRec.getLineItemValue('item', 'description', i);
                    var iItemQty = fRec.getLineItemValue('item', 'quantity', i);

                    pkDetailCounter++;

                    packageDescription += (packageDescription.length > 0 ? ", " : "") + itemName + "(" + iItemQty + ")";
                    packageShortDescription += (packageShortDescription.length > 0 ? ", " : "") + itemShortName + "(" + iItemQty + ")";
                    packageVeryShortDescription += (packageVeryShortDescription.length > 0 ? ", " : "") + itemShortName;
                    dataToSave = true;

                    if (pkDetailCounter === pkDetailMaxLength) {
                        pkgDetailCollection.push({
                                'packageDescription': packageDescription,
                                'packageShortDescription': packageShortDescription,
                                'packageVeryShortDescription': packageVeryShortDescription
                            }
                        );
                        packageDescription = '';
                        packageShortDescription = '';
                        packageVeryShortDescription = '';
                        dataToSave = false;
                    }
                }
                if (dataToSave) {
                    pkgDetailCollection.push({
                            'packageDescription': packageDescription,
                            'packageShortDescription': packageShortDescription,
                            'packageVeryShortDescription': packageVeryShortDescription
                        }
                    );
                }
            }
            return pkgDetailCollection;
        }
    };
})();


function afterSubmit(type) {
    return AMSUEItemFulfillmentPkgDetails.afterSubmit(type);
}
/***********************************************************************
 *
 * The following javascript code is created by FMT Consultants LLC,
 * a NetSuite Partner. It is a SuiteFlex component containing custom code
 * intended for NetSuite (www.netsuite.com) and use the SuiteScript API.
 * The code is provided "as is": FMT Consultants LLC shall not be liable
 * for any damages arising out the intended use or if the code is modified
 * after delivery.
 *
 * Company:		FMT Consultants LLC, www.fmtconsultants.com
 * Author:		apoblete@fmtconsultants.com
 * File:        AM_SUE_SalesOrderChanges.js
 * Date:        11/3/2017
 *
 ***********************************************************************/
var ADMIN = 3;
/**
 * Trigger function which prevents certain users from editing approved Sales Orders
 * @author apoblete@fmtconsultants.com
 * @param{string} type
 * @returns null
 */
function beforeSubmit_SalesOrderChanges(type) {
    if (type == 'xedit') {
        var status = nlapiLookupField ( 'salesorder' , nlapiGetRecordId() , 'status' );
        nlapiLogExecution('DEBUG', 'status ', status);
        var role = nlapiGetRole();
        nlapiLogExecution('DEBUG', 'role ', role);
        if (role != ADMIN && status == 'pendingFulfillment') {
            throw 'You are unable to edit edit this transaction.'
        }
    }
}


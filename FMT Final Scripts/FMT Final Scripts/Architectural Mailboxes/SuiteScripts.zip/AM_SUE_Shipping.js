/***********************************************************************
 *
 * The following javascript code is created by FMT Consultants LLC,
 * a NetSuite Partner. It is a SuiteFlex component containing custom code
 * intended for NetSuite (www.netsuite.com) and use the SuiteScript API.
 * The code is provided "as is": FMT Consultants LLC shall not be liable
 * for any damages arising out the intended use or if the code is modified
 * after delivery.
 *
 * Company:     FMT Consultants LLC, www.fmtconsultants.com
 * Author:      apoblete@fmtconsultants.com
 * File:        AM_SUE_Shipping.js
 * Date:        3/16/2016
 *
 ***********************************************************************/
//Constants
var OTHER_TBD = '2794';

/**
 * Function that sets shipping info on Transfer Order
 * @param{string} type
 * @returns null
 */
function beforeLoad_setShippingInfo(type) {
    if (type == 'create') {
        nlapiSetFieldValue('shipcarrier', 'nonups');
        nlapiSetFieldValue('shipmethod', OTHER_TBD);
    }

}


/***********************************************************************
 *
 * The following javascript code is created by FMT Consultants LLC,
 * a NetSuite Partner. It is a SuiteFlex component containing custom code
 * intended for NetSuite (www.netsuite.com) and use the SuiteScript API.
 * The code is provided "as is": FMT Consultants LLC shall not be liable
 * for any damages arising out the intended use or if the code is modified
 * after delivery.
 *
 * Company:     FMT Consultants LLC, www.fmtconsultants.com
 * Author:      smehmood@fmtconsultants.com
 * File:        AM_AmazonData_Dao.js
 * Date:        10/10/2017
 *
 ***********************************************************************/
var AmazonData = (function () {
    return {
        InternalId: 'customrecord_amazondata',
        Fields: {
            Date: {id: 'custrecord_amdate', type: 'date', dataObject: true},
            SettlementId: {id: 'custrecord_amsettlementid', type: 'string', dataObject: true},
            Type: {id: 'custrecord_amtype', type: 'string', dataObject: true},
            OrderId: {id: 'custrecord_amorderid', type: 'string', dataObject: true},
            Sku: {id: 'custrecord_amsku', type: 'string', dataObject: true},
            Description: {id: 'custrecord_amdescription', type: 'string', dataObject: true},
            Quantity: {id: 'custrecord_amquantity', type: 'number', dataObject: false},
            MarketPlace: {id: 'custrecord_ammarketplace', type: 'string', dataObject: false},
            Fulfillment: {id: 'custrecord_amfulfillment', type: 'checkbox', dataObject: true},
            OrderCity: {id: 'custrecord_amordercity', type: 'string', dataObject: true},
            OrderState: {id: 'custrecord_amorderstate', type: 'string', dataObject: true},
            OrderPostal: {id: 'custrecord_amorderpostal', type: 'string', dataObject: true},
            ProductSales: {id: 'custrecord_amproductsales', type: 'number', dataObject: true},
            PostageCredits: {id: 'custrecord_ampostagecredits', type: 'number', dataObject: true},
            GiftWrapCredits: {id: 'custrecord_giftwrapcredits', type: 'number', dataObject: true},
            PromotionalRebates: {id: 'custrecord_ampromotionalrebates', type: 'number', dataObject: true},
            SellingFees: {id: 'custrecord_amsellingfees', type: 'number', dataObject: true},
            FbaFees: {id: 'custrecord_amfbafees', type: 'number', dataObject: true},
            OtherTransaction: {id: 'custrecord_amothertransactionfees', type: 'number', dataObject: true},
            Other: {id: 'custrecord_amother', type: 'number', dataObject: true},
            Total: {id: 'custrecord_amtotal', type: 'number', dataObject: true},
            ProcessStatus: {id: 'custrecord_amprocessstatus', type: 'listrecord', dataObject: true},
            Comments: {id: 'custrecord_amcomments', type: 'string', dataObject: true},
            NSTransaction: {id: 'custrecord_amnstransaction', type: 'string', dataObject: true},
            Customer: {id: 'custrecord_amcustomer', type: 'string', dataObject: true}

        },
        STATUSES: {QUEUE: '1', PROCESSED: '2', FAILED: '3'},
        TYPE: {
            Order: 'Order', Adjustment: 'Adjustment', FBAInventoryFee: 'FBA Inventory Fee',
            Refund: 'Refund', ServiceFee: 'Service Fee', Transfer: 'Transfer'
        },
        getByProcessStatus: function (processStatuses) {
            var results = [];
            var processStatusField = this.Fields.ProcessStatus.id;
            var filters = [
                [processStatusField, "anyof", processStatuses],
                'and',
                ['isinactive', "is", 'F']
            ];
            var columns = [];
            for (var f in this.Fields) {
                columns.push(
                    new nlobjSearchColumn(this.Fields[f].id)
                );
            }

            var searchObject = nlapiSearchRecord(this.InternalId, null, filters, columns);
            var fields = this.Fields;
            var fieldsData = {};
            var fieldValue;

            if (!!searchObject && searchObject.length > 0) {

                for (var r = 0; r < searchObject.length; r++) {
                    fieldsData = {};
                    fieldsData.id = searchObject[r].getId();
                    for (var f in fields) {
                        fieldValue = searchObject[r].getValue(fields[f].id);
                        fieldsData[f] = !!fieldValue ? fieldValue.trim() : fieldValue;
                    }
                    results.push(fieldsData);
                }
            }
            return results;
        },
        validate: function (data) {
            var result = {status: true, message: ''};
            return result;
        },
        amazonToNetsuite: function (data) {
            //Choose Factory
            var factory = Util.getFactory(data);
            //Process Using Concrete Factory
            var result = factory.upsert(data);
            return result;
        },
        markStatus: function (result) {
            var nsRecord = nlapiLoadRecord(this.InternalId, result.amazondataid);
            if (result.status) {
                nsRecord.setFieldValue(this.Fields.ProcessStatus.id, this.STATUSES.PROCESSED);
                nsRecord.setFieldValue(this.Fields.NSTransaction.id, result.id);
                nsRecord.setFieldValue(this.Fields.Comments.id, '');

            } else {
                nsRecord.setFieldValue(this.Fields.ProcessStatus.id, this.STATUSES.FAILED);
                nsRecord.setFieldValue(this.Fields.Comments.id, result.message);
            }

            nlapiSubmitRecord(nsRecord);
        }
    };
})();
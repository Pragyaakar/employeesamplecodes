/***********************************************************************
 *
 * The following javascript code is created by FMT Consultants LLC,
 * a NetSuite Partner. It is a SuiteFlex component containing custom code
 * intended for NetSuite (www.netsuite.com) and use the SuiteScript API.
 * The code is provided "as is": FMT Consultants LLC shall not be liable
 * for any damages arising out the intended use or if the code is modified
 * after delivery.
 *
 * Company:     FMT Consultants LLC, www.fmtconsultants.com
 * Author:      smehmood@fmtconsultants.com
 * File:        AM_AmazonData_Dao.js
 * Date:        10/10/2017
 *
 ***********************************************************************/
var CreditMemo = (function () {
    return {
        InternalId: 'creditmemo',
        Fields: {
            Customer: {id: 'entity', type: 'string'},
            Date: {id: 'trandate', type: 'string'},
            CustomForm: {id: 'customform'},
            PO: {id: 'otherrefnum'},
            Location: {id: 'location'}
        },
        NS_AMAZON_TRANSACTON_CHECKBOX: 'custbody_crbyamdp',
        Configs: {
            uk: {
                ColumnBasedLines: {
                    SellingFees: {nsItem: '2593', transform: 'negative'}, //9546
                    FbaFees: {nsItem: '2603', transform: 'negative'},      //9557
                    PostageCredits: {nsItem: '2592', transform: 'positive'},    //9545
                    PromotionalRebates: {nsItem: '2596', transform: 'negative'} //9549
                },
                NSCustomer: '2387',
                NSLocation: '5',
                ItemsByTypeDescValue: {
                    'fba disposal fee': '2604',    //9558
                    'fba storage fee': '2680',     //9551
                    'service fee': '2597'           //9550
                }
            },
            germany: {
                ColumnBasedLines: {
                    SellingFees: {nsItem: '2593', transform: 'negative'}, //9546
                    FbaFees: {nsItem: '2603', transform: 'negative'},      //9557
                    PostageCredits: {nsItem: '2592', transform: 'positive'},    //9545
                    PromotionalRebates: {nsItem: '2596', transform: 'negative'} //9549
                },
                NSCustomer: '2383',
                NSLocation: '5',
                ItemsByTypeDescValue: {
                    'fba disposal fee': '2604',    //9558
                    'fba storage fee': '2680',     //9551
                    'service fee': '2597'           //9550
                }
            },
            france: {
                ColumnBasedLines: {
                    SellingFees: {nsItem: '2593', transform: 'negative'}, //9546
                    FbaFees: {nsItem: '2603', transform: 'negative'},      //9557
                    PostageCredits: {nsItem: '2592', transform: 'positive'},    //9545
                    PromotionalRebates: {nsItem: '2596', transform: 'negative'} //9549
                },
                NSCustomer: '2385',
                NSLocation: '5',
                ItemsByTypeDescValue: {
                    'fba disposal fee': '2604',    //9558
                    'fba storage fee': '2680',     //9551
                    'service fee': '2597'           //9550
                }
            },
            italy: {
                ColumnBasedLines: {
                    SellingFees: {nsItem: '2593', transform: 'negative'}, //9546
                    FbaFees: {nsItem: '2603', transform: 'negative'},      //9557
                    PostageCredits: {nsItem: '2592', transform: 'positive'},    //9545
                    PromotionalRebates: {nsItem: '2596', transform: 'negative'} //9549
                },
                NSCustomer: '2386',
                NSLocation: '5',
                ItemsByTypeDescValue: {
                    'fba disposal fee': '2604',    //9558
                    'fba storage fee': '2680',     //9551
                    'service fee': '2597'           //9550
                }
            },
            spain: {
                ColumnBasedLines: {
                    SellingFees: {nsItem: '2593', transform: 'negative'}, //9546
                    FbaFees: {nsItem: '2603', transform: 'negative'},      //9557
                    PostageCredits: {nsItem: '2592', transform: 'positive'},    //9545
                    PromotionalRebates: {nsItem: '2596', transform: 'negative'} //9549
                },
                NSCustomer: '2384',
                NSLocation: '5',
                ItemsByTypeDescValue: {
                    'fba disposal fee': '2604',    //9558
                    'fba storage fee': '2680',     //9551
                    'service fee': '2597'           //9550
                }
            }
        },
        ALLOWED_TYPES: ['fba inventory fee', 'service fee', 'refund'],
        FORM_ID: '125',
        CUSTOMER_IDENTITY_PROPERTY: 'Customer',
        upsert: function (data) {
            var result = this.validate(data);
            var nsObject;
            if (result.status) {
                result = this.prepare(data);
                try {
                    if (result.status) {
                        result.id = nlapiSubmitRecord(result.nsRecord, false, true);
                    }
                } catch (e) {
                    result.message = e.toString();
                    result.status = false;
                }
            }
            return result;
        },
        validate: function (data) {
            var result = {status: true, message: ''};
            return result;
        },
        prepare: function (data) {
            var result = {status: true, message: ''};
            var lineType = data['Type'].toLowerCase();
            var sku;
            var itemId;
            var marketPlace;
            var nsCustomer;
            var nsRecord;
            var existingTran;
            var fieldsAndValues = {};
            var nsLocation;
            var fixedItems;
            var lineCount;
            var fixedLines;
            var amountValue;
            var orderId;
            try {
                if (this.ALLOWED_TYPES.indexOf(lineType) > -1) {
                    marketPlace = data[this.CUSTOMER_IDENTITY_PROPERTY].toLowerCase();
                    nsCustomer = this.Configs[marketPlace].NSCustomer;
                    nsLocation = this.Configs[marketPlace].NSLocation;
                    fixedItems = this.Configs[marketPlace].ItemsByTypeDescValue;
                    fixedLines = this.Configs[marketPlace].ColumnBasedLines;
                    if (!!nsCustomer) {

                        existingTran = this.getExisting(nsCustomer, data);

                        if (!!existingTran && !!existingTran.id) {
                            nsRecord = nlapiLoadRecord(this.InternalId, existingTran.id);
                        } else {
                            nsRecord = nlapiCreateRecord(this.InternalId);
                            //Set Body Fields
                            nsRecord.setFieldValue(this.Fields.Customer.id, nsCustomer);
                            nsRecord.setFieldValue(this.Fields.Date.id, data['Date']);
                            nsRecord.setFieldValue(this.Fields.Date.id, data['Date']);
                            nsRecord.setFieldValue(this.Fields.CustomForm.id, this.FORM_ID);
                            orderId = data['OrderId'];
                            nsRecord.setFieldValue(this.Fields.PO.id, Util.isBlankOrNull(orderId) ? data['Type'] + ' - ' +
                            Util.COUNTRY_MAPES[marketPlace].shortname : orderId);
                            nsRecord.setFieldValue(this.Fields.Location.id, nsLocation);
                            this.setAddress(nsRecord, data);

                        }
                        nsRecord.setFieldValue(this.NS_AMAZON_TRANSACTON_CHECKBOX, 'T');
                        fieldsAndValues = {};

                        if (lineType === 'refund') {
                            sku = data['Sku'];
                            itemId = Util.getItemBySku(sku);

                            if (!itemId) {
                                throw nlapiCreateError('SKU NOT FOUND', 'Netsuite Item not found for sku : ' + sku);
                            }

                            fieldsAndValues['item'] = itemId;
                            fieldsAndValues['quantity'] = data['Quantity'];
                            fieldsAndValues['location'] = nsLocation;
                            fieldsAndValues['rate'] = Math.abs(parseFloat(data['ProductSales'])
                                / parseFloat(data['Quantity']));
                            fieldsAndValues['amount'] = Math.abs(parseFloat(data['ProductSales']));
                            this.addNewLineToInvoice(nsRecord, fieldsAndValues);

                            //Add Fixed Lines
                            for (var l in fixedLines) {
                                fieldsAndValues = {};
                                fieldsAndValues['item'] = fixedLines[l].nsItem;
                                fieldsAndValues['quantity'] = 1;
                                fieldsAndValues['location'] = nsLocation;
                                amountValue = parseFloat(data[l]);
                                if (!isNaN(amountValue) && amountValue !== 0) {
                                    if (fixedLines[l].transform === 'negative') {
                                        fieldsAndValues['rate'] = -1 * Math.abs(amountValue);
                                        fieldsAndValues['amount'] = -1 * Math.abs(amountValue);
                                    } else if (fixedLines[l].transform === 'positive') {
                                        fieldsAndValues['rate'] = Math.abs(amountValue);
                                        fieldsAndValues['amount'] = Math.abs(amountValue);
                                    }
                                    else {
                                        fieldsAndValues['rate'] = amountValue;
                                        fieldsAndValues['amount'] = amountValue;
                                    }
                                    this.addNewLineToInvoice(nsRecord, fieldsAndValues);
                                }
                            }
                        }
                        else {
                            itemId = fixedItems[lineType];

                            if (!itemId) {
                                itemId = fixedItems[data['Description'].toLowerCase()];
                            }
                            fieldsAndValues['item'] = itemId;
                            fieldsAndValues['quantity'] = 1;
                            fieldsAndValues['location'] = nsLocation;
                            fieldsAndValues['rate'] = Math.abs(parseFloat(data['Total']));
                            fieldsAndValues['amount'] = Math.abs(parseFloat(data['Total']));
                            this.addNewLineToInvoice(nsRecord, fieldsAndValues);
                        }


                    } else {
                        throw nlapiCreateError('CUSTOMER NOT DEFINED IN CONFIG', 'Netsuite Customer not found for marketplace : ' + marketPlace);
                    }

                } else {
                    throw nlapiCreateError('TYPE_NOT_ALLOWED', 'Type not allowed for credit memo');
                }

                result.nsRecord = nsRecord;
            }
            catch
                (e) {
                result.status = false;
                result.message = e.toString();
            }
            return result;
        },
        getExisting: function (entityId, data) {
            var output = [];
            var orderIdBlank = Util.isBlankOrNull(data["OrderId"]);

            if (!orderIdBlank) {
                var filters = [
                    ['trandate', "on", data['Date']],
                    'and',
                    ['entity', "is", entityId],
                    'and',
                    ['mainline', "is", 'T'],
                    'and',
                    [this.NS_AMAZON_TRANSACTON_CHECKBOX, "is", 'T'],
                    'and',
                    ['poastext', "is", data["OrderId"]]
                ];
                var searchObject = nlapiSearchRecord(this.InternalId, null, filters);

                var fieldsData = {};

                if (!!searchObject && searchObject.length > 0) {
                    for (var r = 0; r < searchObject.length; r++) {
                        fieldsData = {};
                        fieldsData.id = searchObject[0].getId();
                        output = fieldsData;
                    }
                }
            }
            return output;
        },
        addNewLineToInvoice: function (nsRecord, fieldAndValues) {
            nsRecord.selectNewLineItem('item');

            for (var f in fieldAndValues) {

                nsRecord.setCurrentLineItemValue(
                    'item',
                    f,
                    fieldAndValues[f]
                );
            }

            nsRecord.commitLineItem('item');
        },
        setAddress: function (nsRecord, data) {
            var shipCountry = Util.COUNTRY_MAPES[data[this.CUSTOMER_IDENTITY_PROPERTY].toLowerCase()].nsid;
            nsRecord.setFieldValue('shipcountry', shipCountry);
            nsRecord.setFieldValue('shipisresidential', 'F');
            nsRecord.setFieldValue('shipattention', '');
            nsRecord.setFieldValue('shipaddressee', '');
            nsRecord.setFieldValue('shipaddrphone', '');
            nsRecord.setFieldValue('shipaddr1', '');
            nsRecord.setFieldValue('shipaddr2', '');
            nsRecord.setFieldValue('shipcity', '');
            nsRecord.setFieldValue('shipstate', '');
            nsRecord.setFieldValue('shipzip', '');
        }
    }
});

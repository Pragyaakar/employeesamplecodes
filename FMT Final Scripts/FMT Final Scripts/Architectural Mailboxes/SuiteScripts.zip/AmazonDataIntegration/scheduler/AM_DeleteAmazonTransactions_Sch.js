/***********************************************************************
 *
 * The following javascript code is created by FMT Consultants LLC,
 * a NetSuite Partner. It is a SuiteFlex component containing custom code
 * intended for NetSuite (www.netsuite.com) and use the SuiteScript API.
 * The code is provided "as is": FMT Consultants LLC shall not be liable
 * for any damages arising out the intended use or if the code is modified
 * after delivery.
 *
 * Company:     FMT Consultants LLC, www.fmtconsultants.com
 * Author:      smehmood@fmtconsultants.com
 * File:        AM_DeleteAmazonTransactions_Sch.js
 * Date:        10/11/2017
 *
 ***********************************************************************/
var DeleteAmazonTrans = (function () {
    return {
        MIN_UNITS: 100,
        context: null,
        SAVED_SEARCH: '',
        TRAN_TYPE: {
            CustCred: 'creditmemo',
            CustInvc: 'invoice',
            CustDep: 'customerdeposit'
        },
        startup: function () {
            try {
                this.context = nlapiGetContext();
                this.SAVED_SEARCH = this.context.getSetting('SCRIPT', 'custscript_savedsearchdd');
                var records = this.getRecords();

                nlapiLogExecution('debug',
                    'count',
                    (!!records && !!records.length) ? records.length : 0
                );

                this.processRecords(records);

            } catch (e) {

                nlapiLogExecution('error',
                    'error',
                    e.toString()
                );
            }
        },
        getRecords: function () {
            var result = [];
            if (!!this.SAVED_SEARCH) {
                var recs = nlapiSearchRecord('transaction', this.SAVED_SEARCH, [new nlobjSearchFilter('custbody_crbyamdp', null, 'is', 'T')],
                    [new nlobjSearchColumn('type')]);

                if (!!recs && recs.length > 0) {
                    for (var i = 0; i < recs.length; i++) {
                        nlapiLogExecution('debug', i);
                        result.push({
                            id: recs[i].getId(),
                            type: recs[i].getValue('type')
                        });
                    }
                }
            }
            return result;
        },

        processRecords: function (records) {
            if (!!records && records.length > 0) {

                for (var i = 0; i < records.length; i++) {
                    try {
                        nlapiDeleteRecord(this.TRAN_TYPE[records[i].type], records[i].id);
                        if (this.isRescheduleNeeded()) {
                            this.reschedule(null);
                            break;
                        }
                    } catch (ex) {
                        nlapiLogExecution('error',
                            'Error When Processing Amazon Data' + records[i],
                            ex.toString()
                        );
                    }
                }
            }
        },
        isRescheduleNeeded: function () {
            var result = false;
            var remainingUsage = this.context.getRemainingUsage();

            nlapiLogExecution('debug', 'units', remainingUsage);

            if (remainingUsage < this.MIN_UNITS)
                result = true;

            return result;
        },
        reschedule: function (params) {
            nlapiScheduleScript(this.context.getScriptId(), this.context.getDeploymentId(), params);
        }
    };
})();

function startup() {
    return DeleteAmazonTrans.startup();
}
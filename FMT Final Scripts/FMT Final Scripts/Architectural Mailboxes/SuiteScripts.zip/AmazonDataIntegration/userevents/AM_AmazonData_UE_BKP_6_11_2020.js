/**
 *@NApiVersion 2.x
 *@NScriptType UserEventScript
 */
define(['N/record', 'N/format'],
    function (record, format) {

        function beforeSubmit(context) {
            if (context.type == context.UserEventType.CREATE || context.type == context.UserEventType.UPDATE) {
                var currentRecord = context.newRecord;
                var dateTimeOriginal = currentRecord.getValue({fieldId: 'custrecord_amdatetime'});
                var dateTimeValue = Date.parse(currentRecord.getValue({fieldId: 'custrecord_amdatetime'}));

                log.debug({
                    title: 'dateTimeOriginal',
                    details: dateTimeOriginal
                });

                log.debug({
                    title: 'dateTimeValue',
                    details: dateTimeValue
                });
                var tempDate = new Date();
                log.debug({
                    title: 'tempDate',
                    details: format.parse({
                        value: tempDate,
                        type: format.Type.DATE
                    })
                });


                tempDate.setTime(dateTimeValue);
                currentRecord.setValue({
                    fieldId: 'custrecord_amdate', value: format.parse({
                        value: tempDate,
                        type: format.Type.DATE
                    })
                });
            }
        }

        return {
            beforeSubmit: beforeSubmit,
        };
    });
/***********************************************************************
 *
 * The following javascript code is created by FMT Consultants LLC,
 * a NetSuite Partner. It is a SuiteFlex component containing custom code
 * intended for NetSuite (www.netsuite.com) and use the SuiteScript API.
 * The code is provided "as is": FMT Consultants LLC shall not be liable
 * for any damages arising out the intended use or if the code is modified
 * after delivery.
 *
 * Company:     FMT Consultants LLC, www.fmtconsultants.com
 * Author:      smehmood@fmtconsultants.com
 * File:        AM_AmazonDataIntegration_Util.js
 * Date:        10/10/2017
 *
 ***********************************************************************/
/* This class contains util functions to be used accross amazon data processing module */
var Util = (function () {
    return {
        COUNTRY_MAPES: {
            uk: {nsid: 'GB', shortname: 'UK'},
            germany: {nsid: 'DE', shortname: 'DE'},
            france: {nsid: 'FR', shortname: 'FR'},
            italy: {nsid: 'IT', shortname: 'IT'},
            spain: {nsid: 'ES', shortname: 'ES'}
        },
        getFactory: function (data) {
            var factory;
            switch (data['Type']) {
                case AmazonData.TYPE.Order:
                    factory = new Invoice();
                    break;
                case AmazonData.TYPE.Adjustment:
                    factory = new Invoice();
                    break;
                case AmazonData.TYPE.FBAInventoryFee:
                    factory = new CreditMemo();
                    break;
                case AmazonData.TYPE.Refund:
                    factory = new CreditMemo();
                    break;
                case AmazonData.TYPE.ServiceFee:
                    factory = new CreditMemo();
                    break;
                case AmazonData.TYPE.Transfer:
                    factory = new CustomerDeposit();
                    break;
            }
            return factory;
        },
        //Item by SKU
        getItemBySku: function (sku) {
            var output;
            var searchObject = nlapiSearchRecord('item', null, ['itemid', "is", sku]);

            if (!!searchObject) {
                output = searchObject[0].getId();
            }
            return output;
        },
        isBlankOrNull: function (toCheckValue) {
            return (toCheckValue === null || toCheckValue === "") ? true : false;
        }
    };
})();
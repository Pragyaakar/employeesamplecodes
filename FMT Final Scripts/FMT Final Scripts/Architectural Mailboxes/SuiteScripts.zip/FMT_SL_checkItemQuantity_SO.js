/**
 *@NApiVersion 2.x
 *@NScriptType Suitelet
 */

 define(["N/record", "N/log", "N/search", "N/runtime", "N/http"], function (
    record,
    log,
    search,
    runtime,
    http
  ) {
    function onRequest(context) {
      try {
        var requestparam = context.request.parameters;
        var array_item = requestparam.array_item;
        log.debug("array_itemo", array_item);
        array_ite = JSON.parse(array_item);
  
        var type = Array.isArray(array_ite);
        
        log.debug(type);
  
        if (context.request.method == "GET" ) {
          log.debug("array_itemi", array_ite);
  
          var callSearch = searchItem(array_ite);
  
          log.debug(callSearch);
          
          var callSearc = JSON.stringify(callSearch);
  
          //Retrieve all the results obtained from created search
  
          context.response.write(callSearc);
        }
      } catch (e) {
        log.debug(e);
      }
    }
  
    /*******************************************************searchItem**************************************/
  
    function searchItem(array_item) {
      var inventoryitemSearchObj = search.create({
        type: "salesorder",
        filters: [
          ["itemtype", "is", "InvtPart"],
          "AND",
          ["type", "anyof", "SalesOrd"],
          "AND",
          ["mainline", "is", "F"],
          "AND",
          ["taxline", "is", "F"],
          "AND",
          ["shipping", "is", "F"],
          "AND",
          ["item.internalid", "anyof", array_item],
        ],
        columns: [
          search.createColumn({ name: "internalid", label: "Internal ID" }),
          search.createColumn({
            name: "totalquantityonhand",
            join: "item",
            label: "Total Quantity On Hand",
          }),
          search.createColumn({
            name: "quantityavailable",
            join: "item",
            label: "Available",
          }),
          search.createColumn({
            name: "preferredlocation",
            join: "item",
            label: "Preferred Location",
          }),
        ],
      });
  
      var searchResultCount = searchAll(inventoryitemSearchObj.run());
  
      if (searchResultCount) {
        var flag = true;
  
        for (var i = 0; i < searchResultCount.length; i++) {
          var quantityavailable = searchResultCount[i].getValue({
            name: "quantityavailable",
            join: "item",
            label: "Available",
          });
          var totalquantityonhand = searchResultCount[i].getValue({
              name: "totalquantityonhand",
              join: "item",
              label: "Total Quantity On Hand",
            });
  
            var mess = ' quantityavailable and  totalquantityonhand both are available';
  
          if (!quantityavailable && !totalquantityonhand) {
            flag = false;
            mess = 'no quantityavailable and no totalquantityonhand '
            break;
          }
          if (!quantityavailable && totalquantityonhand) {
            flag = false;
            mess = 'no quantityavailable and but has totalquantityonhand '
  
            break;
          }
          if (quantityavailable && !totalquantityonhand) {
            flag = false;
            mess = 'has quantityavailable and no totalquantityonhand '
            break;
          }
  
        }
  
        return [flag, mess];
      }
    }
    /*******************************************************searchAll***********************************/
  
    function searchAll(resultset) {
      var allResults = [];
      var startIndex = 0;
      var RANGECOUNT = 1000;
  
      do {
        var pagedResults = resultset.getRange({
          start: parseInt(startIndex),
          end: parseInt(startIndex + RANGECOUNT),
        });
  
        allResults = allResults.concat(pagedResults);
  
        var pagedResultsCount = pagedResults != null ? pagedResults.length : 0;
        startIndex += pagedResultsCount;
  
        var remainingUsage = runtime.getCurrentScript().getRemainingUsage();
      } while (pagedResultsCount == RANGECOUNT);
      var remainingUsage = runtime.getCurrentScript().getRemainingUsage();
  
      return allResults;
    }
    /***********************************************************************************************************/
  
    return {
      onRequest: onRequest,
    };
  });
  
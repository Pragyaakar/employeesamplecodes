function Receipt_Fields(type)
{
	if(type=="create")
	{
		try
		{
			var receipt = nlapiGetNewRecord();
			
			var receiptDate = receipt.getFieldValue("trandate");
			nlapiLogExecution("debug","Item Receipt Date",receiptDate);
			
			var receiptDateObj = nlapiStringToDate(receiptDate);
			
			var filters = [];
			filters.push(new nlobjSearchFilter("internalid",null,"is",receipt));
			filters.push(new nlobjSearchFilter("mainline",null,"is","F"));
			filters.push(new nlobjSearchFilter("shipping",null,"is","F"));
			filters.push(new nlobjSearchFilter("taxline",null,"is","F"));
			filters.push(new nlobjSearchFilter("item",null,"noneof","@NONE@"));
			var cols = [];
			cols.push(new nlobjSearchColumn("item"));
			cols.push(new nlobjSearchColumn("quantity"));
			cols.push(new nlobjSearchColumn("custitem_next_west_receipt_date","item"));
			cols.push(new nlobjSearchColumn("custentity_transit_days_west","vendor"));
			cols.push(new nlobjSearchColumn("custrecord_location_addt_transit_time","location"));
			var results = nlapiSeachRecord("itemreceipt",null,filters,cols);
			if(results)
			{
				//Get Days in Transit from Vendor Record
				var daysInTransit = results[0].getValue("custentity_transit_days_west","vendor");
				if(daysInTransit==null || daysInTransit=="")
					daysInTransit = 0;
				else
					daysInTransit = parseInt(daysInTransit);
					
				nlapiLogExecution("debug","Vendor Days in Transit",daysInTransit);
				
				//Get Location Days in Transit from Location Record
				var locationDays = results[0].getValue("custrecord_location_addt_transit_time","location");
				if(locationDays==null || locationDays=="")
					locationDays = 0;
				else
					locationDays = parseInt(locationDays);
					
				nlapiLogExecution("debug","Location Days in Transit",locationDays);
				
				//Figure out total Receipt Date
				var nextReceiptDateObj = nlapiAddDays(receiptDateObj,daysInTransit);
				nextReceiptDateObj = nlapiAddDays(nextReceiptDate,locationDays);
				
				var nextReceiptDate = nlapiDateToString(nextReceiptDateObj,"date");
				
				for(var x=0; x < results.length; x++)
				{
					nlapiLogExecution("debug"," --- ITEM: " + results[x].getText("item") + " ---");
					
					if(results[x].getValue("custitem_next_west_receipt_date","item")!=null && results[x].getValue("custitem_next_west_receipt_date","item")!="")
					{
						var itemDate = nlapiStringToDate(results[x].getValue("custitem_next_west_receipt_date","item"));
						nlapiLogExecution("debug","Existing Receipt Date on Item","Value: " + itemDate);
						
						if(nextReceiptDateObj < itemDate)
						{
							var fields = ["custitem_next_west_receipt_date","custitem_next_west_receipt_qty"];
						
							var data = [];
							data.push(nextReceiptDate);
							data.push(results[x].getValue("quantity"));
						
							nlapiSubmitField("inventoryitem",results[x].getValue("item"),fields,data);
						}
					}
					else
					{
						nlapiLogExecution("debug","Receipt Data Empty on Item");
						
						var fields = ["custitem_next_west_receipt_date","custitem_next_west_receipt_qty"];
						
						var data = [];
						data.push(nextReceiptDate);
						data.push(results[x].getValue("quantity"));
						
						nlapiSubmitField("inventoryitem",results[x].getValue("item"),fields,data);
					}
				}
			}
		}
		catch(err)
		{
			nlapiLogExecution("error","Error Updating Item Date Fields","Details: " + err.message);
		}
	}
}

function Item_Receipt_Date_Cleanup_SS()
{
	var filters = [];
	filters.push(new nlobjSearchFilter("custitem_next_west_receipt_date",null,"isnotempty"));
	filters.push(new nlobjSearchFilter("custitem_next_west_receipt_date",null,"before","today"));
	var results = nlapiSearchRecord("item",null,filters);
	if(results)
	{
		for(var x=0; x < results.length; x++)
		{
			try
			{
				nlapiSubmitField("inventoryitem",results[x].getId(),["custitem_next_west_receipt_date","custitem_next_west_receipt_qty"],["",""]);	
			}
			catch(err)
			{
				nlapiLogExecution("error","Error Removing Receipt Date","Item: " + results[x].getId() + "\n\nDetails: " + err.message);
			}
		}
	}
}

   /**
    *@NApiVersion 2.x
    *@NScriptType MapReduceScript
    */
   define(['N/search', 'N/record', 'N/email', 'N/runtime'],
   function(search, record, email, runtime, error) {
       
        function getInputData() {
           var testsearch = 'getInputData';
           log.debug('Stage',testsearch);

           var searchParam = runtime.getCurrentScript().getParameter('custscript_fmt_datainput_inv_inbound');
           log.debug('This is your param',searchParam);

           var itemreceiptSearchObj = search.load({
               type: search.Type.TRANSACTION,
               id: searchParam
           });

        //    var itemreceiptSearchObj = search.create({
        //     type: "itemreceipt",
        //     filters:
        //     [
        //        ["type","anyof","ItemRcpt"], 
        //        "AND", 
        //        ["item.type","anyof","InvtPart"], 
        //        "AND", 
        //        ["item","anyof","2973"], 
        //        "AND", 
        //        ["mainline","is","F"], 
        //        "AND", 
        //        ["location","anyof","29","21"], 
        //        "AND", 
        //        [[["formulatext: {entity}","is","Suzhou Sunqi"],"AND",["formulanumeric: {today}-{trandate}","lessthanorequalto","27"]],"OR",[["formulatext: {entity}","is","Electrospark"],"AND",["formulanumeric: {today}-{trandate}","lessthanorequalto","62"]],"OR",[["formulatext: {entity}","is","India International House Ltd"],"AND",["formulanumeric: {today}-{trandate}","lessthanorequalto","62"]],"OR",[["formulatext: {entity}","is","Prashant Enterprises"],"AND",["formulanumeric: {today}-{trandate}","lessthanorequalto","62"]]]
        //     ],
        //     columns:
        //     [
        //        search.createColumn({
        //           name: "internalid",
        //           join: "item",
        //           summary: "GROUP",
        //           label: "Item Internal ID"
        //        }),
        //        search.createColumn({
        //           name: "item",
        //           summary: "GROUP",
        //           sort: search.Sort.ASC,
        //           label: "Item"
        //        }),
        //        search.createColumn({
        //           name: "trandate",
        //           summary: "MIN",
        //           sort: search.Sort.ASC,
        //           label: "Date"
        //        }),
        //        search.createColumn({
        //           name: "formuladate",
        //           summary: "MIN",
        //           formula: "CASE WHEN {entity}='Suzhou Sunqi' THEN {trandate}+27 WHEN {entity}='Electrospark' THEN {trandate}+62 WHEN {entity}='India International House Ltd' THEN {trandate}+62 WHEN {entity}='Prashant Enterprises' THEN {trandate}+62 ELSE {trandate}+62 END",
        //           label: "Formula (Date)"
        //        }),
        //        search.createColumn({
        //           name: "quantity",
        //           summary: "MAX",
        //           label: "Quantity"
        //        })
        //     ]
        //  });
         return itemreceiptSearchObj;

        }
        function map(context) {

            var searchObj = JSON.parse(context.value);
            // log.debug('this is your search object',searchObj);

            var searchResultid = searchObj.id; //this is iterative of the record count.  So for loop, searchObj.length

            // log.debug('Search Result Id',searchResultid);

            var itemObj = searchObj.values;

            log.debug('This is your entire Item Obj',itemObj);

            var itemid = itemObj["GROUP(internalid.item)"].value;

            log.debug('Item internalid',itemid);

            var itemDate = itemObj["MIN(formuladate)"];

            //from here, going to pass these as filters to new saved search, and execute correct summary of values

//            var filters = 
//    [
//       ["item","anyof",itemid], 
//       "AND", 
//       ["formuladate: CASE WHEN {entity}='Suzhou Sunqi' THEN {trandate}+27 WHEN {entity}='Electrospark' THEN {trandate}+62 WHEN {entity}='India International House Ltd' THEN {trandate}+62 WHEN {entity}='Prashant Enterprises' THEN {trandate}+62 ELSE {trandate}+62 END","on",itemDate]
//    ];

            var quantitySearchObj = search.create({
                type: "itemreceipt",
                filters:
                [
                ["type","anyof","ItemRcpt"], 
                "AND", 
                ["mainline","is","F"], 
                "AND", 
                ["item","anyof",itemid], 
                "AND", 
                ["formuladate: CASE WHEN {entity}='Suzhou Sunqi' THEN {trandate}+27 WHEN {entity}='Electrospark' THEN {trandate}+62 WHEN {entity}='India International House Ltd' THEN {trandate}+62 WHEN {entity}='Prashant Enterprises' THEN {trandate}+62 ELSE {trandate}+62 END","on",itemDate]
                ],
                columns:
                [
                search.createColumn({
                    name: "item",
                    summary: "GROUP",
                    sort: search.Sort.ASC,
                    label: "Item"
                }),
                search.createColumn({
                    name: "quantity",
                    summary: "SUM",
                    label: "Quantity"
                }),
                search.createColumn({
                    name: "formuladate",
                    summary: "MIN",
                    formula: "CASE WHEN {entity}='Suzhou Sunqi' THEN {trandate}+27 WHEN {entity}='Electrospark' THEN {trandate}+62 WHEN {entity}='India International House Ltd' THEN {trandate}+62 WHEN {entity}='Prashant Enterprises' THEN {trandate}+62 ELSE {trandate}+62 END",
                    label: "Formula (Date)"
                })
                ]
            });

            

            // log.debug('This is Date Filter Formula',objFilterFormulaDate);



            // quantitySearchObj.filters.push(objFilterItem); //Push first filter to Search
            // quantitySearchObj.filters.push(objFilterFormulaDate); // Push Second Filter to Search

            // quantitySearchObj.filterExpression = filters;

            log.debug('This is Search with Filters',quantitySearchObj);

            var res_arr = [];
            var res = {};
            quantitySearchObj.run().each(function(result){
                log.debug('Search Results',JSON.stringify(result))

                res['sumItemQuantity'] = result.getValue({
                    name: 'quantity',
                    summary: search.Summary.SUM
                });

                log.debug('This is Correct Quantity',res.sumItemQuantity);

                res_arr.push(res);


                return true;
            });

            log.debug('This is your Search ARR',res_arr);
            log.debug('This is your object',res);


            // var itemreceiptSearchObj = search.create({
            //     type: "itemreceipt",
            //     filters:
            //     [
            //        ["type","anyof","ItemRcpt"], 
            //        "AND", 
            //        ["item","anyof","2973"], 
            //        "AND", 
            //        ["mainline","is","T"], 
            //        "AND", 
            //        ["formuladate: CASE WHEN {entity}='Suzhou Sunqi' THEN {trandate}+27 WHEN {entity}='Electrospark' THEN {trandate}+62 WHEN {entity}='India International House Ltd' THEN {trandate}+62 WHEN {entity}='Prashant Enterprises' THEN {trandate}+62 ELSE {trandate}+62 END","on","6/7/2020"]
            //     ],
            //     columns:
            //     [
            //        search.createColumn({
            //           name: "item",
            //           summary: "GROUP",
            //           sort: search.Sort.ASC,
            //           label: "Item"
            //        }),
            //        search.createColumn({
            //           name: "quantity",
            //           summary: "SUM",
            //           label: "Quantity"
            //        }),
            //        search.createColumn({
            //           name: "formuladate",
            //           summary: "MIN",
            //           formula: "CASE WHEN {entity}='Suzhou Sunqi' THEN {trandate}+27 WHEN {entity}='Electrospark' THEN {trandate}+62 WHEN {entity}='India International House Ltd' THEN {trandate}+62 WHEN {entity}='Prashant Enterprises' THEN {trandate}+62 ELSE {trandate}+62 END",
            //           label: "Formula (Date)"
            //        })
            //     ]
            //  });


            log.debug('This is the Item expected date',itemDate);

            var itemQuantity = itemObj["MAX(quantity)"];
            log.debug('This is the Max Quantity',itemQuantity);

            //

            try{

            var itemRec = record.load({
                type: record.Type.INVENTORY_ITEM,
                id: itemid,
                isDynamic: true
            });

            log.debug('This is your item record',itemRec);

            itemRec.setValue({
                fieldId: 'custitem_fmt_inv_inbound_date',
                value: new Date(itemDate)
            });

            itemRec.setValue({
                fieldId: 'custitem_fmt_inv_inbound_item_quantity',
                value: res.sumItemQuantity
            });

            var newItemRec = itemRec.save();



            log.debug('You have Succesfully Saved',newItemRec);


        }catch(e){
            log.debug('This is your Error',e);
        }

        }
        function reduce(context) {
            //No Reduce Function
        }
        function summarize(summary) {
            var inputSummary = summary.inputSummary;
            var mapSummary = summary.mapSummary;
            var reduceSummary = summary.reduceSummary;
        }
        return {
            getInputData: getInputData,
            map: map,
            reduce: reduce,
            summarize: summarize
        };
    });
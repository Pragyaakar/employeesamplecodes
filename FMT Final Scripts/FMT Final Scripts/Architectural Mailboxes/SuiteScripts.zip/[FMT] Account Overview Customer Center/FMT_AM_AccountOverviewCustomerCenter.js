/**
 * @NApiVersion 2.0
 * @NScriptType Suitelet
 */
/***********************************************************************
 *
 * The following javascript code is created by FMT Consultants LLC,
 * a NetSuite Partner. It is a SuiteFlex component containing custom code
 * intended for NetSuite (www.netsuite.com) and use the SuiteScript API.
 * The code is provided "as is": FMT Consultants LLC shall not be liable
 * for any damages arising out the intended use or if the code is modified
 * after delivery.
 *
 * Company:     FMT Consultants LLC, www.fmtconsultants.com
 * Author:      smehmood@fmtconsultants.com
 * File:        FMT_AM_AccountOverviewCustomerCenter.js
 * Date:        10/2/2020
 *
 ***********************************************************************/

define(["N/ui/serverWidget", "N/runtime", "N/record", "N/search", "N/file"],
    function (ui, runtime, record, search, file) {

        function onRequest(context) {
            var scriptObj = runtime.getCurrentScript();
            var request = context.request;
            var userObj = runtime.getCurrentUser();
            var parameterUser = request.parameters.user;
            var user = !!parameterUser ? parameterUser : userObj.id;
            var priceLevelId, priceLevelValues;

            if (context.request.method === "GET") {
                try {
                    var customerSearchObj = search.create({
                        type: "customer",
                        filters: ["internalid", "is", user],
                        columns: [
                            search.createColumn({name: "custentity_restock_fee", label: "Restocking Fee"}),
                            search.createColumn({name: "pricelevel", label: "Price Level"}),
                            search.createColumn({name: "salesrep", label: "Sales Rep"}),
                            search.createColumn({name: "email", join: "salesrep", label: "Sales Rep"}),
                            search.createColumn({
                                name: "custentity_tracking_email_contact",
                                label: "Tracking Number Email"
                            }),
                            search.createColumn({
                                name: "custentity_customer_service_email",
                                label: "Customer Service Email"
                            }),
                            search.createColumn({
                                name: "custentity_inventory_update_email",
                                label: "Inventory Update Email"
                            }),
                            search.createColumn({
                                name: "custentity_accounts_payable_email",
                                label: "Accounts Payable Email"
                            })
                        ]
                    });
                    var searchResultCount = customerSearchObj.runPaged().count;
                    var form = ui.createForm({
                        title: "Account Overview",
                    });
                    var restkFeeFld = form.addField({
                        id: "restockingfee",
                        type: ui.FieldType.TEXT,
                        label: "Restocking Fee"
                    });
                    var prcLevelFld = form.addField({
                        id: "pricelevel",
                        type: ui.FieldType.TEXT,
                        label: "Price Level"
                    });
                    restkFeeFld.updateDisplayType({
                        displayType: ui.FieldDisplayType.INLINE
                    });
                    prcLevelFld.updateDisplayType({
                        displayType: ui.FieldDisplayType.INLINE
                    });
                    var salesRepFld = form.addField({
                        id: "salesrep",
                        type: ui.FieldType.TEXT,
                        label: "Sales Rep"
                    });
                    salesRepFld.updateDisplayType({
                        displayType: ui.FieldDisplayType.INLINE
                    });

                    var salesRepEmailFld = form.addField({
                        id: "salesrepemail",
                        type: ui.FieldType.TEXT,
                        label: "Sales Rep Email"
                    });
                    salesRepEmailFld.updateDisplayType({
                        displayType: ui.FieldDisplayType.INLINE
                    });

                    var trackingNumberEmailFld = form.addField({
                        id: "trackingnumberemail",
                        type: ui.FieldType.TEXT,
                        label: "Tracking Number Email"
                    });
                    trackingNumberEmailFld.updateDisplayType({
                        displayType: ui.FieldDisplayType.INLINE
                    });

                    var customerServiceEmailFld = form.addField({
                        id: "customerserviceemail",
                        type: ui.FieldType.TEXT,
                        label: "Customer Service Email"
                    });
                    customerServiceEmailFld.updateDisplayType({
                        displayType: ui.FieldDisplayType.INLINE
                    });

                    var invUpdateEmailFld = form.addField({
                        id: "invupdateemail",
                        type: ui.FieldType.TEXT,
                        label: "Inventory Update Email"
                    });
                    invUpdateEmailFld.updateDisplayType({
                        displayType: ui.FieldDisplayType.INLINE
                    });

                    var accPayableEmailFld = form.addField({
                        id: "apemail",
                        type: ui.FieldType.TEXT,
                        label: "Accounts Payable Email"
                    });
                    accPayableEmailFld.updateDisplayType({
                        displayType: ui.FieldDisplayType.INLINE
                    });


                    customerSearchObj.run().each(function (result) {
                        restkFeeFld.defaultValue = result.getValue({name: "custentity_restock_fee"});
                        //prcLevelFld.defaultValue = result.getText({name: "pricelevel"});
                        priceLevelId = result.getValue({name: "pricelevel"});
                        salesRepFld.defaultValue = result.getText({name: "salesrep"});
                        salesRepEmailFld.defaultValue = result.getValue({name: "email", join: "salesrep"});

                        priceLevelValues = search.lookupFields({
                            type: "pricelevel",
                            id: priceLevelId,
                            columns: ["discountpct"]
                        });

                        prcLevelFld.defaultValue = !!priceLevelValues ? priceLevelValues.discountpct : "";

                        trackingNumberEmailFld.defaultValue = result.getValue({name: "custentity_tracking_email_contact"});
                        customerServiceEmailFld.defaultValue = result.getValue({name: "custentity_customer_service_email"});
                        invUpdateEmailFld.defaultValue = result.getValue({name: "custentity_inventory_update_email"});
                        accPayableEmailFld.defaultValue = result.getValue({name: "custentity_accounts_payable_email"});
                    });

                    context.response.writePage(form);

                } catch (ex) {
                    log.error('error in collecting account overview', ex.toString());
                    context.response.write('error in collecting account overview ' +
                        'please contact to Administrator');
                }
            } else {
                context.response.write('This operation not supported by this endpoint.');
            }
        }

        return {
            onRequest: onRequest
        };
    });

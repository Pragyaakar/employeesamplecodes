/**
 *@NApiVersion 2.0
 *@NScriptType ClientScript
 */
define(['N/error', 'N/url'],
    function (error, url) {

        function pageInit(parameters) {
        }

        function downloadCSV() {
            var hostURL = 'https://' + window.location.hostname;
            var suiteletURL = url.resolveScript({
                scriptId: 'customscript_fmt_custitemlisting',
                deploymentId: 'customdeploy_fmt_custitemlisting'
            });
            suiteletURL = hostURL + suiteletURL;
            suiteletURL = suiteletURL + '&type=csv';
            nlOpenWindow(suiteletURL);
        }

        return {
            pageInit: pageInit,
            downloadCSV: downloadCSV
        };
    });



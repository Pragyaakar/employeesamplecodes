/**
 * @NApiVersion 2.0
 * @NScriptType Suitelet
 */
/***********************************************************************
 *
 * The following javascript code is created by FMT Consultants LLC,
 * a NetSuite Partner. It is a SuiteFlex component containing custom code
 * intended for NetSuite (www.netsuite.com) and use the SuiteScript API.
 * The code is provided "as is": FMT Consultants LLC shall not be liable
 * for any damages arising out the intended use or if the code is modified
 * after delivery.
 *
 * Company:     FMT Consultants LLC, www.fmtconsultants.com
 * Author:      smehmood@fmtconsultants.com
 * File:        FMT_AM_ItemListing.js
 * Date:        5/4/2020
 *
 ***********************************************************************/

define(["N/ui/serverWidget", "N/runtime", "N/record", "N/search", "N/file"],
    function (ui, runtime, record, search, file) {
        var GLOBAL_VALUES = {};
        var CLIENT_SCRIPT_FILE = "SuiteScripts/[FMT] Custom Center Item Listing/client/FMT_AM_ItemListing_Client.js";
        var form, results = [], resultLine;

        function onRequest(context) {
            var scriptObj = runtime.getCurrentScript();
            var request = context.request;
            var userObj = runtime.getCurrentUser();
            var currentRole = userObj.role;
            var roleRec, roleSSId, itemSearch, columns, columnLabel, dataList, itemsListing, output, csvFileObj;
            GLOBAL_VALUES.type = request.parameters.type;
            log.debug('currentRole', currentRole);
            log.debug('GLOBAL_VALUES.type ', GLOBAL_VALUES.type);

            if (context.request.method === "GET") {
                try {
                    roleSSId = request.parameters.ssid;
                    if (!roleSSId)
                        roleSSId = getSSId(currentRole);

                    log.debug('roleSSId', roleSSId);

                    if (!!roleSSId) {
                        itemsListing = getItemsListing(roleSSId);
                        log.debug('GLOBAL_VALUES.columns ', JSON.stringify(GLOBAL_VALUES.columns));

                        if (!GLOBAL_VALUES.type || GLOBAL_VALUES.type == 'ui') {
                            output = getDataListUI(itemsListing);
                            context.response.writePage(output);
                        } else if (GLOBAL_VALUES.type == 'csv') {
                            log.debug('csv data preparation start');
                            output = getDataListCSV(itemsListing);
                            log.debug('csv data preparation end');
                            csvFileObj = file.create({
                                name: 'ItemListing.csv',
                                fileType: file.Type.CSV,
                                contents: output
                            });
                            context.response.writeFile(csvFileObj, false);
                        } else {
                            context.response.write('Invalid Output Type');
                        }
                    } else {
                        context.response.write('NO Item Listing Found for Current Role');
                    }
                } catch (ex) {
                    log.error('error in item listing preparation', ex.toString());
                    context.response.write('Unable to prepare Item Listing, please check saved search or ' +
                        'contact to Administrator');
                }
            } else {
                context.response.write('This operation not supported by this endpoint.');
            }
        }

        function getItemsListing(roleSSId) {
            var itemsData;
            if (!!roleSSId) {
                var itemSearch = search.load({
                    type: "item",
                    id: roleSSId
                });
                GLOBAL_VALUES.columns = itemSearch.columns;
                itemsData = searchAll(itemSearch.run());
            }
            return itemsData;
        }

        function searchAll(resultset) {
            var allResults = [];
            var startIndex = 0;
            var RANGECOUNT = 1000;

            do {
                var pagedResults = resultset.getRange({
                    start: parseInt(startIndex),
                    end: parseInt(startIndex + RANGECOUNT)
                });

                allResults = allResults.concat(pagedResults);

                var pagedResultsCount = pagedResults != null ? pagedResults.length : 0;
                startIndex += pagedResultsCount;

            }
            while (pagedResultsCount == RANGECOUNT);

            return allResults;
        }


        function getSSId(roleId) {
            var roleMapItemListing = search.create({
                type: "customrecord_fmt_rolewiseitemlisting",
                filters: [
                    ['custrecord_fmt_rilrole', 'is', roleId]
                ],
                columns: ['custrecord_fmt_rwilss']
            });
            var ssId, title;
            roleMapItemListing.run().each(function (result) {
                ssId = result.getValue({name: 'custrecord_fmt_rwilss'});
                title = result.getText({name: 'custrecord_fmt_rwilss'});
            });
            GLOBAL_VALUES.title = title;
            return ssId;
        }

        function getDataListUI(itemsData) {
            var columns = GLOBAL_VALUES.columns;
            var columnLabel, dataList, columnText, columnValue;
            dataList = ui.createList({
                title: 'Item Listing - ' + GLOBAL_VALUES.title
            });

            for (var c = 0; c < columns.length; c++) {
                columnLabel = columns[c].label;
                if (!columnLabel) {
                    columnLabel = columns[c].name;
                }
                log.debug('Adding Column to List', JSON.stringify(columns[c]));
                dataList.addColumn({
                    id: columns[c].name,
                    type: ui.FieldType.TEXT,
                    label: columnLabel
                    ,//align: serverWidget.LayoutJustification.RIGHT
                });
            }

            if (!!itemsData) {
                log.debug('itemsData.length', itemsData.length);
                for (var i = 0; i < itemsData.length; i++) {
                    resultLine = {};
                    for (var c = 0; c < columns.length; c++) {
                        columnText = itemsData[i].getText({
                            name: columns[c].name,
                            join: columns[c].join,
                            summary: columns[c].summary
                        });
                        if (!!columnText) {
                            resultLine[columns[c].name] = columnText;
                        } else {
                            resultLine[columns[c].name] = itemsData[i].getValue({
                                name: columns[c].name,
                                join: columns[c].join,
                                summary: columns[c].summary
                            });
                        }
                    }
                    //log.debug('resultLine : ' + i, JSON.stringify(resultLine));
                    //results.push(resultLine);

                    log.debug('Adding Row ', JSON.stringify(resultLine));

                    dataList.addRow({
                        row: resultLine
                    });
                }
                dataList.clientScriptModulePath = CLIENT_SCRIPT_FILE;
                dataList.addButton(
                    {
                        id: 'downloadcsv',
                        label: 'Download CSV',
                        functionName: 'downloadCSV'
                    }
                );
            }
            return dataList;
        }

        function getDataListCSV(itemsData) {
            var csvOutput = "", csvLine = "", columnData, columnLabel;
            if (itemsData != null) {
                var columns = GLOBAL_VALUES.columns;

                for (var c = 0; c < columns.length; c++) {
                    columnLabel = columns[c].label;
                    if (!columnLabel) {
                        columnLabel = columns[c].name;
                    }
                    csvOutput = csvOutput + "," + columnLabel;
                }
                csvOutput = csvOutput.substring(1, csvOutput.length);

                for (var i = 0; i < itemsData.length; i++) {
                    csvOutput = csvOutput + "\n";
                    csvLine = "";

                    for (var c = 0; c < columns.length; c++) {
                        columnData = itemsData[i].getText({
                            name: columns[c].name,
                            join: columns[c].join,
                            summary: columns[c].summary
                        });
                        if (!columnData) {
                            columnData = itemsData[i].getValue({
                                name: columns[c].name,
                                join: columns[c].join,
                                summary: columns[c].summary
                            });
                        }
                        columnData = columnData.toString();
                        columnData = columnData.replace(/["]/g, '\"\"');

                        if (!!columnData) {
                            csvLine = csvLine + ',"' + columnData + '"';
                        } else {
                            csvLine = csvLine + ',' + '" "';
                        }
                    }
                    csvLine = csvLine.substring(1, csvLine.length);
                    csvOutput = csvOutput + csvLine;
                }
            }
            return csvOutput;
        }

        function formatStringField(input) {
            return (input.getMonth() + 1) + "/" + input.getDate() + "/" + input.getFullYear();
        }

        return {
            onRequest: onRequest
        };
    });

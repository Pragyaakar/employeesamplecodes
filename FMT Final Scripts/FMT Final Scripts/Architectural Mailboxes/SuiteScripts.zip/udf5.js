function getUDF(){
          
          var salesOrder = nlapiGetFieldValue('createdfrom');
          if (salesOrder){
                   var itemfulfillmentSearch = nlapiSearchRecord("itemfulfillment",null,
                   [
                      ["type","anyof","ItemShip"], 
                      "AND", 
                      ["createdfrom","anyof",salesOrder], 
                      "AND", 
                      ["mainline","is","T"]
                   ], 
                   [
                      new nlobjSearchColumn("internalid",null,null)
                   ]
                   );
                   
                   var itemfulfillmentId = itemfulfillmentSearch[0].getValue('internalid');
                   
                   if (itemfulfillmentId){
                             var val = nlapiLookupField('itemfulfillment', itemfulfillmentId, 'custbodyhj_tc_udf5');
                             nlapiSetFieldValue('custbodyhj_tc_udf5', val);
                   }
          }
}

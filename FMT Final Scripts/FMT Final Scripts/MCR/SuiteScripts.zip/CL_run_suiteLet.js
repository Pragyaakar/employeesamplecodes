/**
 *@NApiVersion 2.0
 *@NScriptType ClientScript
 */


define(['N/ui/dialog','N/record'],

    function(dialog,record) {
    

        function pageInit(context,record) {
            currentRecord = context.currentRecord;
           return;
        }
        function callSuiteLet(context) {
          
            try {

            var commodity_owner = currentRecord.getValue({
            fieldId: 'custpage_commodity_owner'
            });
            var d_date = currentRecord.getText({
                fieldId: 'custpage_month_of_date'
            });
           // d_Date= format.parse({value: d_Date, type: format.Type.DATE})
           //  d_date= format.parse({value: d_date, type: format.Type.DATE})
           
            var baseUrl = window.location.href;
            baseUrl = baseUrl.substring(0, baseUrl.indexOf("deploy=1") + 8);
            if (_logValidation(commodity_owner))
                baseUrl = baseUrl + "&custpage_commodity_owner=" + commodity_owner

            if (_logValidation(d_date))
                baseUrl = baseUrl + "&custpage_month_of_date=" + d_date

            window.onbeforeunload = null;
            window.location.href = baseUrl;
            } catch (e) {

                log.error ({
                    title: e.name,
                    details: e.message
                });
            }
        }
        function _logValidation(value) {
            if (value != 'null' && value != '' && value != undefined && value != 'NaN') {
                return true;
            } else {
                return false;
            }
        }
        function clearFilters(context) {

            currentRecord.setValue({
                fieldId: 'custpage_commodity_owner',
                value: ''
            });
            currentRecord.setValue({
                fieldId: 'custpage_month_of_date',
                value: ''
            });
            window.onbeforeunload = null;
            window.location.href = 'https://5256277.app.netsuite.com/app/site/hosting/scriptlet.nl?script=1131&deploy=1';

        }


    return {
            pageInit: pageInit,
            callSuiteLet:callSuiteLet,
            clearFilters:clearFilters
    };
});
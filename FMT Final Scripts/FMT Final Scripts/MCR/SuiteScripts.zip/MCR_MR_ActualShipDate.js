/**
 * @NApiVersion 2.0
 * @NScriptType MapReduceScript
 */


 define(['N/search', 'N/record','N/error', 'N/runtime',],
 function(search,record,error,runtime)
 {
 	function getInputData(context)
 	{
 		try
 		{
 			var currentScript = runtime.getCurrentScript();

 			var iFSearch = currentScript.getParameter({name: 'custscript_mcr_update_if_search'});
			
			var savedSearch = search.load({id: iFSearch});
			
			var firstResult = searchAll(savedSearch.run());
			log.debug('firstResult =========>>>>>>> ', firstResult);
          
		    if(firstResult) 
		    {
		    	var lineMap = [];

		    	for (var k = 0; k < firstResult.length; k++) 
				{
					var tranID = firstResult[k].getValue({name: "internalid",sort: search.Sort.ASC,label: "Internal ID"});

					lineMap.push({
						'id': tranID
					})
				}
		    }

		    return lineMap;    
 		}
 		catch(e)
 		{
 			log.error('Error Occures', e);
 		}
 	}
 	function map(context)
 	{
 		var searchResult = JSON.parse(context.value); // Capture all values from getInputData function
 		log.debug('search result', searchResult);

 		var IF_id = searchResult.id;

 		var iFObj = record.load({    // Load customer record to capture required values 						
			type: record.Type.ITEM_FULFILLMENT, //from customer record
	    	id: IF_id,
	    	isDynamic: false
		});

 		var recordId = iFObj.save({
		    enableSourcing: true,
		    ignoreMandatoryFields: true
		});
 	}
    function searchAll(resultset) {
            var allResults = [];
            var startIndex = 0;
            var RANGECOUNT = 1000;

            do {
                var pagedResults = resultset.getRange({
                    start: parseInt(startIndex),
                    end: parseInt(startIndex + RANGECOUNT)
                });

                allResults = allResults.concat(pagedResults);
                //log.debug({title: '199',details: allResults});

                var pagedResultsCount = pagedResults != null ? pagedResults.length : 0;
                startIndex += pagedResultsCount;

                var remainingUsage = runtime.getCurrentScript().getRemainingUsage();
                //log.debug({title: '207', details: remainingUsage});

            }

            while (pagedResultsCount == RANGECOUNT);

            var remainingUsage = runtime.getCurrentScript().getRemainingUsage();
            //log.debug({title: '213', details: remainingUsage});

            return allResults;
        }
 	return {
	    getInputData: getInputData,
	    map: map,
	}
 });
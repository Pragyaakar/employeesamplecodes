/**
* @NApiVersion 2.x
* @NScriptType Restlet
* @NModuleScope Public
*/

/* 

------------------------------------------------------------------------------------------
Script Information
------------------------------------------------------------------------------------------

Name:
GraceBlood API

ID:
_gb_api

Description
The primary NetSuite API for GraceBlood.


------------------------------------------------------------------------------------------
Developer(s)
------------------------------------------------------------------------------------------

TD:
• Tim Dietrich
• timdietrich@me.com


------------------------------------------------------------------------------------------
History
------------------------------------------------------------------------------------------

20201208 - TD
Initial version.

*/


var 
	email,
	format,	
	log,
	query,
	record;


define( [ 'N/email', 'N/format', 'N/log', 'N/query', 'N/record' ], main );


function main( emailModule, formatModule, logModule, queryModule, recordModule ) {

	email = emailModule;
	format = formatModule;
	log = logModule;
	query = queryModule;
	record = recordModule;
	
    return {
        post: postProcess
    }

}


function postProcess( request ) {

 log.debug( { title: 'Request data', details: request } );
	
	switch ( request.function ) {
			
		case 'emailSend':
			return emailSend( request );
			break;		
			
		case 'recordEnumerationsGet':
			return record;
			break;				
			
		case 'recordGet':
			return recordGet( request );
			break;
			
		case 'requestEcho':
			return request;
			break;				

		case 'salesOrderCreate':
			return salesOrderCreate( request );
			break;	
							
		case 'suiteQLRun':
			return suiteQLRun( request );
			break;	
			
		case 'transactionUpdate':
			return transactionUpdate( request );
			break;								

		default:
			var response = { 'error': 'Unsupported Function' }
			return response;
	
	}

}  



// ---------------------------------------------------------------------------------------
// Email
// ---------------------------------------------------------------------------------------

function emailSend( request ) {	

	// Validate the request...
	if ( typeof request.author == 'undefined' ) { return { 'error': 'No author was specified.' } }
	if ( typeof request.recipients == 'undefined' ) { return { 'error': 'No recipients were specified.' } }	
	if ( typeof request.subject == 'undefined' ) { return { 'error': 'No subject was specified.' } }	
	if ( typeof request.body == 'undefined' ) { return { 'error': 'No body was specified.' } }		
	
	// If attachments were specified...
	if ( typeof request.attachments != 'undefined' ) {
	
		// Create an array of file objects.	
		var attachments = [];
		
		// Loop over the file IDs that were specified in the request...
		for ( var i = 0; i < request.attachments.length; i++ ) { 
	
			// Get the file ID.
			var fileID = request.attachments[i];	
			
			// Load the file.
			var fileObj = file.load( { id: fileID } );	
			
			// Add the file object to the array.
			attachments.push( fileObj );
			
		}
		
		// Replace the value in the request with the array of file objects.
		request.attachments = attachments;
				
	}		

	try {
	 
	 	email.send( request );
		
		return 'sent';
	
	} catch( e ) {	
		return e;	
	}		

}


// ---------------------------------------------------------------------------------------
// Records
// ---------------------------------------------------------------------------------------

function recordGet( request ) {

	// Validate the request...
	if ( typeof request.recordType == 'undefined' ) {
		return { 'error': 'No recordType was specified.' }
	}	
	if ( typeof request.recordID == 'undefined' ) {
		return { 'error': 'No recordID was specified.' }
	}		

	// Load the record.
	result = record.load( { type: request.recordType, id: request.recordID, isDynamic: false } );		
	
	// Return the result.
	return result;	
	
} 



// ---------------------------------------------------------------------------------------
// Sales Orders
// ---------------------------------------------------------------------------------------

function salesOrderCreate( request ) {	

	// Lookup the ID of the entity...
    	
		var sql = [
			'SELECT',
			'ID',
			'FROM',
			'Customer',
			'WHERE',
			'( ExternalID = \'' + request['entity']['externalId'] + '\' )',
			'AND ( ROWNUM = 1 )'
		].join(" \n");    
		
		log.debug( 
			{
				title: 'sql',
				details: sql
			}
		);		
		
		// Execute the query.
		var queryResults = query.runSuiteQL( { query: sql } );

		// Get the results.
		var records = queryResults.asMappedResults();
		
		// If a record was found...
		if ( records.length == 1 ) {	
		
			// Get the purchase contract ID.
			var entityID = records[0]['id'];	
			
		} else {
		
			log.error( 
				{
					title: 'Customer Lookup Failed',
					details: 'External ID: ' + request['entity']['externalId']
				}
			);			
			
			return { 'error': 'Customer Lookup Failed.' }
		
		}

	// Format dates in the request...
	var shipDate = format.parse( { value: request['shipDate'], type: format.Type.DATE } );
	
	// Create a record.
	var theRecord = record.create( { type: 'salesorder', isDynamic : true } );
	
	// Specify the custom form to be used.
	theRecord.setValue( { fieldId: 'customform', value: request['customform'] } );
		
	// Set body field values...	
	theRecord.setValue( { fieldId: 'entity', value: entityID } );
	theRecord.setValue( { fieldId: 'otherrefnum', value: request['otherRefNum'] } );
	theRecord.setValue( { fieldId: 'shipdate', value: shipDate } );
	theRecord.setValue( { fieldId: 'memo', value: request['memo'] } );

		
	// Create the items...
	// log.debug( { title: 'items', details: request['item']['items'] } );
	for ( var i = 0; i < request['item']['items'].length; i++ ) { 
	
		// Get the next item from the request.
		var item = request['item']['items'][i];	
		// log.debug( { title: 'item ' + i, details: item } );
		
		// Lookup the ID of the item...
		
			var sql = [
				'SELECT',
				'ID',
				'FROM',
				'Item',
				'WHERE',
				'( ExternalID = \'' + item['item']['externalId'] + '\' )',
				'AND ( ROWNUM = 1 )'
			].join(" \n");    

			log.debug( 
				{
					title: 'sql',
					details: sql
				}
			);		

			// Execute the query.
			var queryResults = query.runSuiteQL( { query: sql } );

			// Get the results.
			var records = queryResults.asMappedResults();

			// If a record was found...
			if ( records.length == 1 ) {	

				// Get the purchase contract ID.
				var itemID = records[0]['id'];	
	
			} else if (item['item']['externalId']== 'Savoy Discount') {
              var itemID = '467'
            } else {

				log.error( 
					{
						title: 'Item Lookup Failed',
						details: 'External ID: ' + item['item']['externalId']
					}
				);			
	
				return { 'error': 'Item Lookup Failed: ' + item['item']['externalId'] }

			}		
		

		// Select the item sublist line.
		theRecord.selectNewLine( { sublistId: 'item' } );
		
		// Set the sublist line fields...
		theRecord.setCurrentSublistValue( { sublistId: 'item', fieldId: 'item', value: itemID } );	
		theRecord.setCurrentSublistValue( { sublistId: 'item', fieldId: 'quantity', value: item['quantity'] } );	
		theRecord.setCurrentSublistValue( { sublistId: 'item', fieldId: 'rate', value: item['rate'] } );
      	theRecord.setCurrentSublistValue( { sublistId: 'item', fieldId: 'location', value: item['location'] } );
      
      	// AD 12/11/2020: Set the Description on Line Item for NonStock [999-PARTS]
		if (itemID == '34642'){
			theRecord.setCurrentSublistValue( { sublistId: 'item', fieldId: 'description', value: item['description'] } );			
		};
		
						
		// Commit the sublist line. 
		theRecord.commitLine( { sublistId: 'item' } );
				
	}	
	
	// Add the address...
	
		// If a shipto ID wasn't specified...
		if ( typeof request.shiptoid == 'undefined' ) { 

			// Override the default address.
			theRecord.setValue( { fieldId: 'shipaddresslist', value: null } );

			// Get the address subrecord.
			var shipaddrSubrecord = theRecord.getSubrecord( { fieldId: 'shippingaddress' } );

			// Set subrecord values...
			shipaddrSubrecord.setValue( { fieldId: 'addressee', value: request['shippingaddress']['addressee'] }) ;
			shipaddrSubrecord.setValue( { fieldId: 'addr1', value: request['shippingaddress']['addr1'] }) ;
			shipaddrSubrecord.setValue( { fieldId: 'addr2', value: request['shippingaddress']['addr2'] }) ;
			shipaddrSubrecord.setValue( { fieldId: 'addr3', value: request['shippingaddress']['addr3'] }) ;
			shipaddrSubrecord.setValue( { fieldId: 'addrPhone', value: request['shippingaddress']['addrPhone'] }) ;
			shipaddrSubrecord.setValue( { fieldId: 'city', value: request['shippingaddress']['city'] }) ;
			shipaddrSubrecord.setValue( { fieldId: 'country', value: request['shippingaddress']['country'] }) ;
			shipaddrSubrecord.setValue( { fieldId: 'state', value: request['shippingaddress']['state'] }) ;
			shipaddrSubrecord.setValue( { fieldId: 'zip', value: request['shippingaddress']['zip'] }) ;
			
		} else {
		
			theRecord.setValue( { fieldId: 'shipaddresslist', value: request['shiptoid'] } );
		
		}

	// Save the record.
	var recordID = theRecord.save( 
		{ 
			enableSourcing: true, 
			ignoreMandatoryFields: true 
		} 
	);			

	// Load the parent record that was created.
	response = record.load( { type: 'salesorder', id: recordID } );
	
	// Return the record.
	return response;	

}



function suiteQLRun( request ) {

	var records = query.runSuiteQL( request['sql'] ).asMappedResults();		
	return { 'records': records }					
		
} 



function transactionUpdate( request ) {	

	// Load the record.
	var theRecord = record.load( { type: request['type'], id: request.id, isDynamic: true } );
	
	// Loop over the fields in the request object...
	for ( var fieldName in request['fields'] ) {
		
		// Set the record's field value.
		theRecord.setValue( { fieldId: fieldName, value: request['fields'][fieldName] } );
				
	}	
					
	// Save the record.
	var recordID = theRecord.save( 
		{ 
			enableSourcing: true, 
			ignoreMandatoryFields: true 
		} 
	);	
	
	// Load the record that was updated.
	response = record.load( { type: request['type'], id: recordID } );
	
	// Return the record.
	return response;	

}



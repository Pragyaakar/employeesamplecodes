/**
* @NApiVersion 2.x
* @NScriptType Suitelet
* @NModuleScope SameAccount
*/
var total_rtn= 0 ;
var total_net = 0;
var total_inv =0 ;
define(['N/ui/serverWidget', 'N/record', 'N/runtime', 'N/log','N/search'],
    
    function(serverWidget, record, runtime, log, search) {
          
          function onRequest(context) {

              if(context.request.method === 'GET'){
                
                var commodity_owner = context.request.parameters.custpage_commodity_owner;   
                var d_date = context.request.parameters.custpage_month_of_date;
               
                var form = serverWidget.createForm({
                title: 'Returns to Sales Ratio'
                });
                form.clientScriptFileId = 131756;
                var commodityOwner = form.addField({
                    id : 'custpage_commodity_owner',
                    type : serverWidget.FieldType.SELECT,
                    source: 'customlist329',
                    label : 'Commodity Owner'
                });
                var date = form.addField({
                    id : 'custpage_month_of_date',
                    type : serverWidget.FieldType.DATE,
                    label : 'Month of Date'
                });
              
              form.addResetButton({label: 'Reset'});
              var run = form.addButton({
              id : 'custom_run',
              label : 'RUN',
              functionName: 'callSuiteLet()'
              });
              var clearFilter = form.addButton({
              id : 'custom_clearfilter',
              label : 'Clear Filters',
              functionName: 'clearFilters()'
              });
            
            log.debug("form=====>>>>>>>>>>>>>",form);
            // Add sublist that will show results
            var sublist = form.addSublist({
                    id : 'custpage_table',
                    type : serverWidget.SublistType.LIST,
                    label : 'Transactions'
                });

             log.debug("sublist=====>>>>>>>>>>>>>",sublist);
            // Add columns to be shown on Page
            sublist.addField({
                id : 'custpage_month',
                label : 'Month of date',
                type : serverWidget.FieldType.TEXT
            });
            sublist.addField({
                id : 'custpage_invoicetotal',
                label : 'INVOICE TOTAL',
                type : serverWidget.FieldType.TEXT
            });
             sublist.addField({
                id : 'custpage_returntotal',
                label : 'RETURNS TOTAL',
                type : serverWidget.FieldType.TEXT
            });
              sublist.addField({
                id : 'custpage_nettotal',
                label : 'NET',
                type : serverWidget.FieldType.TEXT
            });
               sublist.addField({
                id : 'custpage_return_per',
                label : 'PERCENT OF ORDERS WERE RETURNS',
                type : serverWidget.FieldType.TEXT
            });
                                
                var mySearch = search.load({
                id: 'customsearch_rob_sales_2_returns_2'
               });

      var filters = mySearch.filters; //reference Search.filters object to a new variable
      if(commodity_owner){
         filters.push(search.createFilter({ //create new filter
            name: 'custbody5',
            operator: search.Operator.ANYOF,
            values: commodity_owner
        }));

      //filters.push(); //add the filter using .push() method*/
//"trandate","onorafter","1/1/2020"
      }

      log.debug("commodity_owner=====>>>>>>>>>>>>>",commodity_owner);
      log.debug("d_date=====>>>>>>>>>>>>>",d_date);

   // d_date= format.parse({value: d_date, type: format.Type.DATE})
      if(d_date){
         filters.push(search.createFilter({ //create new filter
            name: 'trandate',
            operator: search.Operator.ONORAFTER,
            values: d_date
        }));
      }
      
              var searchResult = mySearch.run().getRange({
              start: 0,
              end: 1000
            });
          var count =0;
          for (var i = 0; i < searchResult.length; i++){
            var total_per = 0;
            var group_date = searchResult[i].getValue({
                name: 'trandate',
                summary : 'GROUP',

            });
             var invTotal = 0;/*searchResult[i].getValue({
                name: "formulacurrency",
                summary: "SUM",
                formula: "CASE WHEN {type}='Invoice' then {amount} else 0 end"
               // label: "Invoice Total"

            });*/
            var returnTotal = searchResult[i].getValue({
               name: "formulacurrency",
               summary: "SUM",
               formula: "CASE WHEN {type}='Credit Memo' then {amount} else 0 end"
               // label: "Returns Total"

            });
            var netTotal = searchResult[i].getValue({
               name: "amount",
               summary:"SUM",
              //label: "Net"

            });
            total_per = (parseFloat(returnTotal*-1)/parseFloat(netTotal))*100;
            //log.debug("group_date=====>>>>>>>>>>>>>",group_date);
           // log.debug("invTotal=====>>>>>>>>>>>>>",invTotal);
            //log.debug("returnTotal=====>>>>>>>>>>>>>",returnTotal);
            //log.debug("netTotal=====>>>>>>>>>>>>>",netTotal);

            total_rtn = total_rtn + total_per;
           //total_net;
           //total_inv;
            sublist.setSublistValue({
                        id: 'custpage_month',
                        line: i,
                        value: group_date
                        
                    });
            invTotal = parseFloat(returnTotal) - parseFloat(netTotal);
            invTotal = invTotal*-1;
            sublist.setSublistValue({
                        id: 'custpage_invoicetotal',
                        line: i,
                        value: invTotal.toFixed(2)
                        
                    });
              sublist.setSublistValue({
                        id: 'custpage_returntotal',
                        line: i,
                        value: returnTotal
                        
                    });
             
              sublist.setSublistValue({
                        id: 'custpage_nettotal',
                        line: i,
                        value: netTotal
                        
                    });

              sublist.setSublistValue({
                        id: 'custpage_return_per',
                        line: i,
                        value: total_per.toFixed(2)+'%'
                        
                    });

        count++;

             //invTotal
        }
        //= sublist.lineCount;
        
       /* sublist.setSublistValue({
                        id: 'custpage_return_per',
                        line: count+1,
                        value: total_rtn.toFixed(2)
                        
                    });   */
        context.response.writePage(form);
    }
                
}

return {
  onRequest: onRequest
};
    
});
function beforeLoad(){

var department = nlapiGetLineItemField('expense', 'department');

department.setMandatory(true);
}
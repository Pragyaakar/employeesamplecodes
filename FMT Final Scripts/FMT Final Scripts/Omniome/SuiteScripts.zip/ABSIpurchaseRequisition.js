function beforeLoad(type, form, request){

	var customForm= nlapiGetFieldValue('customform');
	nlapiLogExecution('DEBUG', 'customForm', 'customForm: ' + customForm);

	var description = nlapiGetLineItemField('item', 'description');
		description.setMandatory(true);

	var custcol11 = nlapiGetLineItemField('item', 'custcol1');
		custcol11.setMandatory(true);

	var estimatedAmount = nlapiGetLineItemField('item', 'estimatedamount');
		estimatedAmount.setDisplayType('disabled');

	var attachFile = nlapiGetLineItemField('item', 'custcol_attachfile');
		attachFile.setDisplayType('normal');

	if(customForm=='112'){

		var item = nlapiGetLineItemField('item', 'item');
		item.setDisplayType('disabled');
	}
}


function fieldChange(type, name){

	if(type=='item' && name=='custcol_itemlist'){

		var itemID = nlapiGetCurrentLineItemValue('item', 'custcol_itemlist');
		nlapiLogExecution('DEBUG', 'itemID', 'itemID: ' + itemID);

		if(itemID!=null || itemID!=''){

			nlapiSetCurrentLineItemValue('item', 'item', itemID);
		}
	}
}
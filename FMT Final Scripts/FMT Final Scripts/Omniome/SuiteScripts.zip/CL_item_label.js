/**
* @NApiVersion 2.0
* @NScriptType ClientScript
*/
var TranId;
define(['N/url','N/record','N/ui/dialog','N/runtime', 'N/currentRecord'],
function(url,record,dialog,runtime,currentRecord) 
{
	
	function pageInit(context,record,currentRecord) {
            var Obj = context.currentRecord;
           return;
        }

	function callSuitelet()
	{
       var recno = currentRecord.get().id;

		var output = url.resolveScript({
		    scriptId: 'customscript_sut_item_label',
		    deploymentId: 'customdeploy_sut_item_label',
		    returnExternalUrl: true
		});

		output = output + '&recno=' + recno;

		window.open(output,'_blank');

		//dialog.alert(optionsRec);

	}

	return {
	pageInit : pageInit,
	callSuitelet: callSuitelet
	};
});
/**
 *@NApiVersion 2.x
 *@NScriptType MapReduceScript
 */
define(['N/record','N/search','N/format','N/runtime','N/xml'],
  function(record,search,format,runtime,xml) {
    function getInputData(context) 
    {
        try
        {
            var savedSearch = search.load({
                id: 'customsearch_fmt_requisition_search'
            });
            //log.debug(' getInputData savedSearch',savedSearch);

            var resultSet = searchAll(savedSearch.run()); 

            if(resultSet)
            {
              var acceptValues = [];

              for(var i=0; i<resultSet.length; i++)
              {
                  var req = resultSet[i].getValue({name: "entityid", join: "CUSTCOL_REQUESTOR", label: "Requestor"});
                  var req_id = resultSet[i].getValue({name: "internalid", join: "CUSTCOL_REQUESTOR", label: "Internal ID"});
                  var req_date = resultSet[i].getValue({name: "trandate", label: "Date"});
                  var req_delvDate = resultSet[i].getValue({name: "custcol_requested_delivery_date", label: "Requested Delivery Date"});
                  var req_memo = resultSet[i].getValue({name: "memo", label: "Memo"});
                  var req_dep = resultSet[i].getValue({name: "department", label: "Department"});
                  var req_item = resultSet[i].getValue({name: "item", label: "Item"});
                  var req_qty = resultSet[i].getValue({name: "quantity", label: "Quantity"});
                  var req_rate = resultSet[i].getValue({name: "rate", label: "Rate"});
                  var req_email = resultSet[i].getValue({name: "email",join: "CUSTCOL_REQUESTOR",label: "Email"});
                  var internalid = resultSet[i].getValue({name: "internalid", label: "PR Internal Id"});
                                   
                  acceptValues.push({ 
                    '_req': req,
                    '_req_date': req_date,
                    '_req_delvDate': req_delvDate,
                    '_req_memo': req_memo,
                    '_req_dep': req_dep,
                    '_req_item': req_item,
                    '_req_qty': req_qty,
                    '_req_rate': req_rate,
                    '_req_id':req_id,
                    '_email':req_email,
                    '_int_id':internalid
                  });
              }

              //log.debug('acceptValues',acceptValues);
              return acceptValues;
            }
        }
                
        catch(e)
        {
            log.debug('ERROR IN getData() FUNCTION',e);
        }
    }
    function map(context) 
    {
        try
        {
            var searchResult = JSON.parse(context.value);//to get value from above getInput() function
            //log.debug('map result', searchResult);

            var _req = searchResult._req;
            var _reqDate = searchResult._req_date;
            var _reqDelvDate = searchResult._req_delvDate;
            var _reqMemo = searchResult._req_memo;
            var _reqDep = searchResult._req_dep;
            var _reqItem = searchResult._req_item;
            var _reqQty = searchResult._req_qty;
            var _reqRate = searchResult._req_rate;
            var req_nameid = searchResult._req_id;
            var reqEmail = searchResult._email;
            var req_int_id = searchResult._int_id;

          context.write({
            key: req_nameid,
            value: {
              'tranDate':_reqDate,
              'deliveryDate':_reqDelvDate,
              'memo' : _reqMemo,
              'department' : _reqDep,
              'item' : _reqItem,
              'quantity' : _reqQty,
              'rate' : _reqRate,
              'requester': _req,
              'emailID':reqEmail,
              'int_id':req_int_id
            }
          });
        }
        catch(e)
        {
            log.debug('ERROR IN MAP FUNCTION', e);
        }
    }

    function reduce(context) 
    {
        var req_Name = context.key;
        
         /*req_Name = xml.escape({
                xmlText : req_Name
            });*/

        var tempmapValueData =  JSON.parse(context.values[0]);
        var trandate = tempmapValueData.tranDate;
        var department_id = tempmapValueData.department;
        var req_txt = tempmapValueData.requester;
        //log.debug('customer Name', req_txt);

        var emailVal = tempmapValueData.emailID;
       // log.debug('emailVal', emailVal);

        var idTran = tempmapValueData.int_id;
        //var customer_id = req_Name; //createCustomer(req_Name);

        var customerName = createCustomer(emailVal,req_txt);
        //log.debug('customerName', customerName);

        var resultData = {};
        resultData = {
          "custname":customerName,
          "tran_date": trandate,
          "departmentName": department_id,
          "idTran": idTran
        };

        resultData.lines = [];

        for(var j = 0; j < context.values.length; j++) {
            resultLine = {};
            var mapValueData = JSON.parse(context.values[j]);
            resultLine.description = mapValueData.memo;
            resultLine.quantity = mapValueData.quantity;
            resultLine.rate = mapValueData.rate;
            resultLine.deliveryDate = mapValueData.deliveryDate;
            resultLine.item = mapValueData.item;
            resultData.lines.push(resultLine);
        }

        log.debug('resultData====>' , JSON.stringify(resultData));
        
        createSalesOrder(resultData);
    }

    //create customer record 

    function createCustomer(email,employee){
      
      log.debug('email', email);

        var customerSearchObj = search.create({
           type: "customer",
           filters:
           [
              ["isinactive","is","F"], "AND" ,["email","is",email]
           ],
           columns:
           [
              search.createColumn({
                 name: "internalid",
                 sort: search.Sort.ASC,
                 label: "Internal ID"
              }),
              search.createColumn({name: "internalid", label: "Internal ID"})
           ]
        });

        var resultSet = searchAll(customerSearchObj.run()); 
       // log.debug('resultSet Length', resultSet.length);
       // log.debug('before set employee', employee);

        var customer_id = "";
        //firstResult.length
       if(resultSet.length<=0)
       {
           // log.debug('inside', 'inside');
            //Create Customer Record 
            var createRec = record.create({
              type: record.Type.CUSTOMER,
              isDynamic: true
            });
           // log.debug('createRec', createRec);

            //Set values in Customer record
            createRec.setValue({
              fieldId: 'companyname',
              value: xml.escape(employee)
            });
           // log.debug('set employee', employee);

            createRec.setValue({
              fieldId: 'email',
              value: email
            });
           // log.debug('set email', email);

            customer_id = createRec.save(); 
           // log.debug('customer_id', customer_id);
        }
        else 
        {
            //log.debug('Enter in else part');

            var results = customerSearchObj.run().getRange({
              start: 0,
              end: 1
            });
           // log.debug('results',results.length);

            for(var i in results) //var i in results
            {
                //log.debug('Found custom list record', results[i]);
                customer_id = results[i].getValue({
                    name:'internalid'
                });
            }
        }
        //log.debug('customer_id 222', customer_id);
        return customer_id ;
    }
 
    function createSalesOrder(resultData){
try{
    //log.debug('createSalesOrder');

      log.debug(" createSalesOrder resultData", JSON.stringify(resultData));

      var _tranId = resultData.idTran;
      log.debug('_tranId',_tranId);

      var createSO = record.create({
      type: record.Type.SALES_ORDER,
      isDynamic: true,
      });

      createSO.setValue({
        fieldId: 'entity',
        value: resultData.custname
      });

      resultData.tran_date = format.parse({
       value: resultData.tran_date,
       type: format.Type.DATE
        });
      
      createSO.setValue({
        fieldId: 'trandate',
        value: resultData.tran_date
      });

      createSO.setValue({
        fieldId: 'department',
        value: resultData.departmentName
      });

      createSO.setValue({
        fieldId: 'custbody_fmt_requisition_reference_num',
        value: resultData.idTran
      });

     // log.debug('resultData lines',JSON.stringify(resultData.lines));

      var lineArray = resultData.lines;
      for(var count in lineArray){

          var tran_item = lineArray[count].item;
          log.debug('tran_item',tran_item);

          var description_val = lineArray[count].description;
          log.debug('description_val',description_val);

          var tran_quantity = lineArray[count].quantity;
          log.debug('tran_quantity',tran_quantity);

          var tran_deliveryDate = lineArray[count].deliveryDate;
          log.debug('tran_deliveryDate',tran_deliveryDate);

          var tran_rate = lineArray[count].rate;
          log.debug('tran_rate',tran_rate);

          //Set Sales order line level fields
          //return;
          createSO.selectNewLine({
              sublistId: 'item'
          });

          createSO.setCurrentSublistValue({
              sublistId: 'item',
              fieldId: 'item',
              value: tran_item
          });

          createSO.setCurrentSublistValue({
              sublistId: 'item',
              fieldId: 'description',
              value: description_val
          });

          createSO.setCurrentSublistValue({
              sublistId: 'item',
              fieldId: 'quantity',
              value: tran_quantity
          });

          createSO.setCurrentSublistValue({
              sublistId: 'item',
              fieldId: 'rate',
              value: tran_rate
          });

          createSO.commitLine('item');
      }

      var recordId = createSO.save();     
      log.debug('SO recordId',recordId); 

      if(recordId)
      {
        var reqObj = record.load({
            type: record.Type.PURCHASE_REQUISITION,
            id: _tranId,
            isDynamic: true,
        });

        reqObj.setValue({
          fieldId: 'custbody_fmt_sales_order_reference',
          value: recordId
        });

        var saveRec = reqObj.save();     
        log.debug('saveRec',saveRec); 
      }

}catch(e){

    log.debug('EROR in Sales order creation',e.toString()); 
    }
      
  }

function searchAll(resultset) {
    var allResults = [];
    var startIndex = 0;
    var RANGECOUNT = 1000;

     do {
    var pagedResults = resultset.getRange({
    start: parseInt(startIndex),
    end: parseInt(startIndex + RANGECOUNT)
    });

     allResults = allResults.concat(pagedResults);
    //log.debug({title: '199',details: allResults});

     var pagedResultsCount = pagedResults != null ? pagedResults.length : 0;
    startIndex += pagedResultsCount;

     var remainingUsage = runtime.getCurrentScript().getRemainingUsage();
    //log.debug({title: '207', details: remainingUsage});

     }

     while (pagedResultsCount == RANGECOUNT);

     var remainingUsage = runtime.getCurrentScript().getRemainingUsage();
    //log.debug({title: '213', details: remainingUsage});

     return allResults;
}

    return {
     getInputData: getInputData,
     map : map,
     reduce : reduce
     };
});
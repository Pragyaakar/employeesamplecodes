/**
* @NApiVersion 2.0
* @NScriptType ClientScript
*/


define(['N/url','N/record','N/ui/dialog','N/runtime', 'N/currentRecord', 'N/https','N/log'],
function(url,record,dialog,runtime,currentRecord, https, log) 
{
	
	function pageInit(context) {
       	
       		//return;
        }

	function callSuitelet()
	{
      	var recno = currentRecord.get();
      	
      	var rectype = currentRecord.get().type;
     	//alert('rectype===>' + rectype)

		var tranDate = recno.getValue({fieldId: 'trandate'});

        var newDate = (tranDate.getMonth()+1)+'/' + tranDate.getDate() + '/'+ tranDate.getFullYear();

        var IRLineCount = recno.getLineCount({'sublistId': 'item'});
       //	alert('IRLineCount===>' + IRLineCount);

       	var param = [];

		for(var q = 0; q<IRLineCount ;q++)
		{	
			var Receive_item = recno.getSublistValue({sublistId: 'item', fieldId: 'itemreceive', line: q});
			
			//alert('Receive_item===>' + Receive_item);

			if(Receive_item == true)
			{
				var item = recno.getSublistValue({sublistId: 'item', fieldId: 'item', line: q});
				var quantity = recno.getSublistValue({sublistId: 'item', fieldId: 'quantity', line: q});
				var paramVal = {'date':newDate,'item':item,'qty':quantity};
				param.push(paramVal);
			}
		}


		param = JSON.stringify(param)
		

		var output = url.resolveScript({
		    scriptId: 'customscript_fmt_sut_autolot_num',
		    deploymentId: 'customdeploy_fmt_sut_autolot_num'
		});

		var finalURL = 'https://5711325-sb1.app.netsuite.com'+ output;

			var headerObj = {
			    name:'Content-Type',
			    value: 'application/json'
			};

		var response = https.post({
		    url: finalURL,
		    body: param,
		    header:headerObj
		 });

		
		var response_parse = JSON.parse(response.body);
		
		if(response_parse)
		{	
			
			for(var q = 0 ; q < response_parse.length; q++)
			{
				var item = response_parse[q].item_id;
				var tran_qty = response_parse[q].qty;
				var inv_det = response_parse[q].inv_detail;

				//alert('item ===>' +item);
				//alert('tran_qty ===>' +tran_qty);
				//alert('inv_det ===>' +inv_det);
				
				recno.selectLine({
            		sublistId: 'item',
            		line: 0
        		});
				var objSubrecord = recno.getCurrentSublistSubrecord({sublistId: 'item', fieldId: 'inventorydetail'});
				try{

				
				//alert('objSubrecord===>' + objSubrecord);
				debugger;
				objSubrecord.selectNewLine({
				sublistId: 'inventoryassignment'
				});

				//objSubrecord.selectLine({ sublistId: 'inventoryassignment', line: 0 });
				
				objSubrecord.setCurrentSublistValue({
				sublistId: 'inventoryassignment',
				fieldId: 'quantity',
				value: tran_qty
				});

				objSubrecord.setCurrentSublistValue({
				sublistId: 'inventoryassignment',
				fieldId: 'issueinventorynumber',
				value: inv_det
				});
								
				objSubrecord.commitLine({
				sublistId: 'inventoryassignment'
				});

				  recno.commitLine({
            		sublistId: 'item'
       			 });

				  }catch(e){

				  	alert('Error Message ====>' + e.toString());
				  }
			}

			/*var recordId = recno.save({
   			 enableSourcing: true,
    		 ignoreMandatoryFields: true
			});*/
		}
	}

	return {
	pageInit : pageInit,
	callSuitelet: callSuitelet
	};
});
function callSuitelet(){
		alert('we are in.............')
		var tranDate = nlapiGetFieldValue( 'trandate');

        //var newDate = (tranDate.getMonth()+1)+'/' + tranDate.getDate() + '/'+ tranDate.getFullYear();

        var IRLineCount = nlapiGetLineItemCount('item');
       	//alert('IRLineCount===>' + IRLineCount);

       	var param = [];

		for(var q = 1; q<=IRLineCount;q++)
		{	
			var Receive_item = nlapiGetLineItemValue('item', 'itemreceive', q);
			
			//alert('Receive_item===>' + Receive_item);

			if(Receive_item != 'F')
			{
				var item = nlapiGetLineItemValue('item', 'item', q);
				//alert('item===>' + item);
				var quantity = nlapiGetLineItemValue('item',  'quantity', q);
				//alert('quantity===>' + quantity);
				var paramVal = {'date':tranDate,'item':item,'qty':quantity};
				param.push(paramVal);
			}
		}


		param = JSON.stringify(param);

		alert('param===>' + param);


		var output = nlapiResolveURL('SUITELET', 'customscript_fmt_sut_autolot_num', 'customdeploy_fmt_sut_autolot_num');
		
		//alert('output===>' + output);
		
		var finalURL = 'https://5711325-sb1.app.netsuite.com'+ output;
		alert('finalURL===>' + finalURL);

		var headerObj = {
			    name:'Content-Type',
			    value: 'application/json'
			};

		var response = nlapiRequestURL(finalURL, param, headerObj ,'POST');

		var response_parse = JSON.parse(response.getBody());

		alert('response_parse===>' + response_parse);

		if(response_parse)
		{	
			
			for(var q = 0 ; q < response_parse.length; q++)
			{
				var item = response_parse[q].item_id;
				alert('item===>' + item);

				var tran_qty = response_parse[q].qty;
				alert('tran_qty===>' + tran_qty);

				var inv_det = response_parse[q].inv_detail;
				alert('inv_det===>' + inv_det);
				try{
				var objSubrecord = nlapiCreateSubrecord('inventorydetail')//('item', 'inventorydetail');

				objSubrecord.selectNewLineItem('inventoryassignment');
				objSubrecord.setCurrentLineItemValue('inventoryassignment', 'issueinventorynumber', 'testinv2343');
				objSubrecord.setCurrentLineItemValue('inventoryassignment', 'quantity', 1);
				objSubrecord.commitLineItem('inventoryassignment');
				//commit Inventory Detail subrecord to parent record
				objSubrecord.commit();

				}catch(e){

				  	alert('Error Message ====>' + e.toString());
				  }

			}
		}
}
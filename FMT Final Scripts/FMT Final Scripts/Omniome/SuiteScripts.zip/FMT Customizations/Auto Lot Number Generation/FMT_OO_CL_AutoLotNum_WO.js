/**
* @NApiVersion 2.0
* @NScriptType ClientScript
*/


define(['N/url','N/record','N/ui/dialog','N/runtime', 'N/currentRecord', 'N/https','N/log'],
function(url,record,dialog,runtime,currentRecord, https, log) 
{
	
	function pageInit(context) 
	{
       	//return;
    }

	function callSuitelet()
	{	
		var recno = currentRecord.get();
      	//alert('recno===>' + recno)

      	var recID =  currentRecord.get().id;

      	var rectype = currentRecord.get().type;
     	//alert('rectype===>' + rectype)
	
		var tranDate = recno.getValue({fieldId: 'trandate'});
		
		var newDate = (tranDate.getMonth()+1)+'/' + tranDate.getDate() + '/'+ tranDate.getFullYear();
		//alert('newDate===>' + newDate)

        var assembly = recno.getValue({fieldId: 'assemblyitem'});
        //alert('assembly===>' + assembly)

        var qty = recno.getValue({fieldId: 'quantity'});
		//alert('qty===>' + qty)

       	var param = [];

		var paramVal = {'tran_date':newDate,'assembly_item':assembly,'qty_val':qty,'recid':recID,'rectype':rectype};
		//alert('paramVal===>' + paramVal)

		param.push(paramVal);
		param = JSON.stringify(param)
		//alert('param===>' + param)

		var output = url.resolveScript({
		    scriptId: 'customscript_fmt_sut_autolot_wo',
		    deploymentId: 'customdeploy_fmt_sut_autolot_wo'
		});
		//alert('output===>' + output)

		var finalURL = 'https://5711325-sb1.app.netsuite.com'+ output;
		//alert('finalURL===>' + finalURL)

		var headerObj = {
			name:'Content-Type',
			value: 'application/json'
		};

		var response = https.post({
		    url: finalURL,
		    body: param,
		    header:headerObj
		});

		//alert('response===>' + response)

		var response_parse = JSON.parse(response.body);
	    //alert('response_parse===>' + response_parse)

		var INV_Num = response_parse[0].inv_detail;
		//alert('INV_Num===>' + INV_Num);

		if(response_parse)
		{	
			recno.setValue({
                fieldId: 'custbody_fmt_generate_assemblylot_num',
                value: INV_Num,
            });
		}
	}

	return {
	pageInit : pageInit,
	callSuitelet: callSuitelet
	};
});
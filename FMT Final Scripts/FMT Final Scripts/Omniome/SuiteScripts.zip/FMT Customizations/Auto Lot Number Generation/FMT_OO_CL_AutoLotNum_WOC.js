/**
* @NApiVersion 2.0
* @NScriptType ClientScript
*/


define(['N/url','N/record','N/ui/dialog','N/runtime', 'N/currentRecord', 'N/https','N/log'],
function(url,record,dialog,runtime,currentRecord, https, log) 
{
	
	function saveRecord(context) {

		 var currentRecord = context.currentRecord;
alert('currentRecord===>' + currentRecord)

		 var createdFrom = currentRecord.getValue({fieldId: 'createdfrom'});
alert('createdFrom===>' + createdFrom)

		 var WO_qty = currentRecord.getValue({fieldId: 'quantity'});
alert('WO_qty===>' + WO_qty)

		var objRecord = record.load({
		    type: record.Type.WORK_ORDER,
		    id: createdFrom,
		    isDynamic: true,
		});

		var LotNum = objRecord.getValue({fieldId: 'custbody_fmt_generate_assemblylot_num'});
alert('LotNum===>' + LotNum)

		var objSubrecord = currentRecord.getCurrentSublistSubrecord({sublistId: 'component', fieldId: 'componentinventorydetail'});
				try{

				
				//alert('objSubrecord===>' + objSubrecord);
				debugger;
				objSubrecord.selectNewLine({
				sublistId: 'inventoryassignment'
				});

				//objSubrecord.selectLine({ sublistId: 'inventoryassignment', line: 0 });
				
				objSubrecord.setCurrentSublistValue({
				sublistId: 'inventoryassignment',
				fieldId: 'quantity',
				value: WO_qty
				});

				objSubrecord.setCurrentSublistValue({
				sublistId: 'inventoryassignment',
				fieldId: 'issueinventorynumber',
				value: LotNum
				});
								
				objSubrecord.commitLine({
				sublistId: 'inventoryassignment'
				});

				
				  }catch(e){

				  	alert('Error Message ====>' + e.toString());
				  }
       // Save the record
		return true;
	 }


	return {
	saveRecord : saveRecord,
	};
});
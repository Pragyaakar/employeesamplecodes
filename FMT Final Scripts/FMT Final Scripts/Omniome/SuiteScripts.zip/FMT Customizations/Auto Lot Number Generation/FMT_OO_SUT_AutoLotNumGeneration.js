/**
 *@NApiVersion 2.x
 *@NScriptType Suitelet
 */

 

define(['N/runtime', 'N/record', 'N/search', 'N/https', 'N/file', 'N/render', 'N/format'],
    function (runtime, record, search, https, file, render, format) 
    {
        function onRequest(context) 
        {
            log.debug('Call Suitelet');

           if (context.request.method == 'POST') 
            {
                try
                {   
                    var scriptObj = runtime.getCurrentScript();
                    
                    var val;
                    
                    val = JSON.parse(context.request.body)
                    log.debug({
                    title: 'Server Request Body',
                    details: val
                    });

                    if(val)
                    {   
                        var filterDate = val[0].date;
                        log.debug({
                        title: 'filterDate',
                        details: filterDate
                        });

                         var searchObj = search.create({
                            type: "customrecord_fmt_auto_lot_num_generation",
                            filters:
                            [
                              ["custrecord_fmt_start_date","onorbefore",filterDate], 
                              "AND", 
                              ["custrecord_fmt_end_date","onorafter",filterDate], 
                              "AND", 
                              ["custrecord_fmt_transaction_type","anyof",'16']
                            ],
                            columns:
                            [
                              search.createColumn({name: "internalid", label: "Internal ID"}),
                              search.createColumn({name: "custrecord_fmt_transaction_type", label: "Transaction Type"}),
                              search.createColumn({name: "custrecord_fmt_min_digits", label: "Min Digits"}),
                              search.createColumn({name: "custrecord_fmt_start_date", label: "Start Date"}),
                              search.createColumn({name: "custrecord_fmt_year", label: "Year"}),
                              search.createColumn({name: "custrecord_fmt_month", label: "Month"}),
                              search.createColumn({name: "custrecord_fmt_end_date", label: "End Date"}),
                              search.createColumn({name: "custrecord_fmt_auto_number", label: "Auto Number"})
                            ]
                        });
                   
                        var resultSet = searchObj.run();
                        var firstResult = resultSet.getRange({
                        start: 0,
                        end: 1000
                        });

 

                        if(firstResult)
                        {
                            var recordMap = []; 
                            log.debug({title: 'firstResult',details: firstResult});
                            for(var i=0;i<firstResult.length;i++)
                            {
                                var internalId = firstResult[i].getValue({name: "internalid", label: "Internal ID"});
                                var type = firstResult[i].getValue({name: "custrecord_fmt_transaction_type", label: "Transaction Type"});
                                var startDate = firstResult[i].getValue({name: "custrecord_fmt_start_date", label: "Start Date"});
                                var EndDate = firstResult[i].getValue({name: "custrecord_fmt_end_date", label: "End Date"});
                                var year = firstResult[i].getValue({name: "custrecord_fmt_year", label: "Year"});
                                var Month = firstResult[i].getValue({name: "custrecord_fmt_month", label: "Month"});
                                var minDig = firstResult[i].getValue({name: "custrecord_fmt_min_digits", label: "Min Digits"});
                                var AutoNum = firstResult[i].getValue({name: "custrecord_fmt_auto_number", label: "Auto Number"});
                            }

 

                            var getYr = year.substring(year.length-2);
                        }

                         var autoNumSet = getYr+''+Month; 
                        log.debug({title: 'autoNumSet',details: autoNumSet});
                        var valArr = [];
                        var genNum = '';
                        for(var i = 0; i < val.length; i++)
                        {
                            var item = val[i].item;
                            var quantity = val[i].qty;
                            genNum = autoNumSet+''+parseInt(AutoNum);
                            valArr.push({'item_id':item,'qty':quantity,'inv_detail':genNum});
                            AutoNum++;
                        }
                     
                        log.debug({title: 'AutoNum',details: parseInt(AutoNum)});

                        /*var otherId = record.submitFields({
                            type: 'customrecord_fmt_auto_lot_num_generation',
                            id: internalId,
                            values: {
                                'custrecord_fmt_auto_number': AutoNum
                            }
                        });*/

                     }


                    context.response.setHeader({name:'Content-Type',value: 'application/json'});
                    context.response.write({output:JSON.stringify(valArr)});
                      
                    /*finalVal = JSON.stringify(valArr);

                     return finalVal;*/
                       
                }
                catch(e)
                {
                    log.debug('Error Occured',e)
                }
            }
            
        }

 

        return {
            onRequest: onRequest
        };
    });
/**
 *@NApiVersion 2.x
 *@NScriptType Suitelet
 */

 

define(['N/runtime', 'N/record', 'N/search', 'N/https', 'N/file', 'N/render', 'N/format'],
    function (runtime, record, search, https, file, render, format) 
    {
        function onRequest(context) 
        {
            log.debug('Call Suitelet');

           if (context.request.method == 'POST') 
            {
                try
                {   
                    var scriptObj = runtime.getCurrentScript();
                    
                    var val;
                    
                    val = JSON.parse(context.request.body)
                    log.debug({
                    title: 'Server Request Body',
                    details: val
                    });

                    if(val)
                    {   
                        var filterDate = val[0].tran_date;
                        log.debug({
                        title: 'filterDate',
                        details: filterDate
                        });

                        var assembly_val = val[0].assembly_item;
                        var tran_qty = val[0].qty_val;

                        var record_id = val[0].recid;
                        log.debug({
                        title: 'Record Id',
                        details: record_id
                        });

                        var record_type = val[0].rectype;

                        var getYr = new Date().getFullYear().toString().substr(-2);
                        log.debug({title: 'getYr',details: getYr});

                        var Month = new Date().getMonth();

                        //var autoNumSet = getYr+''+Month; 
                        //log.debug({title: 'autoNumSet',details: autoNumSet});

                        var valArr = [];
                        var genNum = '';
                        
                          
                        var custRe = createCustomRecord(record_id,search,record);
                        log.debug({title: 'custRe',details: custRe});

                        if(custRe != null && custRe != '')
                        {
                            genNum = custRe;
                          
                            valArr.push({'assembly_id':assembly_val,'qty':tran_qty,'inv_detail':genNum});
                        
                            log.debug({title: 'custRe',details: parseInt(custRe)});
                        }
                        
                     }
                    
                    context.response.setHeader({name:'Content-Type',value: 'application/json'});
                    context.response.write({output:JSON.stringify(valArr)});
                    
                }
                catch(e)
                {
                    log.debug('Error Occured',e)
                }
            }
            
        }

        function createCustomRecord(record_id,search,record)
        {   
            log.debug('record_id',record_id)
            
            var searchObj = search.create({
               type: "customrecord_fmt_auto_lotnum_generation",
               filters:
               [
                  ["custrecord_fmt_tran_number","anyof",record_id]
               ],
               columns:
               [
                  search.createColumn({name: "internalid", label: "Internal ID"}),
                  search.createColumn({name: "custrecord_fmt_tran_type", label: "Transaction Type"}),
                  search.createColumn({name: "custrecord_fmt_tran_number", label: "Transaction Number"}),
                  search.createColumn({name: "custrecord_fmt_auto_lot_num", label: "Auto Lot Number"})
               ]
            });

            var resultSet = searchObj.run();
            var firstResult = resultSet.getRange({start: 0,end: 1000});
            log.debug('firstResult.length',firstResult.length)

            if(firstResult.length > 0)
            {   
                var AutoNum = firstResult[0].getValue({name: "custrecord_fmt_auto_lot_num", label: "Auto Lot Number"});
                log.debug({title: 'AutoNum',details: AutoNum});
            }
            else
            {
                var autoNumSet = createAutoLotNum();

                var getYr = new Date().getFullYear().toString().substr(-2);
                log.debug({title: 'getYr',details: getYr});


                var Month = new Date().getMonth()+1;

                var AutoNum = getYr+''+Month+''+autoNumSet; 
                log.debug({title: 'AutoNum',details: AutoNum});


                var custRecObj = record.create({type: 'customrecord_fmt_auto_lotnum_generation',isDynamic: true});

                custRecObj.setValue({fieldId: 'custrecord_fmt_tran_type',value: '44'});
                custRecObj.setValue({fieldId: 'custrecord_fmt_auto_lot_num',value: AutoNum});
                custRecObj.setValue({fieldId: 'custrecord_fmt_tran_number',value: record_id});

                var submitRec = custRecObj.save({enableSourcing: true,ignoreMandatoryFields: true});
            }
            log.debug({title: 'submitRec',details: submitRec});
            return AutoNum;
        }

        function createAutoLotNum()
        {
            try
            {
                var custRecObj = record.create({type: 'customrecord_fmt_work_order_num',isDynamic: true});

                var submitRec = custRecObj.save({enableSourcing: true,ignoreMandatoryFields: true});
                
                return submitRec;
                log.debug({title: 'submitRec',details: submitRec});
            }
            catch(e)
            {
                log.debug({title: 'Error',details: e});
            }
        }

        return {
            onRequest: onRequest
        };
    });


/**
* @NApiVersion 2.0
* @NScriptType UserEventScript
*/

define(['N/log','N/record','N/ui/serverWidget', 'N/currentRecord'],
function(log,record,serverWidget, currentRecord) 
{
	function beforeLoad(context) 
	{
		try
		{	
			if(context.type == 'create')
			{
				//var newRec = context.newRecord;
				//log.debug('newRec',newRec)

				context.form.clientScriptFileId = 22060;
				
				var button = context.form.addButton({
				id: 'custpage_button',
				label: 'Generate Lot Number',
				functionName: 'callSuitelet()'
				});
			}
		}
		catch(e)
		{
			log.debug('Before Load Error',e)
		}
	}



	return {
	beforeLoad: beforeLoad
	};
});
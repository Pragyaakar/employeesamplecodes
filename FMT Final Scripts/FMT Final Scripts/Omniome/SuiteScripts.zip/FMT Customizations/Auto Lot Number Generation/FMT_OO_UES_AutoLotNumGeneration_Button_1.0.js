function beforeLoad_AddButton(type, form, request){

nlapiLogExecution('debug','type======>', type)
//if( type == 'create' )
{

		nlapiLogExecution('debug','form======>', form)
		form.setScript('customscript_fmt_clt_auto_lot_num_1_0');
        form.addButton('custpage_mybutton','Generate Lot Number','callSuitelet()');
}
	//return true;
}
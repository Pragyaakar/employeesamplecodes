/**
* @NApiVersion 2.0
* @NScriptType UserEventScript
*/

define(['N/log','N/record','N/ui/serverWidget', 'N/currentRecord', 'N/search'],
function(log,record,serverWidget, currentRecord, search) 
{
	function afterSubmit(context) 
	{
		try
		{	
			if(context.type == 'create')
			{
				//var recObj = context.newRecord;
				//log.debug({title: 'Record Object',details: recObj});

				var recID = context.newRecord.id;
				log.debug({title: 'Record ID',details: recID});

				var recObj = record.load({
				    type: record.Type.WORK_ORDER,
				    id: recID,
				    isDynamic: true,
				});

				var trandate = recObj.getValue({fieldId: 'trandate'});
				log.debug({title: 'Transaction Date',details: trandate});
          
          		var filterDate = (trandate.getMonth()+1)+'/' + trandate.getDate() + '/'+ trandate.getFullYear();
                log.debug({title: 'filterDate',details: filterDate});

				var searchObj = search.create({
                    type: "customrecord_fmt_auto_lot_num_generation",
                    filters:
                    [
                        ["custrecord_fmt_start_date","onorbefore",filterDate], 
                        "AND", 
                        ["custrecord_fmt_end_date","onorafter",filterDate], 
                        "AND", 
                        ["custrecord_fmt_transaction_type","anyof",'44']
                    ],
                    columns:
                    [
                        search.createColumn({name: "internalid", label: "Internal ID"}),
                        search.createColumn({name: "custrecord_fmt_transaction_type", label: "Transaction Type"}),
                        search.createColumn({name: "custrecord_fmt_min_digits", label: "Min Digits"}),
                        search.createColumn({name: "custrecord_fmt_start_date", label: "Start Date"}),
                        search.createColumn({name: "custrecord_fmt_year", label: "Year"}),
                        search.createColumn({name: "custrecord_fmt_month", label: "Month"}),
                        search.createColumn({name: "custrecord_fmt_end_date", label: "End Date"}),
                        search.createColumn({name: "custrecord_fmt_auto_number", label: "Auto Number"})
                    ]
                });

                var resultSet = searchObj.run();
                var firstResult = resultSet.getRange({start: 0,end: 1000});

                if(firstResult)
                {
                    var recordMap = []; 
					log.debug({title: 'firstResult',details: firstResult});

                    for(var i=0;i<firstResult.length;i++)
                    {
                        var internalId = firstResult[i].getValue({name: "internalid", label: "Internal ID"});
                        var year = firstResult[i].getValue({name: "custrecord_fmt_year", label: "Year"});
                        var Month = firstResult[i].getValue({name: "custrecord_fmt_month", label: "Month"});
                        var AutoNum = firstResult[i].getValue({name: "custrecord_fmt_auto_number", label: "Auto Number"});
                    }

					var getYr = year.substring(year.length-2);
                }

                var autoNumSet = getYr+''+Month; 
                log.debug({title: 'autoNumSet',details: autoNumSet});

                var genNum = '';

                var quantity = recObj.getValue({fieldId: 'quantity'});
				log.debug({title: 'quantity',details: quantity});

				var assembly = recObj.getValue({fieldId: 'assemblyitem'});
        		log.debug({title: 'assembly',details: assembly});
				
				genNum = autoNumSet+''+parseInt(AutoNum);
                    
                AutoNum++;

				recObj.setValue({fieldId: 'custbody_fmt_generate_assemblylot_num',value: genNum});

                var recordId = recObj.save({enableSourcing: true,ignoreMandatoryFields: true});

                //log.debug({title: 'AutoNum',details: AutoNum});

                var otherId = record.submitFields({
                    type: 'customrecord_fmt_auto_lot_num_generation',
                    id: internalId,
                    values: {
                        'custrecord_fmt_auto_number': parseInt(AutoNum)
                    }
                });
			}	
		}
		catch(e)
		{
			log.debug({title: 'Error',details: e});
		}
	}

	return {
	afterSubmit: afterSubmit
	};
});
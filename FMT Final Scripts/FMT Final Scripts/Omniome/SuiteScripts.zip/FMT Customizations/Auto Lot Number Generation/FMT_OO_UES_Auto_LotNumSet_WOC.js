/**
* @NApiVersion 2.0
* @NScriptType UserEventScript
*/

define(['N/log','N/record','N/ui/serverWidget', 'N/currentRecord', 'N/search'],
function(log,record,serverWidget, currentRecord, search) 
{
	function afterSubmit(context) 
	{
		try
		{	
			if(context.type == 'create') // || context.type == 'edit'
			{
				var wocObj = context.newRecord;
				log.debug({title: 'Record Object',details: recObj});

				var recID = context.newRecord.id;
				log.debug({title: 'Record ID',details: recID});

                var recObj = record.load({
                    type: record.Type.WORK_ORDER_COMPLETION,
                    id: recID,
                    isDynamic: true,
                });

                var createdFrom = recObj.getValue({fieldId: 'createdfrom'});
                log.debug({title: 'Record ID',details: recID});

                var WO_qty = recObj.getValue({fieldId: 'quantity'});
                log.debug({title: 'Record ID',details: recID});


                var lookup = search.lookupFields({
                    type: search.Type.WORK_ORDER,
                    id: createdFrom,
                    columns: ['custbody_fmt_generate_assemblylot_num']
                });

                var inv_detail = lookup.custbody_fmt_generate_assemblylot_num;

                log.debug({title: 'Inventory Detail',details: inv_detail});

               /* var recObj = record.load({
                    type: record.Type.WORK_ORDER,
                    id: recID,
                    isDynamic: true,
                });*/

                //recObj.selectLine({sublistId: 'item',line: q});

                 var subrec = recObj.getSubrecord({
                  fieldId: "inventorydetail"
                });

                var existingLineCount = subrec.getLineCount({sublistId: 'inventoryassignment'});
                log.debug({title: 'existingLineCount',details: existingLineCount});

                for(var i1 = 0; i1 < existingLineCount; i1++)//(var i1 = existingLineCount; i1 >= 1; i1--) 
                {
                    subrec.selectLine({
                        sublistId: "inventoryassignment",
                        line: i1
                    });
                    subrec.removeLine({
                        sublistId: "inventoryassignment",
                        line: i1
                    });
                }

                // Add a line to the subrecord's inventory assignment sublist.
                subrec.selectNewLine({
                    sublistId: 'inventoryassignment'
                });

                subrec.setCurrentSublistValue({
                    sublistId: 'inventoryassignment',
                    fieldId: 'quantity',
                    value: WO_qty
                });

                subrec.setCurrentSublistValue({
                    sublistId: 'inventoryassignment',
                    fieldId: 'receiptinventorynumber',
                    value: inv_detail
                });

                //log.debug({title: 'genNum 143',details: genNum});

                // Save the line in the subrecord's sublist.
                subrec.commitLine({
                    sublistId: 'inventoryassignment'
                });

                var recordSave = recObj.save({enableSourcing: true,ignoreMandatoryFields: true});

			}
		}
		catch(e)
		{
			log.debug({title: 'Error',details: e});
		}
	}

	return {
	afterSubmit: afterSubmit
	};
});
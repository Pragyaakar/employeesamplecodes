/**
* @NApiVersion 2.0
* @NScriptType UserEventScript
*/

define(['N/log','N/record','N/ui/serverWidget', 'N/currentRecord'],
function(log,record,serverWidget, currentRecord) 
{
	function beforeLoad(context) 
	{
		try
		{	
			if(context.type == 'create')
			{
				
				var recObj = context.newRecord;//.get();
      			//var rectype = context.currentRecord.get().type;

				log.debug('Before Load Record Object ',recObj);
      			/*recno.selectLine({
            		sublistId: 'item',
            		line: 0
        		});
*/
				var objSubrecord = recObj.getCurrentSublistSubrecord({sublistId: 'item', fieldId: 'inventorydetail'});
				
				debugger;
				objSubrecord.selectNewLine({
				sublistId: 'inventoryassignment'
				});
						
				objSubrecord.setCurrentSublistValue({
				sublistId: 'inventoryassignment',
				fieldId: 'quantity',
				value: 1
				});

				objSubrecord.setCurrentSublistValue({
				sublistId: 'inventoryassignment',
				fieldId: 'issueinventorynumber',
				value: 'ABCD1234'
				});
								
				objSubrecord.commitLine({
				sublistId: 'inventoryassignment'
				});

				/*  recObj.commitLine({
            		sublistId: 'item'
       			 });*/

				 
			}
		}
		catch(e)
		{
			log.debug('Before Load Error',e.toString())
		}
	}



	return {
	beforeLoad: beforeLoad
	};
});
/**
 *@NApiVersion 2.x
 *
 */
 define(['N/search', 'N/record', 'N/email', 'N/runtime','N/render'],
    function(search, record, email, runtime,render) {
        return{
            SOCreationLibFile : function (resultData){//(currentRecord,customer_id,custname,salesrep,tranid,date,amt,currency) {
            try
            {
                log.audit('Enter in Library File');
                log.audit('resultData', resultData);
            }
            catch(e)
            {
                log.audit('ERROR', e.toString());
            }
        },
    }
});
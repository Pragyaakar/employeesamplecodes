/***********************************************************************
 *
 * The following javascript code is created by FMT Consultants LLC,
 * a NetSuite Partner. It is a SuiteFlex component containing custom code
 * intended for NetSuite (www.netsuite.com) and use the SuiteScript API.
 * The code is provided "as is": FMT Consultants LLC shall not be liable
 * for any damages arising out the intended use or if the code is modified
 * after delivery.
 *
 * Company:     FMT Consultants LLC, www.fmtconsultants.com
 * Author:      smehmood@fmtconsultants.com
 * File:        FMT_UTL_Common.js
 * Date:        4/20/2021
 *
 ***********************************************************************/

define(['N/search', 'N/record', 'N/runtime', 'N/format'],
    function (search, record, runtime, format) {
        return {
            monthNames: ["January", "February", "March", "April", "May", "June",
                "July", "August", "September", "October", "November", "December"
            ],
            monthNames_short: ["Jan", "Feb", "Mar", "Apr", "May", "Jun",
                "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
            ],
            searchAll: function (resultset) {
                var allResults = [];
                var startIndex = 0;
                var RANGECOUNT = 1000;
                do {
                    var pagedResults = resultset.getRange({
                        start: parseInt(startIndex),
                        end: parseInt(startIndex + RANGECOUNT)
                    });

                    allResults = allResults.concat(pagedResults);

                    var pagedResultsCount = pagedResults != null ? pagedResults.length : 0;
                    startIndex += pagedResultsCount;

                }
                while (pagedResultsCount == RANGECOUNT);
                return allResults;
            },
            //Get Formatted Date
            getFormattedDate: function (dateString) {
                var yr = dateString.substring(0, 2);
                var month = dateString.substring(2, 4);
                var day = dateString.substring(4, 6);
                var currentDate = new Date();
                var newDateString = month + "/" + day + "/" + ((currentDate.getFullYear()).toString()).substring(0, 2) + yr;
                var formattedDate = this.formatStringToDate(newDateString);
                return formattedDate;
            },
            //Format Date to String Field
            formatDateToString: function (input) {
                return (input.getMonth() + 1) + "/" + input.getDate() + "/" + input.getFullYear();
            },
            //Format String to Date Field(input)
            formatStringToDate: function (input) {
                return format.parse({
                    value: input,
                    type: format.Type.DATE
                });
            },
            addMonths: function (dt, months) {
                var newDate = new Date(dt);
                newDate.setMonth(newDate.getMonth() + months);
                return newDate;
            },
            addDays: function (dt, days) {
                var newDate = new Date(dt);
                newDate.setDate(newDate.getDate() + days);
                return newDate;
            },
            monthsDiff: function (d1, d2) {
                var months;
                months = (d2.getFullYear() - d1.getFullYear()) * 12;
                months -= d1.getMonth() + 1;
                months += d2.getMonth();
                // edit: increment months if d2 comes later in its month than d1 in its month
                if (d2.getDate() >= d1.getDate())
                    months++
                // end edit
                return months <= 0 ? 0 : months;
            },
            /**
             * Returns Serial Number Information for given internal id
             * @param {number} invNumId
             */
            getSerialNumberInfoById: function (invNumId) {
                var output;
                var customrecord_wrm_warrantyregSearchObj = search.create({
                    type: "inventorynumber",
                    filters: [['internalid', 'is', invNumId]],
                    columns: [
                        search.createColumn({
                            name: "inventorynumber",
                            label: "Number"
                        }),
                        search.createColumn({
                            name: "custitemnumber_cn_oem_serial",
                            label: "OEM Serial Number"
                        })
                    ]
                });
                customrecord_wrm_warrantyregSearchObj.run().each(function (result) {
                    output = {};
                    output.inventorynumber = result.getValue({name: "inventorynumber"});
                    output.custitemnumber_cn_oem_serial = result.getValue({name: "custitemnumber_cn_oem_serial"});
                });
                return output;
            },
            /**
             * Returns Serial Number Information for inventory number
             * @param {string} item
             * @param {string} invNum
             */
            getSerialNumberInfoByNumber: function (item, invNum) {
                var output;
                var customrecord_wrm_warrantyregSearchObj = search.create({
                    type: "inventorynumber",
                    filters: [['item', 'is', item], 'and', ['inventorynumber', 'is', invNum]],
                    columns: [
                        search.createColumn({
                            name: "custitemnumber_cn_oem_serial",
                            label: "OEM Serial Number"
                        })
                    ]
                });
                customrecord_wrm_warrantyregSearchObj.run().each(function (result) {
                    output = {};
                    output.inventorynumber = result.getValue({name: "inventorynumber"});
                    output.custitemnumber_cn_oem_serial = result.getValue({name: "custitemnumber_cn_oem_serial"});
                    output.id = result.id
                });
                return output;
            },
            findRevenueElementBySOLines: function (soId, lineUniqueKeys) {
                var records;
                var filters = [];
                var cols = [];
                var revenueElementIds = {};
                var lineUniqueKeysFilter = [];
                var revElemSearchObj;

                filters.push(['sourcetransaction.internalid', 'anyof', soId]);

                for (var u = 0; u < lineUniqueKeys.length; u++) {
                    lineUniqueKeysFilter.push(['sourcetransaction.lineuniquekey', 'equalto', lineUniqueKeys[u]]);
                    lineUniqueKeysFilter.push('or');
                }
                lineUniqueKeysFilter.pop();

                if (!!lineUniqueKeysFilter && lineUniqueKeysFilter.length > 0) {
                    filters.push('and');
                    filters.push(lineUniqueKeysFilter);
                }

                cols.push(search.createColumn({name: 'lineuniquekey', join: 'sourceTransaction'}));
                cols.push(search.createColumn({
                    name: "internalid",
                    join: "revenueArrangement",
                    label: "Internal ID"
                }));

                revElemSearchObj = search.create({
                    type: "revenueelement",
                });

                revElemSearchObj.filterExpression = filters;
                revElemSearchObj.columns = cols

                revElemSearchObj.run().each(function (result) {
                    revenueElementIds[result.getValue({name: 'lineuniquekey', join: 'sourceTransaction'})] = {};
                    revenueElementIds[result.getValue({
                        name: 'lineuniquekey',
                        join: 'sourceTransaction'
                    })].revenueelementid = result.id;
                    revenueElementIds[result.getValue({
                        name: 'lineuniquekey',
                        join: 'sourceTransaction'
                    })].revenuearrangementid =
                        result.getValue({
                            name: "internalid",
                            join: "revenueArrangement",
                            label: "Internal ID"
                        })
                });
                return revenueElementIds;
            },
            getCurrentDateTimeISO: function () {
                var dt = new Date();
                return dt.toISOString();
            },
            /**
             * Returns string
             * @param {string} item - item id
             * @param {string} location - location id
             */
            getExistingDemanPlanId: function (item, location) {
                var recordId;
                var itemDemandPlanSearchObj = search.create({
                    type: 'itemdemandplan',
                    filters:
                        [
                            ['item', "is", item],
                            "AND",
                            ['location', "is", location]
                        ]
                });
                itemDemandPlanSearchObj.run().each(function (result) {
                    recordId = result.id;
                });
                return recordId;
            },
            /**
             * Returns object
             * @param {string} startDate - startDate
             * @param {string} endDate - endDate
             */
            getExistingDemandPlans: function (startDate, endDate) {
                log.debug(" startDate endDate", startDate + " " + endDate);
                var results = {};
                var lineLoc, lineItem, lineKey, dDateMonth, dDateYear, formattedDemandDate;
                var itemDemandPlanSearchObj = search.create({
                    type: 'itemdemandplan',
                    filters:
                        [
                            ["demanddate", "within", startDate, endDate],
                            "AND",
                            ["location.isinactive", "is", "F"],
                            "AND",
                            ["item.isinactive", "is", "F"]
                        ],
                    columns:
                        [
                            search.createColumn({
                                name: "item",
                                sort: search.Sort.ASC,
                                label: "Item"
                            }),
                            search.createColumn({name: "item", label: "Item"}),
                            search.createColumn({name: "location", label: "Location"}),
                            search.createColumn({name: "demanddate", label: "Demand Date"}),
                            search.createColumn({name: "quantity", label: "Quantity"}),
                            search.createColumn({
                                name: "description",
                                join: "item",
                                label: "Description"
                            })
                        ]
                });
                var recs = this.searchAll(itemDemandPlanSearchObj.run());
                for (var r = 0; r < recs.length; r++) {
                    lineItem = recs[r].getValue({name: "item"});
                    lineLoc = recs[r].getValue({name: "location"});
                    lineKey = lineLoc + "|" + lineItem;
                    if (!!lineItem && !!lineLoc) {
                        if (!results[lineKey]) results[lineKey] = {};
                        results[lineKey].item = recs[r].getValue({name: "item"});
                        results[lineKey].location = recs[r].getValue({name: "location"});
                        results[lineKey].description = recs[r].getValue({name: "description", join: "item"});
                        formattedDemandDate = this.formatStringToDate(recs[r].getValue({name: "demanddate"}));
                        dDateMonth = formattedDemandDate.getMonth();
                        dDateYear = formattedDemandDate.getFullYear();
                        results[lineKey][dDateMonth + "|" + dDateYear] = {};
                        results[lineKey][dDateMonth + "|" + dDateYear].quantity = recs[r].getValue({name: "quantity"});
                    }
                }
                return results;
            }
        }
    });
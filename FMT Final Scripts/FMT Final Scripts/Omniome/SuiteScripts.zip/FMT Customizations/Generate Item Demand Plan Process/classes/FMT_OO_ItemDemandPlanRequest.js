/**
 * FMT_ITI_CRD_Automation_Log.js
 * @NApiVersion 2.0
 */

/***********************************************************************
 *
 * The following javascript code is created by FMT Consultants LLC,
 * a NetSuite Partner. It is a SuiteFlex component containing custom code
 * intended for NetSuite (www.netsuite.com) and use the SuiteScript API.
 * The code is provided "as is": FMT Consultants LLC shall not be liable
 * for any damages arising out the intended use or if the code is modified
 * after delivery.
 *
 * Company:     FMT Consultants LLC, www.fmtconsultants.com
 * Author:      smehmood@fmtconsultants.com
 * File:        FMT_CN_RevenueElementUpdateRequest.js
 * Date:        3/31/2021
 *
 ***********************************************************************/

define(['N/record', 'N/search', '../../Common/FMT_UTL_Common'],
    function (record, search, fmtCommonUtl) {
        return {
            internalid: 'customrecord_fmt_demplanreq',
            fields: {
                Processed: {id: 'custrecord_fmt_dpr_processed'},
                Hold: {id: 'custrecord_fmt_dpr_hold'},
                Error: {id: 'custrecord_fmt_dpr_errornote'},
                Date: {id: 'custrecord_fmt_dpr_startdate'},
                SaveOnly: {id: 'custrecord_fmt_dpr_saveonly'},
                SaveOnlyNote: {id: 'custrecord_fmt_dpr_saveonlynote'}
            },
            sublistId: "recmachcustrecord_fmt_dprdparent",
            /**
             * Returns id of record saved (created or updated)
             * @param {object} dataObject
             */
            upsert: function (dataObject) {
                debugger;
                if (!!dataObject) {
                    var nsObj, lineCount;
                    if (!!dataObject.id) {
                        nsObj = record.load({type: this.internalid, id: dataObject.id, isDynamic: true});
                        lineCount = nsObj.getLineCount({sublistId: this.sublistId});
                        for (var i = lineCount - 1; i > -1; i--) {
                            nsObj.removeLine({sublistId: this.sublistId, line: i});
                        }
                    } else {
                        nsObj = record.create({type: this.internalid, isDynamic: true});
                    }

                    for (var f in dataObject.body) {
                        nsObj.setValue({fieldId: f, value: dataObject.body[f]});
                    }

                    for (var i = 0; i < dataObject.lines.length; i++) {
                        nsObj.selectNewLine({sublistId: this.sublistId});

                        for (var f in dataObject.lines[i]) {
                            nsObj.setCurrentSublistValue({
                                sublistId: this.sublistId,
                                fieldId: f,
                                value: dataObject.lines[i][f]
                            });
                        }
                        nsObj.commitLine({sublistId: this.sublistId});
                    }
                    return nsObj.save();
                }
            },
            /**
             * Returns index
             * @param {object} rec
             * @param {number} location - locationid
             * @param {number} item - itemid
             */
            findLineByLocationItem: function (rec, location, item) {
                var lineCount = rec.getLineCount({sublistId: this.sublistId});
                var lineLocation, lineItem;
                var index = -1;
                for (var i = 0; i < lineCount; i++) {
                    lineLocation = rec.getSublistValue({
                        sublistId: this.sublistId,
                        fieldId: "custrecord_fmt_dprd_location",
                        line: i
                    });
                    lineItem = rec.getSublistValue({
                        sublistId: this.sublistId,
                        fieldId: "custrecord_fmt_dprd_item",
                        line: i
                    });
                    if (location == lineLocation && item == lineItem) {
                        index = i;
                    }
                }
                return index;
            },
            /**
             * Returns void
             * @param {string} id - record id to be marked as processed
             */
            markProcessed: function (id) {
                var rec = record.load({type: this.internalid, id: id, isDynamic: true});
                var lineCount = rec.getLineCount({sublistId: this.sublistId});
                var error = false, processed = true, errorNote;

                for (var i = 0; i < lineCount; i++) {
                    error = rec.getSublistValue({
                        sublistId: this.sublistId,
                        fieldId: "custrecord_fmt_dprderror",
                        value: true,
                        line: i
                    });
                    if (error) {
                        errorNote = rec.getSublistValue({
                            sublistId: this.sublistId,
                            fieldId: "custrecord_fmt_dprderrornote",
                            value: true,
                            line: i
                        })
                        processed = false;
                        break;
                    }
                }

                rec.setValue({fieldId: this.fields.Hold.id, value: error});
                rec.setValue({fieldId: this.fields.Processed.id, value: processed});
                if (!!errorNote) {
                    rec.setValue({fieldId: this.fields.Error.id, value: errorNote});
                }

                rec.save();
            },
            /**
             * Returns void
             * @param {string} id - record id to be marked as processed
             * @param {string} note - note
             */
            setNote: function (id, note) {
                var values = {};
                values[this.fields.Error.id] = note;

                record.submitFields({
                    type: this.internalid,
                    id: id,
                    values: values
                });
            },
            /**
             * Returns void
             * @param {string} id - record id to be marked as error
             * @param {string} error - error note
             */
            markError: function (id, error) {
                var values = {};
                values[this.fields.Error.id] = error;
                values[this.fields.Hold.id] = true;

                record.submitFields({
                    type: this.internalid,
                    id: id,
                    values: values
                });
            },
            /**
             * Returns string
             */
            getFirstPendingRequest: function () {
                var recordId;
                var customrecord_fmt_pendReqSearchObj = search.create({
                    type: this.internalid,
                    filters:
                        [
                            [this.fields.Processed.id, "is", "F"],
                            "AND",
                            [this.fields.Hold.id, "is", "F"],
                            "AND",
                            [this.fields.SaveOnly.id, "is", "F"],
                            "AND",
                            ["custrecord_fmt_dprdparent.custrecord_fmt_dprd_item", "noneof", "@NONE@"]
                        ],
                    columns:
                        [
                            search.createColumn({
                                name: "created",
                                sort: search.Sort.ASC,
                                label: "Date Created"
                            })
                        ]
                });
                customrecord_fmt_pendReqSearchObj.run().each(function (result) {
                    recordId = result.id;
                });
                return recordId;
            },
            /**
             * Returns void
             * @param {string} id - record id to be marked as error
             * @param {number} lineIndex
             * @param {string} error - error note
             */
            markLineError: function (id, lineIndex, error) {
                var rec = record.load({type: this.internalid, id: id, isDynamic: true});
                rec.selectLine({sublistId: this.sublistId, line: lineIndex});
                rec.setCurrentSublistValue({
                    sublistId: this.sublistId,
                    fieldId: "custrecord_fmt_dprderror",
                    value: true
                });
                rec.setCurrentSublistValue({
                    sublistId: this.sublistId,
                    fieldId: "custrecord_fmt_dprderrornote",
                    value: error
                });
                rec.commitLine({sublistId: this.sublistId});
                rec.save();
            },
            /**
             * Returns void
             * @param {string} id - record id to be marked as error
             * @param {number} lineIndex
             */
            markLineProcessed: function (id, lineIndex) {
                var rec = record.load({type: this.internalid, id: id, isDynamic: true});
                rec.selectLine({sublistId: this.sublistId, line: lineIndex});
                rec.setCurrentSublistValue({
                    sublistId: this.sublistId,
                    fieldId: "custrecord_fmt_dprdprocessed",
                    value: true
                });
                rec.setCurrentSublistValue({
                    sublistId: this.sublistId,
                    fieldId: "custrecord_fmt_dprderror",
                    value: false
                });
                rec.setCurrentSublistValue({
                    sublistId: this.sublistId,
                    fieldId: "custrecord_fmt_dprderrornote",
                    value: ""
                });
                rec.commitLine({sublistId: this.sublistId});
                rec.save();
            },
            /**
             * Returns object
             * @param {string} startDate - startDate
             * @param {string} endDate - endDate
             */
            getSavedonlyDemandPlans: function (startDate, endDate) {
                log.debug(" startDate endDate", startDate + " " + endDate);
                var results = {};
                var lineLoc, lineItem, lineKey, dDateMonth, dDateYear, formattedDemandDate;
                var customrecord_fmt_demplanreqSearchObj = search.create({
                    type: "customrecord_fmt_dprd",
                    filters:
                        [["custrecord_fmt_dprdparent.custrecord_fmt_dpr_saveonly", "is", "T"], "AND", ["custrecord_fmt_dprdparent.isinactive", "is", "F"], "AND",
                            [[["custrecord_fmt_dprq_mnth1stdate", "within", startDate, endDate], "AND", ["custrecord_fmt_dprd_qtymnth1", "greaterthan", "0"]],
                                "OR",
                                [["custrecord_fmt_dprq_mnth2stdate", "within", startDate, endDate], "AND", ["custrecord_fmt_dprd_qtymnth2", "greaterthan", "0"]],
                                "OR",
                                [["custrecord_fmt_dprq_mnth3stdate", "within", startDate, endDate], "AND", ["custrecord_fmt_dprd_qtymnth3", "greaterthan", "0"]],
                                "OR",
                                [["custrecord_fmt_dprq_mnth4stdate", "within", startDate, endDate], "AND", ["custrecord_fmt_dprd_qtymnth4", "greaterthan", "0"]],
                                "OR",
                                [["custrecord_fmt_dprq_mnth5stdate", "within", startDate, endDate], "AND", ["custrecord_fmt_dprd_qtymnth5", "greaterthan", "0"]],
                                "OR",
                                [["custrecord_fmt_dprq_mnth6stdate", "within", startDate, endDate], "AND", ["custrecord_fmt_dprd_qtymnth6", "greaterthan", "0"]],
                                "OR",
                                [["custrecord_fmt_dprq_mnth7stdate", "within", startDate, endDate], "AND", ["custrecord_fmt_dprd_qtymnth7", "greaterthan", "0"]],
                                "OR",
                                [["custrecord_fmt_dprq_mnth8stdate", "within", startDate, endDate], "AND", ["custrecord_fmt_dprd_qtymnth8", "greaterthan", "0"]],
                                "OR",
                                [["custrecord_fmt_dprq_mnth9stdate", "within", startDate, endDate], "AND", ["custrecord_fmt_dprd_qtymnth9", "greaterthan", "0"]],
                                "OR",
                                [["custrecord_fmt_dprq_mnth10stdate", "within", startDate, endDate], "AND", ["custrecord_fmt_dprd_qtymnth10", "greaterthan", "0"]],
                                "OR",
                                [["custrecord_fmt_dprq_mnth11stdate", "within", startDate, endDate], "AND", ["custrecord_fmt_dprd_qtymnth11", "greaterthan", "0"]],
                                "OR",
                                [["custrecord_fmt_dprq_mnth12stdate", "within", startDate, endDate], "AND", ["custrecord_fmt_dprd_qtymnth12", "greaterthan", "0"]]
                            ]],
                    columns:
                        [
                            search.createColumn({
                                name: "custrecord_fmt_dprd_location",
                                label: "Location",
                                summary: "group"
                            }),
                            search.createColumn({
                                name: "custrecord_fmt_dprd_item",
                                label: "Item",
                                summary: "group"
                            }),
                            search.createColumn({
                                name: "description",
                                join: "custrecord_fmt_dprd_item",
                                label: "Description",
                                summary: "group"
                            }),
                            search.createColumn({
                                name: "custrecord_fmt_dprq_mnth1stdate",
                                label: "Month1 Start Date",
                                summary: "max"
                            }),
                            search.createColumn({
                                name: "custrecord_fmt_dprd_qtymnth1",
                                label: "Month1 Qty",
                                summary: "sum"
                            }),
                            search.createColumn({
                                name: "custrecord_fmt_dprq_mnth2stdate",
                                label: "Month2 Start Date",
                                summary: "max"
                            }),
                            search.createColumn({
                                name: "custrecord_fmt_dprd_qtymnth2",
                                label: "Month2 Qty",
                                summary: "sum"
                            }),
                            search.createColumn({
                                name: "custrecord_fmt_dprq_mnth3stdate",
                                label: "Month3 Start Date",
                                summary: "max"
                            }),
                            search.createColumn({
                                name: "custrecord_fmt_dprd_qtymnth3",
                                label: "Month3 Qty",
                                summary: "sum"
                            }),
                            search.createColumn({
                                name: "custrecord_fmt_dprq_mnth4stdate",
                                label: "Month4 Start Date",
                                summary: "max"
                            }),
                            search.createColumn({
                                name: "custrecord_fmt_dprd_qtymnth4",
                                label: "Month4 Qty",
                                summary: "sum"
                            }),
                            search.createColumn({
                                name: "custrecord_fmt_dprq_mnth5stdate",
                                label: "Month5 Start Date",
                                summary: "max"
                            }),
                            search.createColumn({
                                name: "custrecord_fmt_dprd_qtymnth5",
                                label: "Month5 Qty",
                                summary: "sum"
                            }),
                            search.createColumn({
                                name: "custrecord_fmt_dprq_mnth6stdate",
                                label: "Month6 Start Date",
                                summary: "max"
                            }),
                            search.createColumn({
                                name: "custrecord_fmt_dprd_qtymnth6",
                                label: "Month6 Qty",
                                summary: "sum"
                            }),
                            search.createColumn({
                                name: "custrecord_fmt_dprq_mnth7stdate",
                                label: "Month7 Start Date",
                                summary: "max"
                            }),
                            search.createColumn({
                                name: "custrecord_fmt_dprd_qtymnth7",
                                label: "Month7 Qty",
                                summary: "sum"
                            }),
                            search.createColumn({
                                name: "custrecord_fmt_dprq_mnth8stdate",
                                label: "Month8 Start Date",
                                summary: "max"
                            }),
                            search.createColumn({
                                name: "custrecord_fmt_dprd_qtymnth8",
                                label: "Month8 Qty",
                                summary: "sum"
                            }),
                            search.createColumn({
                                name: "custrecord_fmt_dprq_mnth9stdate",
                                label: "Month9 Start Date",
                                summary: "max"
                            }),
                            search.createColumn({
                                name: "custrecord_fmt_dprd_qtymnth9",
                                label: "Month9 Qty",
                                summary: "sum"
                            }),
                            search.createColumn({
                                name: "custrecord_fmt_dprq_mnth10stdate",
                                label: "Month10 Start Date",
                                summary: "max"
                            }),
                            search.createColumn({
                                name: "custrecord_fmt_dprd_qtymnth10",
                                label: "Month10 Qty",
                                summary: "sum"
                            }),
                            search.createColumn({
                                name: "custrecord_fmt_dprq_mnth11stdate",
                                label: "Month11 Start Date",
                                summary: "max"
                            }),
                            search.createColumn({
                                name: "custrecord_fmt_dprd_qtymnth11",
                                label: "Month11 Qty",
                                summary: "sum"
                            }),
                            search.createColumn({
                                name: "custrecord_fmt_dprq_mnth12stdate",
                                label: "Month12 Start Date",
                                summary: "max"
                            }),
                            search.createColumn({
                                name: "custrecord_fmt_dprd_qtymnth12",
                                label: "Month12 Qty",
                                summary: "sum"
                            })

                        ]
                });
                var recs = fmtCommonUtl.searchAll(customrecord_fmt_demplanreqSearchObj.run());
                for (var r = 0; r < recs.length; r++) {
                    lineItem = recs[r].getValue({name: "custrecord_fmt_dprd_item", summary: "group"});
                    lineLoc = recs[r].getValue({name: "custrecord_fmt_dprd_location", summary: "group"});
                    lineKey = lineLoc + "|" + lineItem;
                    if (!!lineItem && !!lineLoc) {
                        if (!results[lineKey]) results[lineKey] = {};
                        results[lineKey].item = recs[r].getValue({name: "custrecord_fmt_dprd_item", summary: "group"});
                        results[lineKey].location = recs[r].getValue({
                            name: "custrecord_fmt_dprd_location",
                            summary: "group"
                        });
                        results[lineKey].description = recs[r].getValue({
                            name: "description",
                            join: "custrecord_fmt_dprd_item",
                            summary: "group"
                        });

                        for (var c = 1; c <= 12; c++) {
                            if (!!recs[r].getValue({name: "custrecord_fmt_dprd_qtymnth" + c, summary: "sum"})) {
                                formattedDemandDate = fmtCommonUtl.formatStringToDate(recs[r].getValue({
                                    name: "custrecord_fmt_dprq_mnth" + c + "stdate",
                                    summary: "max"
                                }));
                                dDateMonth = formattedDemandDate.getMonth();
                                dDateYear = formattedDemandDate.getFullYear();
                                results[lineKey][dDateMonth + "|" + dDateYear] = {};
                                results[lineKey][dDateMonth + "|" + dDateYear].quantity = recs[r].getValue({
                                    name: "custrecord_fmt_dprd_qtymnth" + c,
                                    summary: "sum"
                                });
                            }
                        }
                    }
                }
                return results;
            },

            /**
             * Returns object
             * @param {string} id - id
             */
            getDemandPlanById: function (id) {
                log.debug(" id " + id);
                var results = {};
                var lineLoc, lineItem, lineKey, dDateMonth, dDateYear, formattedDemandDate;
                var customrecord_fmt_demplanreqSearchObj = search.create({
                    type: "customrecord_fmt_dprd",
                    filters:
                        ["custrecord_fmt_dprdparent", "is", id],
                    columns:
                        [
                            search.createColumn({
                                name: "custrecord_fmt_dprd_location",
                                label: "Location",
                                summary: "group"
                            }),
                            search.createColumn({
                                name: "custrecord_fmt_dprd_item",
                                label: "Item",
                                summary: "group"
                            }),
                            search.createColumn({
                                name: "description",
                                join: "custrecord_fmt_dprd_item",
                                label: "Description",
                                summary: "group"
                            }),
                            search.createColumn({
                                name: "custrecord_fmt_dprq_mnth1stdate",
                                label: "Month1 Start Date",
                                summary: "max"
                            }),
                            search.createColumn({
                                name: "custrecord_fmt_dprd_qtymnth1",
                                label: "Month1 Qty",
                                summary: "sum"
                            }),
                            search.createColumn({
                                name: "custrecord_fmt_dprq_mnth2stdate",
                                label: "Month2 Start Date",
                                summary: "max"
                            }),
                            search.createColumn({
                                name: "custrecord_fmt_dprd_qtymnth2",
                                label: "Month2 Qty",
                                summary: "sum"
                            }),
                            search.createColumn({
                                name: "custrecord_fmt_dprq_mnth3stdate",
                                label: "Month3 Start Date",
                                summary: "max"
                            }),
                            search.createColumn({
                                name: "custrecord_fmt_dprd_qtymnth3",
                                label: "Month3 Qty",
                                summary: "sum"
                            }),
                            search.createColumn({
                                name: "custrecord_fmt_dprq_mnth4stdate",
                                label: "Month4 Start Date",
                                summary: "max"
                            }),
                            search.createColumn({
                                name: "custrecord_fmt_dprd_qtymnth4",
                                label: "Month4 Qty",
                                summary: "sum"
                            }),
                            search.createColumn({
                                name: "custrecord_fmt_dprq_mnth5stdate",
                                label: "Month5 Start Date",
                                summary: "max"
                            }),
                            search.createColumn({
                                name: "custrecord_fmt_dprd_qtymnth5",
                                label: "Month5 Qty",
                                summary: "sum"
                            }),
                            search.createColumn({
                                name: "custrecord_fmt_dprq_mnth6stdate",
                                label: "Month6 Start Date",
                                summary: "max"
                            }),
                            search.createColumn({
                                name: "custrecord_fmt_dprd_qtymnth6",
                                label: "Month6 Qty",
                                summary: "sum"
                            }),
                            search.createColumn({
                                name: "custrecord_fmt_dprq_mnth7stdate",
                                label: "Month7 Start Date",
                                summary: "max"
                            }),
                            search.createColumn({
                                name: "custrecord_fmt_dprd_qtymnth7",
                                label: "Month7 Qty",
                                summary: "sum"
                            }),
                            search.createColumn({
                                name: "custrecord_fmt_dprq_mnth8stdate",
                                label: "Month8 Start Date",
                                summary: "max"
                            }),
                            search.createColumn({
                                name: "custrecord_fmt_dprd_qtymnth8",
                                label: "Month8 Qty",
                                summary: "sum"
                            }),
                            search.createColumn({
                                name: "custrecord_fmt_dprq_mnth9stdate",
                                label: "Month9 Start Date",
                                summary: "max"
                            }),
                            search.createColumn({
                                name: "custrecord_fmt_dprd_qtymnth9",
                                label: "Month9 Qty",
                                summary: "sum"
                            }),
                            search.createColumn({
                                name: "custrecord_fmt_dprq_mnth10stdate",
                                label: "Month10 Start Date",
                                summary: "max"
                            }),
                            search.createColumn({
                                name: "custrecord_fmt_dprd_qtymnth10",
                                label: "Month10 Qty",
                                summary: "sum"
                            }),
                            search.createColumn({
                                name: "custrecord_fmt_dprq_mnth11stdate",
                                label: "Month11 Start Date",
                                summary: "max"
                            }),
                            search.createColumn({
                                name: "custrecord_fmt_dprd_qtymnth11",
                                label: "Month11 Qty",
                                summary: "sum"
                            }),
                            search.createColumn({
                                name: "custrecord_fmt_dprq_mnth12stdate",
                                label: "Month12 Start Date",
                                summary: "max"
                            }),
                            search.createColumn({
                                name: "custrecord_fmt_dprd_qtymnth12",
                                label: "Month12 Qty",
                                summary: "sum"
                            })

                        ]
                });
                var recs = fmtCommonUtl.searchAll(customrecord_fmt_demplanreqSearchObj.run());
                for (var r = 0; r < recs.length; r++) {
                    lineItem = recs[r].getValue({name: "custrecord_fmt_dprd_item", summary: "group"});
                    lineLoc = recs[r].getValue({name: "custrecord_fmt_dprd_location", summary: "group"});
                    lineKey = lineLoc + "|" + lineItem;
                    if (!!lineItem && !!lineLoc) {
                        if (!results[lineKey]) results[lineKey] = {};
                        results[lineKey].item = recs[r].getValue({name: "custrecord_fmt_dprd_item", summary: "group"});
                        results[lineKey].item_text = recs[r].getText({name: "custrecord_fmt_dprd_item", summary: "group"});
                        results[lineKey].location = recs[r].getValue({
                            name: "custrecord_fmt_dprd_location",
                            summary: "group"
                        });
                        results[lineKey].location_text = recs[r].getText({name: "custrecord_fmt_dprd_location", summary: "group"});
                        results[lineKey].description = recs[r].getValue({
                            name: "description",
                            join: "custrecord_fmt_dprd_item",
                            summary: "group"
                        });

                        for (var c = 1; c <= 12; c++) {
                            if (!!recs[r].getValue({name: "custrecord_fmt_dprd_qtymnth" + c, summary: "sum"})) {
                                formattedDemandDate = fmtCommonUtl.formatStringToDate(recs[r].getValue({
                                    name: "custrecord_fmt_dprq_mnth" + c + "stdate",
                                    summary: "max"
                                }));
                                dDateMonth = formattedDemandDate.getMonth();
                                dDateYear = formattedDemandDate.getFullYear();
                                results[lineKey][dDateMonth + "|" + dDateYear] = {};
                                results[lineKey][dDateMonth + "|" + dDateYear].quantity = recs[r].getValue({
                                    name: "custrecord_fmt_dprd_qtymnth" + c,
                                    summary: "sum"
                                });
                            }
                        }
                    }
                }
                return results;
            },

            /**
             * Returns id
             */
            getTemplateRecordId: function () {
                var customrecord_fmt_demplanreqSearchObj = search.create({
                    type: "customrecord_fmt_demplanreq",
                    filters:
                        [["custrecord_fmt_dpr_saveonly", "is", "T"], "AND", ["isinactive", "is", "F"]]
                });
                var id;

                customrecord_fmt_demplanreqSearchObj.run().each(function (result) {
                    id = result.id;
                });

                return id;
            }
        }
    })


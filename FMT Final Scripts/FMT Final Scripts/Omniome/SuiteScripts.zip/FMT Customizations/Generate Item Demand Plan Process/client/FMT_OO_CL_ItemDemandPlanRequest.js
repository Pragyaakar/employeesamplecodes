/**
 *@NApiVersion 2.0
 *@NScriptType ClientScript
 */
define(['N/error', 'N/ui/message', 'N/search'],
    function (error, message, search) {
        var MAX_QTY_NUMBER = 9999;

        function pageInit() {
            var warning = message.create({
                title: 'DO NOT USE BROWSER REFRESH BUTTON',
                message: 'Do not use browser refresh button, use "Generate / Refresh" button on this screen. "',
                type: message.Type.WARNING
            });
            warning.show();
        }

        function validateLine(context) {
            var rec = context.currentRecord;
            var qtyValue, result = true;
            var currentItem, existingItemIndex, currentLineIndex, savedOnlyLine;

            currentLineIndex = rec.getCurrentSublistIndex({
                sublistId: 'custpage_sublist'
            });
            currentItem = rec.getCurrentSublistValue({
                sublistId: 'custpage_sublist',
                fieldId: 'custpage_item'
            });

            existingItemIndex = findLineByLocationItem(rec, rec.getCurrentSublistValue({
                    sublistId: 'custpage_sublist',
                    fieldId: 'custpage_location'
                }),
                rec.getCurrentSublistValue({
                    sublistId: 'custpage_sublist',
                    fieldId: 'custpage_item'
                }));

            if (result && existingItemIndex > -1 && currentLineIndex != existingItemIndex) {
                alert("Item already exists in grid at line " + (existingItemIndex + 1));
                result = false;
            }

            if (result) {
                for (var i = 1; i <= 12; i++) {
                    qtyValue = parseFloat(rec.getCurrentSublistValue({
                        sublistId: 'custpage_sublist',
                        fieldId: 'custpage_mnth' + i
                    }));

                    if (!isNaN(qtyValue) && qtyValue > MAX_QTY_NUMBER) {
                        result = false;
                        alert("Maximum quantity allowed : " + MAX_QTY_NUMBER);
                    }
                }

                rec.setCurrentSublistValue({
                    sublistId: 'custpage_sublist',
                    fieldId: 'custpage_linechanged',
                    value: true
                });
            }

            return result;
        }

        /**
         * Returns index
         * @param {object} rec
         * @param {number} location - locationid
         * @param {number} item - itemid
         */
        function findLineByLocationItem(rec, location, item) {
            var lineCount = rec.getLineCount({sublistId: 'custpage_sublist'});
            var lineLocation, lineItem;
            var index = -1;
            for (var i = 0; i < lineCount; i++) {
                lineLocation = rec.getSublistValue({
                    sublistId: 'custpage_sublist',
                    fieldId: "custpage_location",
                    line: i
                });
                lineItem = rec.getSublistValue({
                    sublistId: 'custpage_sublist',
                    fieldId: "custpage_item",
                    line: i
                });
                if (location == lineLocation && item == lineItem) {
                    index = i;
                }
            }
            return index;
        }

        function fieldChanged(context) {
            debugger;
            if (context.fieldId == "custpage_item") {
                var rec = context.currentRecord;
                var item = rec.getCurrentSublistValue({
                    sublistId: 'custpage_sublist',
                    fieldId: 'custpage_item'
                });
                var itemDesc = search.lookupFields({type: "item", id: item, columns: ["description"]});
                rec.setCurrentSublistValue({
                    sublistId: 'custpage_sublist',
                    fieldId: 'custpage_itemdesc',
                    value: itemDesc.description
                });
            }
        }

        function saveRecord(context) {
            var rec = context.currentRecord;
            var lineCount = rec.getLineCount({
                sublistId: 'custpage_sublist'
            });
            var lineChangeValue = false;

            for (var i = 0; i < lineCount; i++) {
                lineChangeValue = rec.getCurrentSublistValue({
                    sublistId: 'custpage_sublist',
                    fieldId: 'custpage_linechanged'
                });
                if (lineChangeValue) break;
            }

            if (!lineChangeValue) {
                alert("At least one line should be changed/added.");
            }

            return lineChangeValue;
        }

        return {
            validateLine: validateLine,
            fieldChanged: fieldChanged,
            pageInit: pageInit
        };
    }
);



/**
 *@NApiVersion 2.0
 *@NScriptType MapReduceScript
 */

/***********************************************************************
 *
 * The following javascript code is created by FMT Consultants LLC,
 * a NetSuite Partner. It is a SuiteFlex component containing custom code
 * intended for NetSuite (www.netsuite.com) and use the SuiteScript API.
 * The code is provided "as is": FMT Consultants LLC shall not be liable
 * for any damages arising out the intended use or if the code is modified
 * after delivery.
 *
 * Company:     FMT Consultants LLC, www.fmtconsultants.com
 * Author:      smehmood@fmtconsultants.com; mjahn@fmtconsultants.com
 * File:        FMT_OO_MR_GenerateItemDemandPlan.js
 * Date:        4/24/2021
 *
 ***********************************************************************/

define(['N/search', 'N/record', 'N/runtime', 'N/error', 'N/format', 'N/task', '../classes/FMT_OO_ItemDemandPlanRequest'
        , '../../Common/FMT_UTL_Common'],
    function (search, record, runtime, error, format, task, itemDemandPlanReq, fmtCommonUtl) {
        const SUBLIST_ID = "recmachcustrecord_fmt_dprdparent";

        function getInputData(context) {
            var firstPendingRecordId = itemDemandPlanReq.getFirstPendingRequest();
            var nsRec, lineCount, toBeProcessDataArray = [], toBeProcessDataObj;
            if (!!firstPendingRecordId) {
                nsRec = record.load({type: itemDemandPlanReq.internalid, id: firstPendingRecordId});
                lineCount = nsRec.getLineCount({sublistId: SUBLIST_ID});
                for (var i = 0; i < lineCount; i++) {
                    toBeProcessDataObj = {};
                    toBeProcessDataObj.id = nsRec.getSublistValue({sublistId: SUBLIST_ID, fieldId: "id", line: i});
                    toBeProcessDataObj.index = i;
                    toBeProcessDataObj.parent = firstPendingRecordId;
                    toBeProcessDataObj.item = nsRec.getSublistValue({
                        sublistId: SUBLIST_ID,
                        fieldId: "custrecord_fmt_dprd_item",
                        line: i
                    });
                    toBeProcessDataObj.location = nsRec.getSublistValue({
                        sublistId: SUBLIST_ID,
                        fieldId: "custrecord_fmt_dprd_location",
                        line: i
                    });
                    for (var j = 1; j <= 12; j++) {
                        toBeProcessDataObj['mnth' + j + 'stdate'] = nsRec.getSublistValue({
                            sublistId: SUBLIST_ID,
                            fieldId: "custrecord_fmt_dprq_mnth" + j + "stdate",
                            line: i
                        });

                        if (!!toBeProcessDataObj['mnth' + j + 'stdate']) {
                            toBeProcessDataObj['mnth' + j + 'stdate'] = fmtCommonUtl.formatDateToString(toBeProcessDataObj['mnth' + j + 'stdate']);
                        }
                        toBeProcessDataObj['qtymnth' + j] = nsRec.getSublistValue({
                            sublistId: SUBLIST_ID,
                            fieldId: "custrecord_fmt_dprd_qtymnth" + j,
                            line: i
                        });
                    }
                    toBeProcessDataArray.push(toBeProcessDataObj);
                }
            }
            return toBeProcessDataArray;
        }

        function map(context) {
            log.debug('context.value', context.value);
            var sourceData = JSON.parse(context.value);
            var resultObj = {error: false}, item, location, existingDpId, dpNSRec, defaultValues;
            try {
                log.debug("sourceData", JSON.stringify(sourceData));
                resultObj.parent = sourceData.parent;
                item = sourceData.item;
                location = sourceData.location;
                existingDpId = fmtCommonUtl.getExistingDemanPlanId(item, location);
                log.debug("existingDpId", existingDpId);
                if (!!existingDpId) {
                    record.delete({type: "itemdemandplan", id: existingDpId});
                }
                defaultValues = {};
                defaultValues.item = item;
                defaultValues.location = location;
                dpNSRec = record.create({type: "itemdemandplan", isDynamic: true, defaultValues: defaultValues});

                for (var j = 1; j <= 12; j++) {
                    if (!!sourceData['mnth' + j + 'stdate'] && !!sourceData['qtymnth' + j]) {
                        dpNSRec.selectLine({sublistId: "demandplandetail", line: j - 1});
                        dpNSRec.setCurrentSublistValue({
                            sublistId: "demandplandetail",
                            fieldId: "startdate",
                            value: fmtCommonUtl.formatStringToDate(sourceData['mnth' + j + 'stdate'])
                        });
                        dpNSRec.setCurrentMatrixSublistValue({
                            sublistId: 'demandplandetail',
                            fieldId: 'quantity',
                            column: 0,
                            value: sourceData['qtymnth' + j],
                        });
                        dpNSRec.commitLine({sublistId: "demandplandetail"});
                    }
                }
                dpNSRec.save();
                itemDemandPlanReq.markLineProcessed(sourceData.parent, sourceData.index);
            } catch (ex) {
                log.error("ex", ex.toString());
                resultObj.error = true;
                resultObj.errorNote = ex.toString()
                log.debug("Marking line error ", "Parent : " + sourceData.parent + "  Index : " + sourceData.index);
                itemDemandPlanReq.markLineError(sourceData.parent, sourceData.index, ex.toString());
            }
            context.write({
                key: fmtCommonUtl.getCurrentDateTimeISO(),
                value: resultObj
            });
        }

        function reduce(context) {
            //NOT USING THIS STAGE IN THIS SCRIPT
        }

        function summarize(context) {
            log.debug("Summarizing stage started");
            var scriptObj = runtime.getCurrentScript();
            var mapResult;
            var dpReqId, firstPendingRecordId;
            context.output.iterator().each(function (key, value) {
                if (!!value) {
                    mapResult = JSON.parse(value);
                    dpReqId = mapResult.parent;
                }
            });

            if (!!dpReqId) {
                itemDemandPlanReq.markProcessed(dpReqId);
            }
            firstPendingRecordId = itemDemandPlanReq.getFirstPendingRequest();
            if (!!firstPendingRecordId) {
                try {
                    var mrTask = task.create({taskType: task.TaskType.MAP_REDUCE});
                    mrTask.scriptId = scriptObj.id;
                    mrTask.deploymentId = scriptObj.deploymentId;
                    var mrTaskId = mrTask.submit();
                } catch (ex) {
                    log.error("error when calling map/reduce", ex.toString());
                }
            }
        }

        return {
            getInputData: getInputData,
            map: map,
            //reduce: reduce,
            summarize: summarize
        };
    });

























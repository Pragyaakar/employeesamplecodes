/**
 *@NApiVersion 2.0
 *@NScriptType Suitelet
 */
/***********************************************************************
 *
 * The following javascript code is created by FMT Consultants LLC,
 * a NetSuite Partner. It is a SuiteFlex component containing custom code
 * intended for NetSuite (www.netsuite.com) and use the SuiteScript API.
 * The code is provided "as is": FMT Consultants LLC shall not be liable
 * for any damages arising out the intended use or if the code is modified
 * after delivery.
 *
 * Company:     FMT Consultants LLC, www.fmtconsultants.com
 * Author:      smehmood@fmtconsultants.com
 * File:        FMT_OO_SL_GenerateItemDemandPlan.js
 * Date:        4/26/2021
 *
 ***********************************************************************/

define(['N/runtime', 'N/record', 'N/search', 'N/ui/serverWidget', 'N/task',
        '../../Common/FMT_UTL_Common', '../classes/FMT_OO_ItemDemandPlanRequest'],
    function (runtime, record, search, ui, task, fmtCommonUtl, itemDemandPlanReq) {
        var currentContext;
        var CLIENT_SCRIPT_FILE = "SuiteScripts/FMT Customizations/Generate Item Demand Plan Process/client/FMT_OO_CL_ItemDemandPlanRequest.js";
        var addSuccessMessage = false;
        var MAP_REDUCE_SCRIPT_ID = "customscript_fmt_gendemandplans",
            MAP_REDUCE_DEPLOYMENT_ID = "customdeploy_fmt_gendemandplans";
        var DEFAULT_LOCATION;

        function onRequest(context) {
            var form;
            var scriptObj = runtime.getCurrentScript();
            DEFAULT_LOCATION = scriptObj.getParameter({name: 'custscript_defaultlocation'});
            currentContext = context;
            try {
                form = designForm();
                form.clientScriptModulePath = CLIENT_SCRIPT_FILE;
                if (currentContext.request.method === 'POST' && addSuccessMessage) {
                    addAlert(form, "Request submitted successfully.");
                    log.debug("genDemandPlan", genDemandPlan);
                    if (genDemandPlan) initiateJob();
                }
            } catch (ex) {
                log.error("error", ex.toString());
                if (!!form)
                    addAlert(form, ex.toString());
            }
            currentContext.response.writePage(form);
        }

        function initiateJob() {
            try {
                var mrTask = task.create({taskType: task.TaskType.MAP_REDUCE});
                mrTask.scriptId = MAP_REDUCE_SCRIPT_ID;
                mrTask.deploymentId = MAP_REDUCE_DEPLOYMENT_ID;
                var mrTaskId = mrTask.submit();
            } catch (ex) {
                log.error("error when calling map/reduce", ex.toString());
            }
        }

        function addAlert(form, alertText) {
            var alertFld = form.addField({
                id: "custpage_alert",
                type: ui.FieldType.INLINEHTML,
                label: "Alert"
            });
            alertFld.defaultValue = '<script> alert("' + alertText + '");</script>';
        }

        function designForm() {
            var today = new Date();
            var currentDate = new Date(today);
            var mnthFieldLabel, monthField;
            var existingDataStDate = new Date(currentDate);
            var existingDataEnDate;
            var form = ui.createForm({
                title: 'Generate Demand Plan'
            });

            var generateNSDemandPlan = form.addField({
                id: "custpage_gennsdemandplan",
                type: ui.FieldType.CHECKBOX,
                label: "Generate Netsuite Demand Plan",
            });

            var stDateFld = form.addField({
                id: "custpage_startdate",
                type: ui.FieldType.DATE,
                label: "Start Date",
            });
            stDateFld.updateDisplayType({
                displayType: ui.FieldDisplayType.DISABLED
            });
            stDateFld.defaultValue = currentDate;

            var sublist = form.addSublist({
                id: "custpage_sublist",
                type: ui.SublistType.INLINEEDITOR,
                label: 'Details'
            });

            var itemFld = sublist.addField({
                id: "custpage_item",
                type: ui.FieldType.SELECT,
                label: "Item",
                source: "item"
            });
            itemFld.isMandatory = true;
            var itemDescFld = sublist.addField({
                id: "custpage_itemdesc",
                type: ui.FieldType.TEXT,
                label: "Description",
            });
            itemDescFld.updateDisplayType({
                displayType: ui.FieldDisplayType.DISABLED
            });
            var locationFld = sublist.addField({
                id: "custpage_location",
                type: ui.FieldType.SELECT,
                label: "Location",
                source: "location"
            });
            locationFld.isMandatory = true;
            locationFld.defaultValue = DEFAULT_LOCATION;
            for (var i = 1; i <= 12; i++) {
                mnthFieldLabel = fmtCommonUtl.monthNames[currentDate.getMonth()] + " " + currentDate.getFullYear();
                monthField = sublist.addField({
                    id: "custpage_mnth" + i,
                    type: ui.FieldType.INTEGER,
                    label: mnthFieldLabel
                });
                currentDate = fmtCommonUtl.addMonths(currentDate, 1);
                monthField.maxLength = 4;
                //if (i == 1)
                //monthField.isMandatory = true;
            }

            form.addSubmitButton({
                label: "Proceed / Refresh"
            });

            if (currentContext.request.method === 'POST') {
                var request = currentContext.request;
                var startDate, currentDate, recordSave = false;
                var listCount = request.getLineCount({
                    group: 'custpage_sublist'
                });
                var dpReqData = {body: {}, lines: []}, dpReqDataLine;
                startDate = fmtCommonUtl.formatStringToDate(request.parameters.custpage_startdate);
                currentDate = startDate;
                currentDate.setDate(1);
                genDemandPlan = request.parameters.custpage_gennsdemandplan == "T" ? true : false;

                for (var c = 0; c < listCount; c++) {
                    log.debug("line Changed ", request.getSublistValue({
                        group: 'custpage_sublist',
                        name: "custpage_linechanged",
                        line: c
                    }));
                    currentDate = startDate;
                    currentDate.setDate(1);
                    dpReqDataLine = {};
                    dpReqDataLine["custrecord_fmt_dprd_item"] = request.getSublistValue({
                        group: 'custpage_sublist',
                        name: "custpage_item",
                        line: c
                    });
                    dpReqDataLine["custrecord_fmt_dprd_location"] = request.getSublistValue({
                        group: 'custpage_sublist',
                        name: "custpage_location",
                        line: c
                    });

                    for (var i = 1; i <= 12; i++) {
                        dpReqDataLine["custrecord_fmt_dprd_qtymnth" + i] = request.getSublistValue({
                            group: 'custpage_sublist',
                            name: "custpage_mnth" + i,
                            line: c
                        });
                        dpReqDataLine["custrecord_fmt_dprq_mnth" + i + "stdate"] = currentDate;
                        currentDate = fmtCommonUtl.addMonths(currentDate, 1);
                    }
                    dpReqData.lines.push(dpReqDataLine);
                    recordSave = true;

                }
                dpReqData.id = itemDemandPlanReq.getTemplateRecordId();
                dpReqData.body[itemDemandPlanReq.fields.SaveOnly.id] = true;
                itemDemandPlanReq.upsert(dpReqData);
                //addSuccessMessage = true;

                if (genDemandPlan) {
                    dpReqData.body[itemDemandPlanReq.fields.SaveOnly.id] = false;
                    dpReqData.id = null;
                    itemDemandPlanReq.upsert(dpReqData);
                    addSuccessMessage = true;
                }
            }

            // Fill Sublist data
            existingDataStDate.setDate(1);
            existingDataEnDate = fmtCommonUtl.addMonths(existingDataStDate, 13);

            var existingSavedOnlyData = itemDemandPlanReq.getSavedonlyDemandPlans(
                fmtCommonUtl.formatDateToString(existingDataStDate),
                fmtCommonUtl.formatDateToString(existingDataEnDate));
            var sublistLine = 0, currentFieldMonth, currentFieldYear;

            var existingSavedOnlyDataKeys = Object.keys(existingSavedOnlyData);
            var allKeys = [], dpsKey;

            log.debug("existingSavedOnlyData", JSON.stringify(existingSavedOnlyData));

            if (!!existingSavedOnlyDataKeys && existingSavedOnlyDataKeys.length > 0) {
                allKeys = allKeys.concat(existingSavedOnlyDataKeys);
            }

            allKeys = allKeys.filter(function (x, i, a) {
                return a.indexOf(x) == i;
            });

            log.debug("allKeys", JSON.stringify(allKeys));

            for (var k = 0; k < allKeys.length; k++) {
                dpsKey = allKeys[k];
                log.debug("dpsKey", dpsKey);

                if (!!existingSavedOnlyData[dpsKey]) {
                    log.debug("adding line for ", dpsKey);
                    currentDate = new Date(today);
                    sublist.setSublistValue({
                        id: "custpage_saveonlylinefld",
                        line: sublistLine,
                        value: "T"
                    });
                    sublist.setSublistValue({
                        id: "custpage_item",
                        line: sublistLine,
                        value: existingSavedOnlyData[dpsKey].item
                    });
                    sublist.setSublistValue({
                        id: "custpage_location",
                        line: sublistLine,
                        value: existingSavedOnlyData[dpsKey].location
                    });
                    if (!!existingSavedOnlyData[dpsKey].description)
                        sublist.setSublistValue({
                            id: "custpage_itemdesc",
                            line: sublistLine,
                            value: existingSavedOnlyData[dpsKey].description
                        });
                    for (var i = 1; i <= 12; i++) {
                        currentFieldMonth = currentDate.getMonth();
                        currentFieldYear = currentDate.getFullYear();
                        if (!!existingSavedOnlyData[dpsKey][currentFieldMonth + "|" + currentFieldYear] &&
                            !!existingSavedOnlyData[dpsKey][currentFieldMonth + "|" + currentFieldYear].quantity) {
                            sublist.setSublistValue({
                                id: "custpage_mnth" + i,
                                line: sublistLine,
                                value: existingSavedOnlyData[dpsKey][currentFieldMonth + "|" + currentFieldYear].quantity
                            });
                        }
                        currentDate = fmtCommonUtl.addMonths(currentDate, 1);
                    }
                    sublistLine++;
                }
            }
            return form;
        }

        return {
            onRequest: onRequest
        };
    });


/**
 *@NApiVersion 2.0
 *@NScriptType UserEventScript
 */

/***********************************************************************
 *
 * The following javascript code is created by FMT Consultants LLC,
 * a NetSuite Partner. It is a SuiteFlex component containing custom code
 * intended for NetSuite (www.netsuite.com) and use the SuiteScript API.
 * The code is provided "as is": FMT Consultants LLC shall not be liable
 * for any damages arising out the intended use or if the code is modified
 * after delivery.
 *
 * Company:     FMT Consultants LLC, www.fmtconsultants.com
 * Author:      smehmood@fmtconsultants.com
 * File:        FMT_OO_SUE_DemandPlanRequest.js
 * Date:        7/5/2021
 *
 ***********************************************************************/

define(['N/error', 'N/record', 'N/search', 'N/runtime', 'N/render', 'N/file', 'N/email',
        '../classes/FMT_OO_ItemDemandPlanRequest', '../../Common/FMT_UTL_Common'],
    function (error, record, search, runtime, render, file, email, dpReq, fmtCommonUtl) {
        function afterSubmit(context) {
            if (context.type == context.UserEventType.CREATE || context.type == context.UserEventType.EDIT) {
                try {
                    var scriptObj = runtime.getCurrentScript();
                    var pdfLayout = scriptObj.getParameter({name: 'custscript_dprpdflayout'});
                    var emailSender = scriptObj.getParameter({name: 'custscript_emailsender'});
                    var emailRecipients = scriptObj.getParameter({name: 'custscript_emailrecipients'});
                    var recId = context.newRecord.id;
                    var recType = context.newRecord.type;
                    var dpReqData, currentFieldMonth, currentFieldYear;
                    var existingDataKeys;
                    var allKeys = [], dpsKey, currentDate, itemLineObject, itemLinesArray = [];
                    var finalResultSet = {}, renderer;

                    log.debug("email sent already", context.newRecord.getValue({fieldId: "custrecord_emailsent"}));
                    log.debug("Template", context.newRecord.getValue({fieldId: "custrecord_fmt_dpr_saveonly"}));

                    if (context.newRecord.getValue({fieldId: "custrecord_fmt_dpr_saveonly"}) == false &&
                        context.newRecord.getValue({fieldId: "custrecord_emailsent"}) == false) {
                        dpReqData = dpReq.getDemandPlanById(recId);
                        existingDataKeys = Object.keys(dpReqData);

                        log.debug("existingSavedOnlyData", JSON.stringify(dpReqData));

                        if (!!existingDataKeys && existingDataKeys.length > 0) {
                            allKeys = allKeys.concat(existingDataKeys);
                        }

                        log.debug("allKeys", JSON.stringify(allKeys));

                        itemLineObject = {};
                        itemLineObject.lineno = 0;
                        itemLineObject.item = "&nbsp;Item";
                        itemLineObject.desc = "&nbsp;Description";
                        itemLineObject.location = "&nbsp;Location";
                        currentDate = context.newRecord.getValue({fieldId: "custrecord_fmt_dpr_startdate"});
                        currentDate.setDate(1);
                        for (var i = 0; i < 12; i++) {
                            log.debug("currentDate.getMonth()", currentDate.getMonth());
                            itemLineObject['month' + (i + 1)] = fmtCommonUtl.monthNames_short[currentDate.getMonth()] + "<br/>" + currentDate.getFullYear();
                            currentDate = fmtCommonUtl.addMonths(currentDate, 1);
                        }
                        itemLinesArray.push(itemLineObject);
                        for (var k = 0; k < allKeys.length; k++) {
                            itemLineObject = {};
                            dpsKey = allKeys[k];
                            log.debug("dpsKey", dpsKey);

                            if (!!dpReqData[dpsKey]) {
                                log.debug("adding line for ", dpsKey);
                                currentDate = context.newRecord.getValue({fieldId: "custrecord_fmt_dpr_startdate"});
                                currentDate.setDate(1);
                                itemLineObject.item = dpReqData[dpsKey].item_text;
                                itemLineObject.desc = dpReqData[dpsKey].description;
                                itemLineObject.location = dpReqData[dpsKey].location_text;

                                for (var i = 1; i <= 12; i++) {
                                    currentFieldMonth = currentDate.getMonth();
                                    currentFieldYear = currentDate.getFullYear();
                                    if (!!dpReqData[dpsKey][currentFieldMonth + "|" + currentFieldYear] &&
                                        !!dpReqData[dpsKey][currentFieldMonth + "|" + currentFieldYear].quantity) {
                                        itemLineObject['month' + i] = dpReqData[dpsKey][currentFieldMonth + "|" + currentFieldYear].quantity;
                                    }
                                    currentDate = fmtCommonUtl.addMonths(currentDate, 1);
                                }
                                log.debug("itemLineObject", JSON.stringify(itemLineObject));
                                itemLineObject.lineno = itemLinesArray.length;
                                itemLinesArray.push(itemLineObject);
                            }
                        }
                        log.debug("itemLinesArray", JSON.stringify(itemLinesArray));

                        finalResultSet.refno = recId;
                        finalResultSet.date = fmtCommonUtl.formatDateToString(context.newRecord.getValue({fieldId: "custrecord_fmt_dpr_startdate"}));
                        finalResultSet.lines = itemLinesArray;
                        renderer = render.create();

                        renderer.setTemplateByScriptId({
                            scriptId: pdfLayout
                        });
                        log.debug("finalResultSet", JSON.stringify(finalResultSet));

                        renderer.addCustomDataSource({
                            format: render.DataSource.OBJECT,
                            alias: "JSON",
                            data: {data: finalResultSet}
                        });

                        var demandPlanReqPDF = renderer.renderAsPdf();
                        demandPlanReqPDF.name = 'DemandPlanRequest_' + recId + ".pdf";
                        // demandPlanReqPDF.folder = '-20';
                        // demandPlanReqPDF.save();
                        emailRecipients = emailRecipients.split(",");
                        email.send({
                            author: emailSender,
                            recipients: emailRecipients,
                            subject: 'Demand Plan Request Submitted : Id : ' + recId,
                            body: 'Hi, Please find the details of submitted demand plan request in attached pdf.',
                            attachments: [demandPlanReqPDF]
                        });
                        record.submitFields({type: recType, id: recId, values: {"custrecord_emailsent": true}});
                    }
                } catch (ex) {
                    log.error("Error when sending email.", ex.message);
                }
            }
        }

        return {
            afterSubmit: afterSubmit
        };
    });



/**
* @NApiVersion 2.0
* @NScriptType ClientScript
*/
var TranId;
define(['N/url','N/record','N/ui/dialog','N/runtime', 'N/currentRecord'],
function(url,record,dialog,runtime,currentRecord) 
{
	
	function saveRecord(context,record,currentRecord) {
            var CorObj = context.currentRecord;

           var recno = CorObj.id;

           alert('Hello Rakesh');

           var output = url.resolveScript({
               scriptId: 'customscript_fmt_item_label_ir_sue',
               deploymentId: 'customdeploy_fmt_omniome_item_label_dep',
               returnExternalUrl: true
           });
   
           output = output + '&recno=' + recno;
   
           window.open(output,'_blank');
   
        }

        //im going to check for flag

	// function callSuitelet()
	// {
    //    var recno = currentRecord.get().id;

	// 	var output = url.resolveScript({
	// 	    scriptId: 'customscript_fmt_item_label_ir_sue',
	// 	    deploymentId: 'customdeploy_fmt_omniome_item_label_dep',
	// 	    returnExternalUrl: true
	// 	});

	// 	output = output + '&recno=' + recno;

	// 	window.open(output,'_blank');

	// 	//dialog.alert(optionsRec);

	// }

	return {
	saveRecord : saveRecord,
	// callSuitelet: callSuitelet
	};
});
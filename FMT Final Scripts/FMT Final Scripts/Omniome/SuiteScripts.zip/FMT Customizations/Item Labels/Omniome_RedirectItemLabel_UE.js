		/**
		 *
		 * * Version    Date            Author           			Remarks
		 *   1.00       3 Mar 2021		Sam Goldfarb				Initial Version
		 *
		 * 
		 * @NApiVersion 2.1
		 * @NScriptType UserEventScript
		 * @NModuleScope Public
		 */
		
         define(['N/search', 
		 'N/log',
		 'N/record',
		 'N/runtime',
         'N/redirect'
	],
	
	function(search, log, record, runtime, redirect, https) {
		
		function afterSubmit(context) {
			var stLogTitle = 'afterSubmit';
			
			try {
				log.audit(stLogTitle, '>> SCRIPT START: ' + runtime.executionContext + ' <<');
				
				if (context.type !== 'edit' && context.type !== 'create') {
					log.debug(stLogTitle, 'Context type is not create or edit. Type: ' + context.type);
					log.debug(stLogTitle, '>> SCRIPT END <<');
					return;
				}
				
				//DECLARE VARIABLES
				var recIR = context.newRecord;
				var stNumItems = recIR.getLineCount('item');
				var stIRName = recIR.getValue('tranid');
				var objIR = record.load({
					type: record.Type.ITEM_RECEIPT,
					id: recIR.id
				});

				var counter = 0;
				//loop through lineCount, see if we have any of those with a value

				for(var i = 0; i < objIR.getLineCount('item');i++){
					var numLabels = objIR.getSublistValue({
						sublistId: 'item',
						fieldId: 'custcol_fmt_quantity_of_labels',
						line: i
					});

                    log.debug('THis is Number of Labels',numLabels);

					if(numLabels > 0){
						log.debug('Printing Labels')
						counter++
					}
				}

				if(counter == 0){
					log.debug('Exiting Script')
                    return;
				}

				else{
					redirect.toSuitelet({
						scriptId: 'customscript_fmt_item_label_ir_sue',
						deploymentId: 'customdeploy_fmt_omniome_item_label_dep',
						parameters: {
							'recno': recIR.id
						}
					})
				}
			
			} catch(e) {
				log.error(stLogTitle, e);
				log.error(stLogTitle, '>> SCRIPT END <<');
				return;
			}
		}
		
		
		
		function _isEmpty(value) {
            if (value == null) {
                return true;
            }
            if (value == undefined) {
                return true;
            }
            if (value == 'undefined') {
                return true;
            }
            if (value == '') {
                return true;
            }
			if (value == NaN) {
				return true;
			}
			if (value == 'NaN') {
				return true;
			}
            return false;
        }

	return {
		afterSubmit : afterSubmit
	};
});	
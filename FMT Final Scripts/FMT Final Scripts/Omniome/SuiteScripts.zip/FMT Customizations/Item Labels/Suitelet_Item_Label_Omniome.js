/**
 *@NApiVersion 2.1
 *@NScriptType Suitelet
 */
/***********************************************************************
 *
 * The following javascript code is created by FMT Consultants LLC,
 * a NetSuite Partner. It is a SuiteFlex component containing custom code
 * intended for NetSuite (www.netsuite.com) and use the SuiteScript API.
 * The code is provided "as is": FMT Consultants LLC shall not be liable
 * for any damages arising out the intended use or if the code is modified
 * after delivery.
 *
 * Company:     FMT Consultants LLC, www.fmtconsultants.com
 * Author:      sgoldfarb@fmtconsultants.com
 * File:        FMT_OO_SUT_BomPrint.js
 * Date:        07/13/2021
 *
 ***********************************************************************/

define(['N/runtime', 'N/record', 'N/search', 'N/http', 'N/file', 'N/render', 'N/xml', 'N/format'],
    function (runtime, record, search, http, file, render, xml, format) {
        function onRequest(params) {
            try {
                if (params.request.method === 'GET') {
                    var scriptObj = runtime.getCurrentScript();
                    var request = params.request, resultData;

                    var recno = request.parameters.recno;

                    //load the recor
                    //isnt going to work on create
                    var woLineCount, resultLine;

                    var woRec = record.load({type: record.Type.ITEM_RECEIPT, id: recno}); //
                    //{itemid}

                    var resultData;

                    var createdFrom = woRec.getText({fieldId: 'createdFrom'});
                    var poDate = formatStringField(woRec.getValue({fieldId: 'trandate'}));
                    var poText = woRec.getText('createdfrom');
                    var woRecId = woRec.getValue({fieldId: 'tranid'});
                    

                    resultData = {
                        "poNumber": createdFrom,
                      	"poDate": poDate,
                        "poText": poText,
                      	"itemReceiptNumber": woRecId,
                    };


                    fetchWorkorderIssues(woRec, resultData, params);

                    for(var i = 0; i < woRec.getLineCount('item'); i++){
                        woRec.setSublistValue({sublistId: 'item',fieldId:'custcol_fmt_quantity_of_labels',line: i, value: null});
                    }
    
                    var newIR = woRec.save();

                    log.debug('You have saved Item Receipt',newIR);
    

                    // woRec.setValue('memo','helloworld');
                    // woRec.save();
                    //log.debug({title: '43',details: JSON.stringify(resultData)});
                }
            } catch (e) {
                log.debug('Error Occured', e)
            }
        }

        function fetchWorkorderIssues(woRec, resultData, params,invDeatilSearch) {

            //log.debug('itemArr',itemArr)
            //here I am going to loop through the item sublist
            //if number of labels to print has a value
            //continue processing lines
            //get inventory detail for lines that require
            //going to have to handle the inventory detail
            //if inventory detail true, loop through create some stuff
            //if false, leave as blank and continue building object resultLine.
            
            var itemWiseWoIssue = {};
            var item;

            resultData.lines = [];

            var resultLine = {};

            //resultData.sublines = [];



            var woLineCount = woRec.getLineCount({'sublistId': 'item'});
          
            for (var i = 0; i < woLineCount; i++) {

                var itemID = woRec.getSublistValue({sublistId: 'item', fieldId: 'item', line: i});

                var myItemLookup = search.lookupFields({
                    type: search.Type.ITEM,
                    id: itemID,
                    columns: ['itemid']
                });

                var itemText = myItemLookup.itemid;

                log.debug('myItemLookup',myItemLookup);

                var numberOfLabels = woRec.getSublistValue({sublistId: 'item', fieldId: 'custcol_fmt_quantity_of_labels', line: i});
                log.debug('number of Labels',numberOfLabels);
                var inventoryDetail = woRec.getSublistSubrecord({sublistId: 'item', fieldId: 'inventorydetail', line: i});

                var expirationDate;

                //if inventorydetail is true, loop through it
                //grab all values
                //so from here for items, I am getting the expirationDate, item text, item descriptionmemo field, quantity

            if(numberOfLabels > 0){

                if(!!inventoryDetail){
                    log.debug('There is inventory Detail');

                    var inventoryDetailLineCount = inventoryDetail.getLineCount('inventoryassignment');

                    log.debug('Countof Inv Detail',inventoryDetailLineCount);
					
					//BUILD LOT NUMBER STRING
					for (var j=0; j<inventoryDetailLineCount; j++) {
						var inventoryNumber = inventoryDetail.getSublistValue({
							sublistId: 'inventoryassignment',
							fieldId: 'receiptinventorynumber',
							line: j
						});

                        expirationDate = inventoryDetail.getSublistValue({
							sublistId: 'inventoryassignment',
							fieldId: 'expirationdate',
							line: j
						});

                        if(!!expirationDate && expirationDate != ""){

                        expirationDate = formatStringField(expirationDate);
                        }

                    //setting result lines inventory Detail
                    //setting resultLines qty required
                    //setting expirationDate
                    resultLine.inventoryDetail = inventoryNumber;    
                    resultLine.memberitemid = woRec.getSublistValue({sublistId: 'item', fieldId: 'item', line: i});
                    resultLine.memberitem = woRec.getSublistText({sublistId: 'item', fieldId: 'item', line: i});
                    log.debug('This is Item Text',resultLine.memberitem);
                    resultLine.qtyrequired = woRec.getSublistValue({sublistId: 'item', fieldId: 'quantity', line: i});
                    resultLine.expirationDate = expirationDate;
                    resultLine.descp = woRec.getSublistValue({sublistId: 'item', fieldId: 'description', line: i});
    
    
                    resultData.lines.push({
                        "memberitemid": resultLine.memberitemid,
                        "memberitem": itemText,
                        "qtyrequired": resultLine.qtyrequired,
                        "description": resultLine.descp,
                        "numberofLabels": numberOfLabels,
                        "inventoryDetail": inventoryNumber,
                        "expirationDate": expirationDate //this will be blank for non serial numbers
                    });

                }
                }

                else{

                resultLine.memberitemid = woRec.getSublistValue({sublistId: 'item', fieldId: 'item', line: i});
                resultLine.memberitem = woRec.getSublistText({sublistId: 'item', fieldId: 'item', line: i});
                resultLine.qtyrequired = woRec.getSublistValue({sublistId: 'item', fieldId: 'quantity', line: i});
                resultLine.expirationDate = expirationDate;
                resultLine.descp = woRec.getSublistValue({sublistId: 'item', fieldId: 'description', line: i});


                resultData.lines.push({
                    "memberitemid": resultLine.memberitemid,
                    "memberitem": itemText,
                    "qtyrequired": resultLine.qtyrequired,
                    "description": resultLine.descp,
                    "numberofLabels": numberOfLabels,
                    "inventoryDetail": inventoryDetail,
                    "expirationDate": expirationDate //this will be blank for non serial numbers
                });

            }
        }


            log.debug({title: 'resultData', details: JSON.stringify(resultData)});
            var renderer = render.create();
            renderer.setTemplateByScriptId({
                scriptId: 'CUSTTMPL_123_5711325_SB1_510'
            });

            var samData = "Hello World";

            renderer.addCustomDataSource({
                format: render.DataSource.OBJECT,
                alias: "JSON",
                data: {data: resultData}
            });

           if (!!resultData){

            try{
                var invoicePdf = renderer.renderAsPdf();
                params.response.writeFile({file: invoicePdf, isInline: true});

            } catch(e){
                log.debug('This is your Error on Render',e);
            }

            } else {
                params.response.write('There is a problem with BOM PDF');
            }

        }

    }

        function formatStringField(input) {
            return (input.getMonth() + 1) + "/" + input.getDate() + "/" + input.getFullYear();
        }

        return {
            onRequest: onRequest
        };
    });
/**
 * Copyright (c) 1998-2018 NetSuite, Inc.
 * 2955 Campus Drive, Suite 100, San Mateo, CA, USA 94403-2511
 * All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of
 * NetSuite, Inc. ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with NetSuite.
 * 
 * User Story: PEER CHAIN COMPANY: 
 *
 * * Version    Date            Author           			Remarks
 *   1.00       11 Feb 2019		Sam Goldfarb				Initial Version
 *
 * 
 * @NApiVersion 2.x
 * @NScriptType UserEventScript
 * @NModuleScope Public
 */
 
 define(['N/search', 
		 'N/log',
		 'N/record',
		 'N/runtime'
	],
	
	function(search, log, record, runtime, email, url, redirect, https) {
		
		function afterSubmit(context) {
			var stLogTitle = 'afterSubmit';
			
			try {
				log.audit(stLogTitle, '>> SCRIPT START: ' + runtime.executionContext + ' <<');
				
				if (context.type !== 'edit' && context.type !== 'create') {
					log.debug(stLogTitle, 'Context type is not create or edit. Type: ' + context.type);
					log.debug(stLogTitle, '>> SCRIPT END <<');
					return;
				}
				
				//DECLARE VARIABLES
				var recIR = context.newRecord;
				var stNumItems = recIR.getLineCount('item');
				var stIRName = recIR.getValue('tranid');
				var objIR = record.load({
					type: record.Type.ITEM_RECEIPT,
					id: recIR.id
				});
				
				//GO THROUGH LINE ITEMS
				for (var i=0; i<stNumItems; i++) {
					log.debug(stLogTitle, 'Line item: ' + i);
					var arrLotNums = [];
					var stLotNumsFinal = '';
					
					var objInvDetail = recIR.getSublistSubrecord({
						sublistId: 'item',
						fieldId: 'inventorydetail',
						line: i
					});
					var stInvDetailLines = objInvDetail.getLineCount('inventoryassignment');
                  
                   log.debug('Countof Inv Detail',stInvDetailLines);
					
					//BUILD LOT NUMBER STRING
					for (var j=0; j<stInvDetailLines; j++) {
						var stLotNum = objInvDetail.getSublistValue({
							sublistId: 'inventoryassignment',
							fieldId: 'inventorynumber',
							line: j
						});
                      
                      log.debug('This is Lot Number',stLotNum);
						arrLotNums.push(stLotNum);
					}
					stLotNumsFinal = arrLotNums.join(', ');
					log.debug(stLogTitle, 'Lot Num Array: ' + arrLotNums + ', Lot Num String: ' + stLotNumsFinal);
					
					//SET LOT NUMBER COLUMN FIELD
					recIR.setSublistValue({
						sublistId: 'item',
						fieldId: 'custcol_fmt_inventory_detail_item_rec',
						value: stLotNumsFinal,
						line: i
					});
				}
				
				//SAVE IR RECORD
				var stIRNID = recIR.save({
					ignoreMandatoryFields: true
				});
				log.audit(stLogTitle, 'Successfully saved IR w/ ID: ' + stIRNID); 
				log.audit(stLogTitle, '>> SCRIPT END <<');
				return;
			
			} catch(e) {
				log.error(stLogTitle, e);
				log.error(stLogTitle, '>> SCRIPT END <<');
				return;
			}
		}
		
		
		
		function _isEmpty(value) {
            if (value == null) {
                return true;
            }
            if (value == undefined) {
                return true;
            }
            if (value == 'undefined') {
                return true;
            }
            if (value == '') {
                return true;
            }
			if (value == NaN) {
				return true;
			}
			if (value == 'NaN') {
				return true;
			}
            return false;
        }

	return {
		afterSubmit : afterSubmit
	};
});	
		/**
		 *
		 * * Version    Date            Author           			Remarks
		 *   1.00       31 Aug 2020		Sam Goldfarb				Initial Version
		 *
		 * 
		 * @NApiVersion 2.1
		 * @NScriptType UserEventScript
		 * @NModuleScope Public
		 */
		
         define(['N/search', 
         'N/log',
         'N/record',
         'N/runtime',
         'N/format',
         'N/error'
     ],
     
     function(search, log, record, runtime,format,error){
         
         function beforeSubmit(context){


                var myRec = context.newRecord;

                var istrue = "YES";

                if(istrue == "YES"){

    
             throw error.create({
                 name: 'Invalid PO',
                 message: 'ITEM 10-0146-01 does not belong to this Vendor '
             });

            }
                  
            }
     
     return {
         beforeSubmit : beforeSubmit
     };
 });	
/**
*@NApiVersion 2.x
*@NScriptType Suitelet
*/
define(['N/runtime', 'N/record', 'N/search', 'N/http', 'N/file', 'N/render', 'N/xml', 'N/format'],
    function (runtime, record, search, http, file, render, xml, format) 
    {
        function onRequest(params) 
        {
        	try
        	{
        		if (params.request.method === 'GET') 
                {
                    var scriptObj = runtime.getCurrentScript();
                    var request = params.request, resultData;
                    var recno = request.parameters.recno;
                    var irLineCount, resultLine;
                    log.debug({
                        title: 'recno',
                        details: recno
                    });

                    var irRec = record.load({type: record.Type.ITEM_RECEIPT, id: recno});
                    irLineCount = irRec.getLineCount({'sublistId': 'item'});
                    var irIssues = fetchWorkorderIssues(recno);

                    log.debug('irIssues', JSON.stringify(irIssues));

                    resultData = {
                        "date": formatStringField(irRec.getValue({fieldId: 'trandate'})),
                        "reference": woRec.getValue({fieldId: 'tranid'}),
                        //created from purchase order
                    };

                    resultData.lines = [];

                    for (var i = 0; i < irLineCount; i++) {
                        resultLine = {};
                        resultLine.memberitemid = irRec.getSublistValue({sublistId: 'item', fieldId: 'item', line: i});
                        resultLine.descp = irRec.getSublistValue({sublistId: 'item', fieldId: 'description', line: i});
                        resultLine.sublines = !!woIssues[resultLine.memberitemid] ? woIssues[resultLine.memberitemid] : [];

                        if (resultLine.sublines.length == 0) {
                            resultLine.sublines.push({
                                //"lotserial": "",
                                "qtyissued": resultLine.inventorynumber
                            });
                        }

                        resultData.lines.push(resultLine);
                    }

                    log.debug({
                        title: 'resultData',
                        details: JSON.stringify(resultData)
                    });

                    var renderer = render.create();

                    renderer.setTemplateByScriptId({
                        scriptId: scriptObj.getParameter({name: 'CUSTTMPL_110_5711325_SB1_386'})
                    });

                    renderer.addCustomDataSource({
                        format: render.DataSource.OBJECT,
                        alias: "JSON",
                        data: {data: resultData}
                    });
                    if (!!resultData) {
                        var invoicePdf = renderer.renderAsPdf();                
                        params.response.writeFile({file: invoicePdf, isInline: true});    
                    } else {
                        params.response.write('There is a problem with ITEM LABEL PDF');
                    }
                }

        	}
        	catch(e)
        	{
        		log.debug('Error Occured',e)
        	}

        }
        function fetchWorkorderIssues(woId) {
            var itemWiseWoIssue = {};
            var item;

var itemreceiptSearchObj = search.create({
   type: "itemreceipt",
   filters:
   [
      ["type","anyof","ItemRcpt"], 
      "AND", 
      ["taxline","is","F"], 
      "AND", 
      ["shipping","is","F"], 
      "AND", 
      ["mainline","is","F"], 
      "AND", 
      ["internalid","anyof","9441"]
   ],
   columns:
   [
      search.createColumn({name: "internalid", label: "Internal ID"}),
      search.createColumn({name: "item", label: "Item"}),
      search.createColumn({
         name: "inventorynumber",
         join: "inventoryDetail",
         label: " Number"
      })
   ]
});
var searchResults = searchAll(itemreceiptSearchObj.run());

            for (var s = 0; s < searchResults.length; s++) {
                item = searchResults[s].getValue({name: 'item'});
                if (!itemWiseWoIssue[item]) {
                    itemWiseWoIssue[item] = [];
                }
itemWiseWoIssue[item].push({
                    inventorynumber: searchResults[s].getValue({name: 'inventorynumber', join: 'inventoryDetail'}),
                    item: searchResults[s].getText({name: 'item', label: 'item'}),
                    internalid: searchResults[s].getValue({name: 'internalid', label:'internalid'}),

});

            }

            return itemWiseWoIssue;
        }

        function searchAll(resultset) {
            var allResults = [];
            var startIndex = 0;
            var RANGECOUNT = 1000;

            do {
                var pagedResults = resultset.getRange({
                    start: parseInt(startIndex),
                    end: parseInt(startIndex + RANGECOUNT)
                });

                allResults = allResults.concat(pagedResults);

                var pagedResultsCount = pagedResults != null ? pagedResults.length : 0;
                startIndex += pagedResultsCount;

            }
            while (pagedResultsCount == RANGECOUNT);

            return allResults;
        }

        function formatStringField(input) {
            return (input.getMonth() + 1) + "/" + input.getDate() + "/" + input.getFullYear();
        }

        return {
            onRequest: onRequest
        };
    });








     
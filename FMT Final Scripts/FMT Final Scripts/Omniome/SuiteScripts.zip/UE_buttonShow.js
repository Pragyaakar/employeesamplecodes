/**
* @NApiVersion 2.x
* @NScriptType UserEventScript
*/
/*define(['N/ui/serverWidget'],['N/log'],['N/record'],
	function(serverWidget,log,record)
	{
		function beforeLoad(context)
		{
			try
			{
				//context.form.clientScriptFileId =    ;
				var custbutton = context.form.addButton({
					id:'custpage_item_label_custbutton',
					label:'Print Item Label',
					//functionName: 'callSuitelet()'              
				});
				/*var Removebutton = context.form.removeButton({
	            id :'print_item_label'
	            });
			}
			catch(e)
			{
				log.debug('before Load Error',e)
			}
		}
		return{
			beforeLoad : beforeLoad
		};
	});*/

/**
* @NApiVersion 2.0
* @NScriptType UserEventScript
*/

define(['N/log','N/record','N/ui/serverWidget'],
function(log,record,serverWidget) 
{
	function beforeLoad(context) 
	{
		try
		{
			context.form.clientScriptFileId = 22042;
			var button = context.form.addButton({
			id: 'custpage_item_label_print_button',
			label: 'Item Label Print',
			functionName: 'callSuitelet()'
			});

			/*var Removebutton = context.form.removeButton({
	            id :'print_item_label'
	            });*/
		}
		catch(e)
		{
			log.debug('Before Load Error',e)
		}
	}
	return {
	beforeLoad: beforeLoad
	};
});
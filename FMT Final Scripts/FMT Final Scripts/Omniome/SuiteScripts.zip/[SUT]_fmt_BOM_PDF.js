/**
 *@NApiVersion 2.x
 *@NScriptType Suitelet
 */
/***********************************************************************
 *
 * The following javascript code is created by FMT Consultants LLC,
 * a NetSuite Partner. It is a SuiteFlex component containing custom code
 * intended for NetSuite (www.netsuite.com) and use the SuiteScript API.
 * The code is provided "as is": FMT Consultants LLC shall not be liable
 * for any damages arising out the intended use or if the code is modified
 * after delivery.
 *
 * Company:     FMT Consultants LLC, www.fmtconsultants.com
 * Author:      smehmood@fmtconsultants.com
 * File:        FMT_CER_SLT_BOMPDF.js
 * Date:        3/5/2020
 *
 ***********************************************************************/

define(['N/runtime', 'N/record', 'N/search', 'N/http', 'N/file', 'N/render', 'N/xml', 'N/format'],
    function (runtime, record, search, http, file, render, xml, format) 
    {
        function onRequest(params) 
        {
            try
            {
                if (params.request.method === 'GET') 
                {
                    var scriptObj = runtime.getCurrentScript();
                    var request = params.request, resultData;

                    var recno = request.parameters.recno;
                    //log.debug({title: 'recno',details: recno});

                    var woLineCount, resultLine;
                    
                    var woRec = record.load({type: record.Type.WORK_ORDER, id: recno});
                    woLineCount = woRec.getLineCount({'sublistId': 'item'});
                    log.debug({title: '40',details: woLineCount});

                    /*var woIssues = fetchWorkorderIssues(recno);
                    log.debug({title: '43',details: woIssues});*/

                    resultData = {
                        "date": formatStringField(woRec.getValue({fieldId: 'trandate'})),
                        "orderno": woRec.getValue({fieldId: 'tranid'}),
                        "assembly": woRec.getText({fieldId: 'assemblyitem'}),
                        "billofmaterials": woRec.getText({fieldId: 'billofmaterials'}),
                        "billOfMatRevi": woRec.getText({fieldId: 'billofmaterialsrevision'}),
                        "unitsmeasure": woRec.getText({fieldId: 'units'}),
                        "qtyrequired": woRec.getValue({fieldId: 'quantity'}),
                        "comments": ""
                    };

                    resultData.lines = [];

                    for (var i = 0; i < woLineCount; i++) 
                    {
                        resultLine = {};
                        var itemID = woRec.getSublistValue({sublistId: 'item', fieldId: 'item', line: i});

                        resultLine.memberitemid = woRec.getSublistValue({sublistId: 'item', fieldId: 'item', line: i});
                        resultLine.memberitem = woRec.getSublistText({sublistId: 'item', fieldId: 'item', line: i});
                        resultLine.qtyrequired = woRec.getSublistValue({sublistId: 'item', fieldId: 'quantity', line: i});
                        resultLine.um = woRec.getSublistValue({sublistId: 'item', fieldId: 'unit', line: i});
                        resultLine.descp = woRec.getSublistValue({sublistId: 'item', fieldId: 'description', line: i});
                        
                        var woIssues = fetchWorkorderIssues(itemID);
                        log.debug({title: '43',details: woIssues});

                        resultLine.sublines = !!woIssues[resultLine.memberitemid] ? woIssues[resultLine.memberitemid] : [];

                        //log.debug('67', resultLine.sublines);

                        if (resultLine.sublines.length == 0) 
                        {
                            resultLine.sublines.push({
                                "inventorynumber": resultLine.inventorynumber,
                                "expirydate":resultLine.expirydate,
                                "qtyissued": resultLine.qtyissued
                            });
                        }
                        resultData.lines.push(resultLine);
                    }

                    log.debug({title: 'resultData',details: JSON.stringify(resultData)});

                    var renderer = render.create();

                    renderer.setTemplateByScriptId({
                        scriptId: scriptObj.getParameter({name: 'custscript_fmt_advanced_pdf'})
                    });

                    renderer.addCustomDataSource({
                        format: render.DataSource.OBJECT,
                        alias: "JSON",
                        data: {data: resultData}
                    });

                    if (!!resultData) {
                        var invoicePdf = renderer.renderAsPdf();
                        params.response.writeFile({file: invoicePdf, isInline: true});
                    } else {
                        params.response.write('There is a problem with BOM PDF');
                    }
                }
            }
            catch(e)
            {
                log.debug('Error Occured',e)
            }
        }

        function fetchWorkorderIssues(itemID) {

            log.debug('itemID',itemID)

            var itemWiseWoIssue = {};
            var item;
            var itemSearchObj = search.create({
               type: "item",
               filters:
               [
                  ["internalid","anyof",itemID], 
                  "AND", 
                  ["inventorynumber.quantityonhand","greaterthan","0"]
               ],
               columns:
               [
                  search.createColumn({name: "internalid", label: "Internal ID"}),
                  search.createColumn({
                     name: "inventorynumber",
                     join: "inventoryNumber",
                     label: "Number"
                  }),
                  search.createColumn({
                     name: "expirationdate",
                     join: "inventoryNumber",
                     label: "Expiration Date"
                  }),
                  search.createColumn({
                     name: "quantityonhand",
                     join: "inventoryNumber",
                     label: "On Hand"
                  })
               ]
            });

            var searchResults = searchAll(itemSearchObj.run());
            //log.debug({title: '156',details: searchResults.length});

            for (var s = 0; s < searchResults.length; s++) 
            {
                //var item = searchResults[s].getValue({name: 'item'});
                
                if (!itemWiseWoIssue[itemID]) 
                {
                    itemWiseWoIssue[itemID] = [];
                }

                itemWiseWoIssue[itemID].push({
                    inventorynumber: searchResults[s].getValue({name: "inventorynumber",join: "inventoryNumber",label: "Number"}),
                    expirydate: searchResults[s].getValue({name: "expirationdate",join: "inventoryNumber",label: "Expiration Date"}),
                    qtyissued: searchResults[s].getValue({name: "quantityonhand",join: "inventoryNumber",label: "On Hand"}),
                    internalid: searchResults[s].getValue({name: "internalid", label: "Internal ID"})
                });

                log.debug({title: '177',details: itemWiseWoIssue});
            }

            return itemWiseWoIssue;
        }

        function searchAll(resultset) 
        {
            var allResults = [];
            var startIndex = 0;
            var RANGECOUNT = 1000;

            do 
            {
                var pagedResults = resultset.getRange({
                    start: parseInt(startIndex),
                    end: parseInt(startIndex + RANGECOUNT)
                });

                allResults = allResults.concat(pagedResults);
                //log.debug({title: '199',details: allResults});
                
                var pagedResultsCount = pagedResults != null ? pagedResults.length : 0;
                startIndex += pagedResultsCount;

            }
            
            while (pagedResultsCount == RANGECOUNT);
            
            return allResults;
        }

        function formatStringField(input) {
            return (input.getMonth() + 1) + "/" + input.getDate() + "/" + input.getFullYear();
        }

        return {
            onRequest: onRequest
        };
    });
